"""串口通信工具：发送、读取、监控。"""
from __future__ import annotations

import time
import threading
from collections import deque

from tools import tool

try:
    import serial
    import serial.tools.list_ports
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False

_monitor_thread: threading.Thread | None = None
_monitor_buf: deque = deque(maxlen=500)
_monitor_stop = threading.Event()


def _get_port(port: str = "") -> str:
    if port:
        return port
    import config
    port = config.serial_cfg.get("serial_port", "")
    if port:
        return port
    if HAS_SERIAL:
        ports = list(serial.tools.list_ports.comports())
        if ports:
            return ports[0].device
    return "COM3"


def _get_baud(baudrate: int = 0) -> int:
    if baudrate:
        return baudrate
    import config
    return int(config.serial_cfg.get("baudrate", 115200))


@tool(
    "serial_list_ports",
    "列出当前系统可用的串口（COM 端口）。",
    {},
    [],
)
def serial_list_ports() -> str:
    if not HAS_SERIAL:
        return "错误：未安装 pyserial，请 pip install pyserial"
    ports = serial.tools.list_ports.comports()
    if not ports:
        return "未检测到串口设备。"
    return "\n".join(f"{p.device}: {p.description} [VID:PID={p.vid}:{p.pid}]" for p in ports)


@tool(
    "serial_send",
    "向串口发送一条命令（自动追加换行符）。",
    {
        "command": {"type": "string", "description": "要发送的命令文本"},
        "port": {"type": "string", "description": "串口号如 COM3，留空自动检测"},
        "baudrate": {"type": "integer", "description": "波特率，默认 115200"},
    },
    ["command"],
)
def serial_send(command: str, port: str = "", baudrate: int = 0) -> str:
    if not HAS_SERIAL:
        return "错误：未安装 pyserial"
    port = _get_port(port)
    baud = _get_baud(baudrate)
    try:
        with serial.Serial(port, baud, timeout=1, write_timeout=5) as ser:
            data = (command + "\n").encode("utf-8")
            ser.write(data)
            ser.flush()
            return f"已发送到 {port}@{baud}: {command!r}"
    except serial.SerialException as e:
        return f"串口错误: {e}"


@tool(
    "serial_read",
    "从串口读取输出。可指定行数或等待关键词出现。",
    {
        "port": {"type": "string", "description": "串口号，留空自动检测"},
        "baudrate": {"type": "integer", "description": "波特率"},
        "lines": {"type": "integer", "description": "读取行数，默认 20"},
        "timeout": {"type": "number", "description": "超时秒数，默认 3"},
        "wait_for": {"type": "string", "description": "等待包含此关键词的行出现后返回"},
    },
    [],
)
def serial_read(port: str = "", baudrate: int = 0, lines: int = 20, timeout: float = 3, wait_for: str = "") -> str:
    if not HAS_SERIAL:
        return "错误：未安装 pyserial"
    port = _get_port(port)
    baud = _get_baud(baudrate)
    try:
        with serial.Serial(port, baud, timeout=0.5) as ser:
            collected = []
            deadline = time.time() + timeout
            while time.time() < deadline and len(collected) < lines:
                raw = ser.readline()
                if raw:
                    line = raw.decode("utf-8", errors="replace").rstrip()
                    collected.append(line)
                    if wait_for and wait_for in line:
                        break
            if not collected:
                return f"({port}@{baud} 在 {timeout}s 内无输出)"
            return "\n".join(collected)
    except serial.SerialException as e:
        return f"串口错误: {e}"


@tool(
    "serial_send_read",
    "发送命令并立即读取响应（常用于测试）。",
    {
        "command": {"type": "string", "description": "发送的命令"},
        "port": {"type": "string", "description": "串口号"},
        "baudrate": {"type": "integer", "description": "波特率"},
        "timeout": {"type": "number", "description": "等待响应超时秒数，默认 2"},
    },
    ["command"],
)
def serial_send_read(command: str, port: str = "", baudrate: int = 0, timeout: float = 2) -> str:
    if not HAS_SERIAL:
        return "错误：未安装 pyserial"
    port = _get_port(port)
    baud = _get_baud(baudrate)
    try:
        with serial.Serial(port, baud, timeout=0.1, write_timeout=min(max(timeout, 0.1), 5)) as ser:
            ser.reset_input_buffer()
            ser.write((command + "\n").encode("utf-8"))
            ser.flush()
            collected = []
            deadline = time.time() + timeout
            while time.time() < deadline:
                raw = ser.readline()
                if raw:
                    collected.append(raw.decode("utf-8", errors="replace").rstrip())
            resp = "\n".join(collected) if collected else "(无响应)"
            return f">>> {command}\n{resp}"
    except serial.SerialException as e:
        return f"串口错误: {e}"


def _monitor_loop(port: str, baud: int, keywords: list[str]):
    try:
        with serial.Serial(port, baud, timeout=0.5) as ser:
            while not _monitor_stop.is_set():
                raw = ser.readline()
                if raw:
                    line = raw.decode("utf-8", errors="replace").rstrip()
                    _monitor_buf.append(line)
                    for kw in keywords:
                        if kw.lower() in line.lower():
                            _monitor_buf.append(f"[ALERT] 检测到关键词 '{kw}': {line}")
    except serial.SerialException:
        _monitor_buf.append("[ERROR] 串口监控断开")


@tool(
    "serial_monitor_start",
    "启动后台串口监控，持续记录日志并检测异常关键词（HardFault, ERROR, assert）。",
    {
        "port": {"type": "string", "description": "串口号"},
        "baudrate": {"type": "integer", "description": "波特率"},
        "keywords": {"type": "string", "description": "逗号分隔的异常关键词，默认 HardFault,ERROR,assert,PANIC"},
    },
    [],
)
def serial_monitor_start(port: str = "", baudrate: int = 0, keywords: str = "HardFault,ERROR,assert,PANIC") -> str:
    global _monitor_thread
    if not HAS_SERIAL:
        return "错误：未安装 pyserial"
    if _monitor_thread and _monitor_thread.is_alive():
        return "监控已在运行中。用 serial_monitor_stop 停止后再启动。"
    port = _get_port(port)
    baud = _get_baud(baudrate)
    kws = [k.strip() for k in keywords.split(",") if k.strip()]
    _monitor_stop.clear()
    _monitor_buf.clear()
    _monitor_thread = threading.Thread(target=_monitor_loop, args=(port, baud, kws), daemon=True)
    _monitor_thread.start()
    return f"串口监控已启动: {port}@{baud}, 关键词: {kws}"


@tool(
    "serial_monitor_read",
    "读取监控缓冲区中的最新日志。",
    {"lines": {"type": "integer", "description": "读取最近 N 行，默认 50"}},
    [],
)
def serial_monitor_read(lines: int = 50) -> str:
    if not _monitor_buf:
        return "(缓冲区为空，监控可能未启动)"
    items = list(_monitor_buf)[-lines:]
    return "\n".join(items)


@tool(
    "serial_monitor_stop",
    "停止后台串口监控。",
    {},
    [],
)
def serial_monitor_stop() -> str:
    global _monitor_thread
    _monitor_stop.set()
    if _monitor_thread:
        _monitor_thread.join(timeout=2)
        _monitor_thread = None
    return "串口监控已停止。"