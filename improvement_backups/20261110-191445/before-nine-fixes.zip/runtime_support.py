"""Small shared helpers for durable reports and credential-safe diagnostics."""
from __future__ import annotations

import os
import re
import sys
import tempfile
from pathlib import Path

_SECRET_ENV = re.compile(r"(?:API_?KEY|TOKEN|PASSWORD|PASSWD|SECRET|PRIVATE_KEY)$", re.I)


def redact_secrets(text: str) -> str:
    values = {value for name, value in os.environ.items() if _SECRET_ENV.search(name) and len(value) >= 6}
    for value in sorted(values, key=len, reverse=True):
        text = text.replace(value, "***REDACTED***")
    return text


def ensure_utf8_stdio() -> None:
    """管道/重定向输出统一 UTF-8，被 IDE 捕获或写日志时中文不乱码；交互控制台保持默认编码。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            if stream.isatty():
                continue
            reconfigure = getattr(stream, "reconfigure", None)
            if reconfigure is not None:
                reconfigure(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            pass


def atomic_write(path: Path, content: str) -> None:
    """A stopped process must leave either the old or the new complete report."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix=f".{path.name}.", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
