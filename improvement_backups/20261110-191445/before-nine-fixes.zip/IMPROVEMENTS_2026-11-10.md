# 2026-11-10 改进交付记录

本轮已完成代码修改、需求基线修正和验证。当前具备更可靠的项目初始化、模型工具验证入口、只读探测和证据门禁；真实模型、真实设备和客户验收的结果仍按各自条件分别记录。

## 已修复的问题

| 问题 | 修改后的行为 |
|---|---|
| OPC UA 项目误复制串口、舵机和 MCU 需求 | 修订为 0.2.0 协议需求草案；新建项目按九个平台分别生成；真实混合集成需显式声明 interfaces |
| 工作流没有完成标记也判成功 | 只接受最后非空行的完整状态标记；没有标记即失败 |
| 更换项目后续跑仍跳过旧步骤 | 校验绝对工作流路径、内容、状态版本和项目变量；旧格式状态需重新运行 |
| 模型被截断时仍可能执行工具 | 执行前验证结束原因和调用 ID；截断、空调用和重复 ID 均失败，异常响应不写入后续对话 |
| 旧验收结果在需求、证据变化后继续有效 | 每条 pass 绑定需求指纹与证据 SHA256；变化后门禁阻塞 |
| 状态写入中断可能留下半个 YAML | 工作流状态、验收、评测及新增报告采用临时文件与原子替换 |
| 切换提供商仍沿用旧接口和密钥变量 | 单独切换 AGENT_PROVIDER 时按新厂商重新选择默认模型、接口和密钥变量；显式环境覆盖仍生效 |
| 真实工具评测只检查回答关键词 | 支持检查真实工具返回值；最小闭环工作流限定计算器并要求实际调用 |
| 调试不便、进度和证据分散 | 新增探测 JSON、工作流工具调用/Token 证据和 HTML 进度快照 |

新草案默认 `baseline_status: draft_requires_customer_review`。客户评审后才能显式设置为 `approved`；本轮没有替客户批准需求。

## 使用方法

在 PowerShell 中：

```powershell
Set-Location D:\Agent

# 在 workspace 中新建平台对应草案，已有目录禁止覆盖
python manage.py init my-project --platform opc_ua

# 只读探测，不打开端口、不连接目标、不修改 config.yaml
python manage.py discover

# 项目门禁、需求证据和已保存工作流；不调用模型或设备
python manage.py status workspace/my_opcua/project.yaml --html

# 当前提供商的真实工具评测 + 工作流（会消耗 API Token）
# 先在本机进程设置 DEEPSEEK_API_KEY，不要把密钥写进源码或发进聊天
python manage.py smoke
```

新建 AI 项目同时复制设计和评测模板。其他平台名称可通过 `python manage.py init --help` 查看。HTML 是保存时快照，重新执行命令刷新。

## 本轮验证结果

- `python selftest.py`：106 passed，0 failed。
- `python -m unittest test_improvements -v`：28 项通过。
- `workspace/my_opcua/run_protocol_tests.py`：6 项通过，覆盖读写回读、10 次越权拒绝、类型与节点异常、订阅、重启恢复和远程端点拒绝。
- 修改过的 Python 模块通过 compileall 语法检查。
- 真实模型闭环：BLOCKED，当前进程未配置 DEEPSEEK_API_KEY，未调用模型。

环回协议测试需要本地套接字。本轮沙箱阻塞了 Python asyncio 内部 socketpair；已在允许本地环回的环境中完成上述协议测试和完整自检。

验证记录：

- [完整自检日志](workspace/selftest_latest.log)
- [新增回归日志](workspace/improvement_tests_latest.log)
- [OPC UA 协议证据](workspace/my_opcua/evidence/local_protocol_tests.json)
- [OPC UA 当前门禁报告](workspace/my_opcua/traceability_report.md)
- [可视化进度报告](workspace/status/my_opcua.html)
- [环境探测结果](workspace/discovery/latest.json)

本轮只读探测识别到 STM32CubeIDE/ARM GCC、Android SDK/ADB/JDK；没有枚举到串口和支持的 ST-Link/J-Link USB 设备，未识别到 ESP-IDF 框架路径。设备不在这份枚举中不等于已验证所有驱动或接口。

## 当前限制与后续方向

OPC UA 基线仍待客户评审，24 小时长稳、资源曲线和真实 PLC 测试未执行；三个本地 bench 通过项保留本地仿真范围，正式交付门禁仍为 BLOCKED。远程 OPC UA 还需要授权端点和有效固定证书配置。

截图中的交互方向本轮实现为离线 HTML 进度与证据报告。完整 Web/TUI 确认交互、并行子 Agent 调度和生成代码的进程隔离执行仍是后续独立功能；当前测试没有验证这些能力。

## 备份

修改前的源码、文档、工作流及 my_opcua 原基线位于：

`D:\Agent\workspace\improvement_backups\20261110-091830\before.zip`

备份未包含本机 config.yaml 或密钥。项目原先没有 Git 仓库，本轮未擅自初始化仓库或提交。
