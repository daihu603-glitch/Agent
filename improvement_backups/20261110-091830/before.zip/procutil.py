"""跨平台进程执行与路径处理，不使用 shell 拼接命令。"""
from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path, PureWindowsPath


class CommandError(RuntimeError):
    pass


def run_command(
    argv: list[str],
    *,
    cwd: str | Path | None = None,
    env: dict[str, str] | None = None,
    timeout: int = 300,
    max_output: int = 12000,
) -> str:
    if not argv or not all(isinstance(x, str) and x for x in argv):
        raise CommandError("命令参数不能为空")
    try:
        proc = subprocess.run(
            argv,
            cwd=str(cwd) if cwd else None,
            env=env,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
        )
    except FileNotFoundError:
        raise CommandError(f"找不到命令: {argv[0]}") from None
    except subprocess.TimeoutExpired as e:
        stdout = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        raise CommandError(f"命令超时（{timeout}s）: {' '.join(argv)}\n{stdout[-1000:]}") from None
    output = ((proc.stdout or "") + (proc.stderr or "")).strip()
    if len(output) > max_output:
        output = output[:1000] + "\n...(中间输出省略)...\n" + output[-max_output:]
    if proc.returncode:
        raise CommandError(f"命令失败 exit={proc.returncode}: {' '.join(argv)}\n{output}")
    return output or f"命令成功 exit=0: {' '.join(argv)}"


def windows_to_wsl(path: str | Path) -> str:
    raw = str(path)
    match = re.match(r"^([A-Za-z]):[\\/](.*)$", raw)
    if not match:
        return raw.replace("\\", "/")
    drive = match.group(1).lower()
    rest = match.group(2).replace("\\", "/")
    return f"/mnt/{drive}/{rest}"


def existing_dir(path: str | Path, label: str = "目录") -> Path:
    p = Path(path).expanduser().resolve()
    if not p.is_dir():
        raise CommandError(f"{label}不存在: {p}")
    return p


def find_artifact(root: Path, patterns: tuple[str, ...]) -> Path | None:
    candidates = []
    for pattern in patterns:
        candidates.extend(root.rglob(pattern))
    files = [p for p in candidates if p.is_file()]
    return max(files, key=lambda p: p.stat().st_mtime) if files else None
