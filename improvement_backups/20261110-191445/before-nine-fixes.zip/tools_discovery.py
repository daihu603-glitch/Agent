"""Read-only inventory: enumerate devices without opening ports or connecting targets."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import config
from runtime_support import atomic_write
from tools import WORKSPACE, _safe_path, tool


def _probe_usb() -> tuple[list[dict], str]:
    if os.name != "nt":
        return [], "USB debugger enumeration currently requires Windows; serial inventory remains available"
    command = ("Get-PnpDevice -PresentOnly -ErrorAction Stop | "
               "Where-Object { $_.InstanceId -match '^USB\\\\VID_(0483|1366)' } | "
               "Select-Object FriendlyName,InstanceId,Status | ConvertTo-Json -Compress")
    try:
        result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
                                capture_output=True, text=True, errors="replace", timeout=20)
        if result.returncode:
            return [], "Windows USB enumeration unavailable (driver/cmdlet/permissions); debugger presence unknown"
        data = json.loads(result.stdout) if result.stdout.strip() else []
        return data if isinstance(data, list) else [data], ""
    except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError):
        return [], "Windows USB enumeration unavailable; debugger presence unknown"


def inventory() -> dict:
    ports, warnings = [], []
    try:
        from serial.tools import list_ports
        for port in sorted(list_ports.comports(), key=lambda p: p.device):
            ports.append({"device": port.device, "description": port.description,
                          "vid": port.vid, "pid": port.pid})
    except (ImportError, OSError) as error:
        warnings.append(f"Serial enumeration unavailable: {type(error).__name__}")
    usb, warning = _probe_usb()
    if warning:
        warnings.append(warning)
    # Bounded known locations only: never scan an entire disk.
    idf_candidates = [value for value in (config.IDF_PATH, os.environ.get("IDF_PATH")) if value]
    frameworks = Path("C:/Espressif/frameworks")
    if frameworks.is_dir():
        idf_candidates.extend(str(path) for path in sorted(frameworks.glob("esp-idf*"))[:20])
    sdk_paths = {"esp_idf": next((str(Path(p)) for p in idf_candidates if (Path(p) / "tools/idf.py").is_file()), ""),
                 "android_sdk": config.ANDROID_SDK if config.ANDROID_SDK and Path(config.ANDROID_SDK).is_dir() else "",
                 "cubeide": config.CUBEIDE if config.CUBEIDE and Path(config.CUBEIDE).is_dir() else "",
                 "arm_gcc_bin": str(config.get_arm_gcc_bin() or ""),
                 "adb": str(config.get_adb() or ""),
                 "java": str(config.get_java() or ""),
                 "openocd": shutil.which("openocd") or ""}
    return {"scope": "READ_ONLY_DISCOVERY_NOT_DEVICE_VALIDATION", "created_at": datetime.now(timezone.utc).isoformat(),
            "serial_ports": ports, "usb_debuggers": usb, "sdk_paths": sdk_paths, "warnings": warnings,
            "selection": "Select an explicit device before flashing; inventory never opens a port or modifies config.yaml"}


@tool("discover_environment", "只读探测串口、USB 调试器和已安装 SDK，保存 JSON；不打开串口、不连接或烧录目标、不修改配置。",
      {"output_path": {"type": "string", "description": "工作区内 JSON 路径"}}, [])
def discover_environment(output_path: str = "discovery/latest.json") -> str:
    path = _safe_path(output_path)
    if path.suffix.lower() != ".json":
        raise ValueError("探测报告必须使用 .json 后缀")
    report = inventory()
    atomic_write(path, json.dumps(report, ensure_ascii=False, indent=2))
    return json.dumps(report, ensure_ascii=False, indent=2) + f"\n报告: {path}"
