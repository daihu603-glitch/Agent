"""嵌入式、Android、AI 与 OPC UA 产品交付智能体：可插拔模型工具调用循环。

用法：
    python agent.py "检查 RK3588 SDK 环境并给出构建前置条件"
    python agent.py            # 进入交互模式
"""
from __future__ import annotations

import argparse
import importlib
import json
import pkgutil
import sys

from collections.abc import Iterable
from pathlib import Path
from typing import Any

import tools
from config import AGENT_BASE_URL, AGENT_MAX_STEPS, AGENT_MODEL, AGENT_PROVIDER
from model_client import api_key_env, create_model_client, has_api_key, normalize_provider

for module in pkgutil.iter_modules([str(Path(__file__).parent.resolve())]):
    if module.name.startswith("tools_"):
        importlib.import_module(module.name)

MODEL = AGENT_MODEL
MAX_STEPS = AGENT_MAX_STEPS

EMBEDDED_SYSTEM = """你是智能产品全流程开发与交付智能体，支持 STM32、Linux 驱动/应用、ESP32/ESP-IDF、RK3588 SDK、Android APP、AI 智能体应用和 OPC UA 工业互联。

目标是把客户需求转化为可复现、可测试、可验收的交付物，而不是只生成示例代码。

工作原则：
1. 先建立并校验需求规格：每条需求有唯一 ID、量化验收标准、验证方法、设计/代码/测试追踪。需求不明确时列出假设和待客户确认项，不编造已确认事实。
2. 先检查真实 SDK、工具链、原理图、设备树、硬件版本、APP/后端与现有代码，再制定实现方案。区分已验证事实、推断和待办；不声称未执行的编译、部署、模型评测或测试已经成功。
3. STM32：覆盖 CubeMX/HAL、外设、中断/DMA/RTOS、链接脚本、SWD 烧录、HardFault/看门狗定位、资源占用和长时间稳定性。
4. Linux 驱动：覆盖内核模块、设备树、并发/内存/DMA、用户接口、交叉编译、insmod/rmmod、Oops 定位、KASAN/lockdep 和压力测试。Linux 应用覆盖 CMake、IPC、服务部署、日志和异常恢复。
5. ESP32：覆盖 ESP-IDF 组件、FreeRTOS、Wi-Fi/BLE、分区表、NVS、OTA/回滚、功耗、Core Dump、backtrace 和量产安全配置。不自动执行 eFuse 烧写。
6. RK3588：覆盖板级配置、U-Boot/kernel/rootfs、设备树、驱动/应用、MPP/RGA/NPU（按需求）、update.img、Loader/MaskROM 烧录、启动与运行时验收。不同 SDK 版本命令有差异，先读取 build.sh 和文档。
7. Android：覆盖权限、BLE/Wi-Fi 配网、TCP/MQTT、设备管理、OTA、Gradle/自定义构建、Lint/单测/仪器测试、ADB 联调和 APK/AAB 签名验证。安装与仪器测试明确目标设备，不把构建成功冒充真机通过。
8. AI 智能体：模型密钥仅由后端环境变量管理，不进入 APK/前端/仓库。工具按执行层白名单、最小 scopes 和风险等级授权；写/控制/关键操作必须服务端鉴权并人工确认。记忆/RAG 有 ACL、保留删除与提示注入隔离，评测保存逐条真实结果。
9. OPC UA：覆盖信息模型、NodeId、浏览、读写、订阅、会话恢复和证书信任。非环回端点必须显式授权并使用 SignAndEncrypt 与环境变量凭据；写入仅限白名单测试节点并人工确认。本地匿名仿真不代表真实 PLC 或客户验收。
10. 编译失败先读完整错误并最小修复，最多自动重试 3 轮；修复后必须重新构建。调试保留与固件完全一致的 ELF/map/vmlinux/symbols。
11. 烧录、远程部署、ADB 安装、加载/卸载驱动、OPC UA 真实端点连接与写入、控制执行器、真实模型评测、长时间压力测试和正式交付必须设置确认门禁。不执行高风险系统清除或不可逆安全熔断操作。
12. 测试必须与运行版本绑定。功能、接口、异常、断电恢复、通信重连、长时间运行和资源泄漏按需求执行；失败就记录 fail，不允许改写结果凑通过。
13. 最终用 traceability_report 和 check_delivery_gate 检查。只有所有需求 pass、证据完整且交付包哈希校验通过，才可报告“具备客户交付条件”；缺少硬件/SDK/客户验收时明确报告阻塞项。
14. 所有输出用中文，操作结论简洁，证据保存到 workspace。
"""

DEFAULT_SYSTEM = EMBEDDED_SYSTEM


def _attr(value: Any, name: str, default: Any = None) -> Any:
    return value.get(name, default) if isinstance(value, dict) else getattr(value, name, default)


def _serialize_block(block: Any) -> dict:
    if isinstance(block, dict):
        return dict(block)
    if hasattr(block, "model_dump"):
        return block.model_dump(mode="json")
    block_type = _attr(block, "type", "")
    if block_type == "text":
        return {"type": "text", "text": _attr(block, "text", "")}
    if block_type == "tool_use":
        return {
            "type": "tool_use",
            "id": _attr(block, "id", ""),
            "name": _attr(block, "name", ""),
            "input": dict(_attr(block, "input", {}) or {}),
        }
    raise ValueError(f"不支持的模型响应块: {type(block).__name__}")


class Agent:
    def __init__(
        self,
        system: str = DEFAULT_SYSTEM,
        model: str = MODEL,
        verbose: bool = True,
        allowed_tools: Iterable[str] | None = None,
        max_steps: int | None = None,
        client: Any = None,
        provider: str = AGENT_PROVIDER,
    ):
        self.provider = normalize_provider(provider)
        self.system = system
        self.model = model
        if not str(self.model).strip():
            raise ValueError("模型名称不能为空；请设置 agent.model 或 AGENT_MODEL")
        self.client = client if client is not None else create_model_client(self.provider)
        self.verbose = verbose
        self.allowed_tools = frozenset(allowed_tools) if allowed_tools is not None else None
        self.max_steps = max(1, int(max_steps or MAX_STEPS))
        self.messages: list[dict] = []
        self.tool_calls: list[dict] = []
        self.usage = {"input_tokens": 0, "output_tokens": 0}
        self.last_status = "idle"
        self.last_error = ""

    def run(self, task: str) -> str:
        if not task.strip():
            self.last_status = "failed"
            self.last_error = "任务不能为空"
            return "AGENT_ERROR: 任务不能为空"
        self.messages.append({"role": "user", "content": task})
        self.tool_calls = []
        self.usage = {"input_tokens": 0, "output_tokens": 0}
        self.last_status = "running"
        self.last_error = ""

        for step in range(1, self.max_steps + 1):
            try:
                resp = self.client.messages.create(
                    model=self.model,
                    max_tokens=8192,
                    system=self.system,
                    tools=tools.schemas(self.allowed_tools),
                    messages=self.messages,
                )
                usage = _attr(resp, "usage", {})
                self.usage["input_tokens"] += _attr(usage, "input_tokens", 0) or 0
                self.usage["output_tokens"] += _attr(usage, "output_tokens", 0) or 0
                content = list(_attr(resp, "content", []) or [])
                serialized = [_serialize_block(block) for block in content]
                self.messages.append({"role": "assistant", "content": serialized})
                json.dumps(self.messages, ensure_ascii=False)
            except Exception as e:
                self.last_status = "failed"
                self.last_error = f"{type(e).__name__}: {e}"
                return f"AGENT_ERROR: {self.last_error}"

            stop_reason = _attr(resp, "stop_reason", "")
            if stop_reason != "tool_use":
                text = "".join(str(_attr(block, "text", "")) for block in content if _attr(block, "type") == "text")
                if not text.strip():
                    self.last_status = "failed"
                    self.last_error = f"模型未返回文本，stop_reason={stop_reason or 'unknown'}"
                    return f"AGENT_ERROR: {self.last_error}"
                if stop_reason not in {"", "end_turn", "stop_sequence"}:
                    self.last_status = "failed"
                    self.last_error = f"模型响应未完整结束: {stop_reason}"
                    return text + f"\nAGENT_ERROR: {self.last_error}"
                self.last_status = "completed"
                return text

            results = []
            for block in content:
                if _attr(block, "type") != "tool_use":
                    continue
                name = str(_attr(block, "name", ""))
                arguments = dict(_attr(block, "input", {}) or {})
                call = {"name": name, "arguments": arguments, "result": ""}
                self.tool_calls.append(call)
                if self.verbose:
                    print(f"  [步骤 {step}] 调用 {name}({arguments})")
                out = tools.run_tool(name, arguments, allowed_tools=self.allowed_tools) or "(工具无输出)"
                call["result"] = out
                if self.verbose:
                    print(f"           -> {out[:160]!r}")
                results.append({"type": "tool_result", "tool_use_id": _attr(block, "id", ""), "content": out})
            if not results:
                self.last_status = "failed"
                self.last_error = "stop_reason=tool_use，但响应中没有工具调用"
                return f"AGENT_ERROR: {self.last_error}"
            self.messages.append({"role": "user", "content": results})

        self.last_status = "max_steps"
        self.last_error = f"已达到最大步数 {self.max_steps}"
        return f"AGENT_MAX_STEPS: 已达到最大步数 {self.max_steps}，任务未完成；不能视为验收通过"

    def reset(self):
        self.messages.clear()
        self.tool_calls = []
        self.usage = {"input_tokens": 0, "output_tokens": 0}
        self.last_status = "idle"
        self.last_error = ""


def _doctor() -> str:
    from tools_opcua import opcua_environment_check
    lines = [
        "AGENT_DOCTOR",
        f"Python: {sys.version.split()[0]}",
        f"模型提供商: {AGENT_PROVIDER}",
        f"模型: {MODEL}",
        f"接口地址: {AGENT_BASE_URL or '(SDK 默认)'}",
        f"密钥环境变量: {api_key_env()}",
        f"API Key: {'已配置' if has_api_key() else '未配置（仅真实模型调用需要）'}",
        f"最大步数: {MAX_STEPS}",
        f"工具数: {len(tools.schemas())}",
        f"工作区: {tools.WORKSPACE}",
        "项目根: " + (", ".join(f"{name}={path}" for name, path in tools._PROJECT_ROOTS.items()) or "未注册"),
    ]
    return "\n".join(lines) + "\n" + opcua_environment_check()


def main() -> int:
    parser = argparse.ArgumentParser(description="智能产品全流程开发与交付智能体")
    parser.add_argument("task", nargs="*", help="要执行的任务；留空进入交互模式")
    parser.add_argument("--doctor", action="store_true", help="检查本地配置，不调用模型")
    parser.add_argument("--list-tools", action="store_true", help="列出已注册工具，不调用模型")
    parser.add_argument("--project-root", action="append", default=[], help="授权项目目录，格式 path 或 name=path，可重复")
    args = parser.parse_args()
    try:
        for item in args.project_root:
            name, separator, path = item.partition("=")
            tools.register_project_root(path if separator else item, name if separator else "")
    except ValueError as e:
        print(f"错误：{e}", file=sys.stderr)
        return 2
    if args.list_tools:
        print("\n".join(schema["name"] for schema in tools.schemas()))
        return 0
    if args.doctor:
        print(_doctor())
        return 0
    if not has_api_key():
        print(f"请先设置环境变量 {api_key_env()}；离线检查可运行 --doctor 或 selftest.py", file=sys.stderr)
        return 2

    agent = Agent()
    if args.task:
        print(agent.run(" ".join(args.task)))
        return 0 if agent.last_status == "completed" else 1

    print("智能产品交付智能体已就绪（输入 quit 退出）。")
    print(f"已注册 {len(tools.schemas())} 个工具，支持嵌入式 / Android APP / AI 智能体应用 / OPC UA。")
    while True:
        try:
            task = input("\n你> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not task or task.lower() in ("quit", "exit", "q"):
            break
        print("\n" + agent.run(task))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
