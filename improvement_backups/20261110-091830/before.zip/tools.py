"""工具注册表：每个工具 = JSON Schema 描述 + Python 实现。

新增工具只需用 @tool 装饰一个函数，智能体会自动识别。
所有文件操作被限制在 WORKSPACE 目录内，避免越权读写。
"""
from __future__ import annotations

import ast
import ipaddress
import json
import operator
import os
import socket
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable, Iterable

from config import AGENT_PROJECT_ROOTS, AGENT_WORKSPACE

_BASE_DIR = Path(__file__).resolve().parent
WORKSPACE = Path(os.environ.get("AGENT_WORKSPACE", AGENT_WORKSPACE)).resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)

_REGISTRY: dict[str, dict[str, Any]] = {}
_PROJECT_ROOTS: dict[str, Path] = {}


def register_project_root(path: str, name: str = "") -> str:
    root = Path(path).expanduser().resolve()
    if not root.is_dir():
        raise ValueError(f"项目目录不存在: {root}")
    root_name = name or root.name or "project"
    if root_name in _PROJECT_ROOTS and _PROJECT_ROOTS[root_name] != root:
        raise ValueError(f"项目根名称已注册: {root_name}")
    _PROJECT_ROOTS[root_name] = root
    return root_name


for index, configured_root in enumerate(os.environ.get("AGENT_PROJECT_ROOTS", "").split(os.pathsep), 1):
    if configured_root.strip():
        register_project_root(configured_root, f"project{index}")
for configured_root in AGENT_PROJECT_ROOTS:
    register_project_root(str(configured_root))


def tool(name: str, description: str, properties: dict, required: list[str]):
    """注册一个工具。"""

    def deco(fn: Callable[..., str]):
        _REGISTRY[name] = {
            "schema": {
                "name": name,
                "description": description,
                "input_schema": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
            "fn": fn,
        }
        return fn

    return deco


def _safe_path(rel: str) -> Path:
    p = (WORKSPACE / rel).resolve()
    if WORKSPACE not in p.parents and p != WORKSPACE:
        raise ValueError(f"路径越出工作区: {rel}")
    return p


@tool(
    "read_file",
    "读取工作区内的文本文件。",
    {"path": {"type": "string", "description": "相对工作区的路径"}},
    ["path"],
)
def read_file(path: str) -> str:
    with _safe_path(path).open("r", encoding="utf-8") as f:
        content = f.read(20001)
    return content[:20000] + ("\n...(内容已截断)" if len(content) > 20000 else "")


@tool(
    "write_file",
    "写入（覆盖）工作区内的文本文件，自动创建父目录。",
    {
        "path": {"type": "string", "description": "相对工作区的路径"},
        "content": {"type": "string", "description": "文件内容"},
    },
    ["path", "content"],
)
def write_file(path: str, content: str) -> str:
    p = _safe_path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {path}（{len(content)} 字符）"


@tool(
    "list_files",
    "列出工作区内的文件。",
    {"subdir": {"type": "string", "description": "子目录，默认根目录"}},
    [],
)
def list_files(subdir: str = ".") -> str:
    base = _safe_path(subdir)
    return "\n".join(
        str(p.relative_to(WORKSPACE)) for p in sorted(base.rglob("*")) if p.is_file()
    ) or "(空)"


_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.USub: operator.neg,
}


def _eval(node: ast.AST, depth: int = 0) -> float:
    if depth > 20:
        raise ValueError("表达式嵌套过深")
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        left = _eval(node.left, depth + 1)
        right = _eval(node.right, depth + 1)
        if isinstance(node.op, ast.Pow) and (abs(left) > 1e100 or abs(right) > 100):
            raise ValueError("幂运算超出资源限制")
        return _OPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.operand, depth + 1))
    raise ValueError("仅支持数字和 + - * / ** % 运算")


@tool(
    "calculator",
    "安全计算数学表达式，例如 '(3.3*2+1)/4'。",
    {"expression": {"type": "string"}},
    ["expression"],
)
def calculator(expression: str) -> str:
    if len(expression) > 200:
        raise ValueError("表达式最多 200 字符")
    tree = ast.parse(expression, mode="eval")
    if sum(1 for _ in ast.walk(tree)) > 64:
        raise ValueError("表达式节点过多")
    return str(_eval(tree.body))


def _validate_http_url(url: str) -> urllib.parse.SplitResult:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("只允许有效的 http(s) 地址")
    if parsed.username or parsed.password:
        raise ValueError("URL 不允许携带凭据")
    if os.environ.get("AGENT_HTTP_ALLOW_PRIVATE") == "1":
        return parsed
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    addresses = socket.getaddrinfo(parsed.hostname, port, type=socket.SOCK_STREAM)
    for address in addresses:
        ip = ipaddress.ip_address(address[4][0])
        if not ip.is_global:
            raise ValueError(f"拒绝访问非公网地址: {ip}")
    return parsed


class _SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_http_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


@tool(
    "http_get",
    "抓取公网网页或 API 文本，拒绝内网/环回地址，限制重定向和响应大小。",
    {"url": {"type": "string", "description": "以 http(s):// 开头的公网地址"}},
    ["url"],
)
def http_get(url: str) -> str:
    _validate_http_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": "product-agent/1.0"})
    opener = urllib.request.build_opener(_SafeRedirectHandler())
    with opener.open(req, timeout=15) as response:
        payload = response.read(65537)
    text = payload[:65536].decode("utf-8", errors="replace")
    return text[:8000] + ("\n...(内容已截断)" if len(payload) > 65536 or len(text) > 8000 else "")


def _project_path(root: str, path: str) -> tuple[Path, Path]:
    if root not in _PROJECT_ROOTS:
        raise ValueError(f"项目根未注册: {root}；请通过 --project-root 或 AGENT_PROJECT_ROOTS 明确授权")
    base = _PROJECT_ROOTS[root]
    candidate = (base / path).resolve()
    if base != candidate and base not in candidate.parents:
        raise ValueError(f"路径越出项目根: {path}")
    return base, candidate


@tool(
    "project_read_file",
    "读取已明确注册的项目根目录内的文本文件。",
    {"root": {"type": "string"}, "path": {"type": "string", "description": "相对项目根的路径"}},
    ["root", "path"],
)
def project_read_file(root: str, path: str) -> str:
    _, candidate = _project_path(root, path)
    with candidate.open("r", encoding="utf-8") as f:
        content = f.read(20001)
    return content[:20000] + ("\n...(内容已截断)" if len(content) > 20000 else "")


@tool(
    "project_write_file",
    "写入已明确注册的项目根目录内的文本文件，自动创建父目录。",
    {"root": {"type": "string"}, "path": {"type": "string"}, "content": {"type": "string"}},
    ["root", "path", "content"],
)
def project_write_file(root: str, path: str, content: str) -> str:
    _, candidate = _project_path(root, path)
    candidate.parent.mkdir(parents=True, exist_ok=True)
    candidate.write_text(content, encoding="utf-8")
    return f"已写入项目文件 {root}/{path}（{len(content)} 字符）"


@tool(
    "project_list_files",
    "列出已明确注册的项目根目录内的文件，最多 500 项。",
    {"root": {"type": "string"}, "subdir": {"type": "string"}},
    ["root"],
)
def project_list_files(root: str, subdir: str = ".") -> str:
    base, candidate = _project_path(root, subdir)
    files = [p.relative_to(base).as_posix() for p in sorted(candidate.rglob("*")) if p.is_file()]
    return "\n".join(files[:500]) + ("\n...(文件列表已截断)" if len(files) > 500 else "") if files else "(空)"


def schemas(allowed_tools: Iterable[str] | None = None) -> list[dict]:
    allowed = set(allowed_tools) if allowed_tools is not None else None
    return [t["schema"] for name, t in _REGISTRY.items() if allowed is None or name in allowed]


def run_tool(name: str, args: dict, allowed_tools: Iterable[str] | None = None) -> str:
    """执行工具；任何异常都转成文本返回给模型，让它自己纠错。"""
    if allowed_tools is not None and name not in set(allowed_tools):
        return f"错误：工具 {name} 不在当前权限白名单内，已拒绝执行"
    if name not in _REGISTRY:
        return f"错误：未知工具 {name}"
    try:
        return str(_REGISTRY[name]["fn"](**args))
    except Exception as e:  # noqa: BLE001
        return f"工具执行出错：{type(e).__name__}: {e}"


if __name__ == "__main__":
    print(json.dumps(schemas(), ensure_ascii=False, indent=2))
