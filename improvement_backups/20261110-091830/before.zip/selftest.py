"""离线自检：不调用真实模型 API、外部 SDK/SSH、烧录器或目标硬件；OPC UA 使用环回仿真。"""
from __future__ import annotations

import copy
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).parent.resolve()
os.environ.setdefault("AGENT_WORKSPACE", str(ROOT / "workspace"))
sys.path.insert(0, str(ROOT))

import tools
import agent
import model_client
import tools_requirements as req
import tools_delivery as delivery
import tools_esp32 as esp32
import tools_debug as debug
import tools_linux as linux
import tools_ai_agent as ai
import tools_android as android
import tools_remote as remote
import tools_flash as flash
import tools_build as build
import tools_test as hardware_test
import tools_stm32 as stm32
import tools_vcs as vcs
import tools_ioc as ioc
import tools_opcua as opcua
from tools_knowledge import query_knowledge
from tools import WORKSPACE

passed = []
failed = []


def check(name: str, condition: bool, detail: str = ""):
    if condition:
        passed.append(name)
        print(f"PASS {name}")
    else:
        failed.append(f"{name}: {detail}")
        print(f"FAIL {name}: {detail}")


def main() -> int:
    check("工具注册数量", len(tools.schemas()) >= 81, str(len(tools.schemas())))
    names = {s["name"] for s in tools.schemas()}
    expected = {
        "build_linux_driver", "build_linux_app", "build_rk3588", "device_driver_test",
        "validate_esp32_partitions", "stm32_fault_snapshot", "package_delivery", "traceability_report",
        "build_android_app", "android_instrumented_test", "adb_install_apk", "verify_android_artifact",
        "validate_agent_design", "agent_tool_audit", "run_agent_eval", "check_ai_backend_security",
        "opcua_browse", "opcua_read", "opcua_write", "opcua_subscribe", "opcua_run_demo",
    }
    check("多平台关键工具", expected <= names, str(expected - names))
    check("白名单仅暴露指定 schema", [s["name"] for s in tools.schemas(["calculator"])] == ["calculator"])
    denied = tools.run_tool("calculator", {"expression": "1+1"}, allowed_tools={"read_file"})
    allowed = tools.run_tool("calculator", {"expression": "1+1"}, allowed_tools={"calculator"})
    check("执行层拒绝白名单外工具", "已拒绝执行" in denied and allowed == "2", denied)

    import yaml
    import io
    from contextlib import redirect_stdout
    from workflow import run_workflow
    workflow_files = list((ROOT / "workflows").glob("*.yaml"))
    for file in workflow_files:
        try:
            spec = yaml.safe_load(file.read_text(encoding="utf-8"))
            ids = [s["id"] for s in spec["steps"]]
            valid = len(ids) == len(set(ids)) and all(s.get("task") for s in spec["steps"])
            with redirect_stdout(io.StringIO()):
                dry_steps = run_workflow(str(file), {}, dry_run=True)
            check(f"工作流 {file.name}", valid and len(dry_steps) == len(ids))
        except Exception as e:
            check(f"工作流 {file.name}", False, str(e))

    test_root = WORKSPACE / "selftest"
    if test_root.exists():
        shutil.rmtree(test_root)
    test_root.mkdir(parents=True)

    class FakeMessages:
        def __init__(self, responses):
            self.responses = list(responses)
            self.calls = []

        def create(self, **kwargs):
            self.calls.append(copy.deepcopy(kwargs))
            response = self.responses.pop(0)
            if isinstance(response, Exception):
                raise response
            return response

    def response(content, stop_reason):
        return SimpleNamespace(content=content, stop_reason=stop_reason, usage=SimpleNamespace(input_tokens=3, output_tokens=2))

    tool_block = SimpleNamespace(type="tool_use", id="call-1", name="calculator", input={"expression": "6*7"})
    final_block = SimpleNamespace(type="text", text="计算结果是 42")
    fake_client = SimpleNamespace(messages=FakeMessages([
        response([tool_block], "tool_use"),
        response([final_block], "end_turn"),
    ]))
    offline_agent = agent.Agent(client=fake_client, verbose=False, allowed_tools=["calculator"])
    answer = offline_agent.run("计算 6*7")
    check("模拟模型完整工具调用闭环", answer == "计算结果是 42" and offline_agent.last_status == "completed" and offline_agent.tool_calls[0]["result"] == "42", answer)
    check("Agent 消息可 JSON 序列化", bool(json.dumps(offline_agent.messages, ensure_ascii=False)) and offline_agent.messages[-1]["content"][0]["text"] == "计算结果是 42")
    check("Agent 使用量累计", offline_agent.usage == {"input_tokens": 6, "output_tokens": 4}, str(offline_agent.usage))
    api_error_agent = agent.Agent(client=SimpleNamespace(messages=FakeMessages([RuntimeError("offline-api-error")])), verbose=False)
    check("API 异常明确失败", "AGENT_ERROR" in api_error_agent.run("test") and api_error_agent.last_status == "failed")
    looping_client = SimpleNamespace(messages=FakeMessages([response([tool_block], "tool_use")]))
    limited_agent = agent.Agent(client=looping_client, verbose=False, allowed_tools=["calculator"], max_steps=1)
    check("最大步数不等于完成", limited_agent.run("loop").startswith("AGENT_MAX_STEPS") and limited_agent.last_status == "max_steps")
    empty_agent = agent.Agent(client=SimpleNamespace(messages=FakeMessages([response([], "end_turn")])), verbose=False)
    check("空模型响应明确失败", empty_agent.run("empty").startswith("AGENT_ERROR") and empty_agent.last_status == "failed")

    def openai_response(content="", tool_calls=None, finish_reason="stop", choices=True):
        message = SimpleNamespace(content=content, tool_calls=tool_calls or [])
        choice_list = [SimpleNamespace(message=message, finish_reason=finish_reason)] if choices else []
        return SimpleNamespace(choices=choice_list, usage=SimpleNamespace(prompt_tokens=5, completion_tokens=3))

    openai_tool_call = SimpleNamespace(id="openai-call-1", function=SimpleNamespace(name="calculator", arguments='{"expression":"6*7"}'))
    openai_fake = SimpleNamespace(chat=SimpleNamespace(completions=FakeMessages([
        openai_response(tool_calls=[openai_tool_call], finish_reason="tool_calls"),
        openai_response(content="计算结果是 42"),
    ])))
    compatible_agent = agent.Agent(client=model_client.OpenAICompatibleClient(openai_fake), provider="deepseek", verbose=False, allowed_tools=["calculator"])
    compatible_answer = compatible_agent.run("计算 6*7")
    check("OpenAI 兼容完整工具调用闭环", compatible_answer == "计算结果是 42" and compatible_agent.last_status == "completed" and compatible_agent.tool_calls[0]["result"] == "42", compatible_answer)
    first_request = openai_fake.chat.completions.calls[0]
    second_request = openai_fake.chat.completions.calls[1]
    check("OpenAI 工具 schema 转换", first_request["tools"][0]["type"] == "function" and first_request["tools"][0]["function"]["name"] == "calculator" and "input_schema" not in first_request["tools"][0]["function"], str(first_request["tools"]))
    roles = [message["role"] for message in second_request["messages"]]
    check("OpenAI 多轮消息转换", roles == ["system", "user", "assistant", "tool"] and second_request["messages"][2]["tool_calls"][0]["id"] == "openai-call-1" and second_request["messages"][3]["content"] == "42", str(second_request["messages"]))
    check("OpenAI 使用量与结束原因转换", compatible_agent.usage == {"input_tokens": 10, "output_tokens": 6} and compatible_agent.messages[1]["content"][0]["type"] == "tool_use", str(compatible_agent.usage))
    invalid_json_agent = agent.Agent(client=model_client.OpenAICompatibleClient(SimpleNamespace(chat=SimpleNamespace(completions=FakeMessages([
        openai_response(tool_calls=[SimpleNamespace(id="bad-json", function=SimpleNamespace(name="calculator", arguments="{bad"))], finish_reason="tool_calls"),
    ])))), provider="deepseek", verbose=False)
    check("OpenAI 非法工具 JSON 明确失败", "arguments 不是合法 JSON" in invalid_json_agent.run("bad") and invalid_json_agent.last_status == "failed")
    no_choices_agent = agent.Agent(client=model_client.OpenAICompatibleClient(SimpleNamespace(chat=SimpleNamespace(completions=FakeMessages([openai_response(choices=False)])))), provider="deepseek", verbose=False)
    check("OpenAI 空 choices 明确失败", "缺少 choices" in no_choices_agent.run("empty") and no_choices_agent.last_status == "failed")
    try:
        model_client.normalize_provider("unknown-provider")
        provider_rejected = False
    except ValueError:
        provider_rejected = True
    check("未知模型提供商明确拒绝", provider_rejected)
    with patch.object(model_client.config, "AGENT_API_KEY_ENV", "sk-invalid-secret-like-value"):
        try:
            model_client.api_key_env()
            secret_env_rejected = False
        except ValueError:
            secret_env_rejected = True
    check("api_key_env 禁止误填密钥", secret_env_rejected)
    with patch.dict(os.environ, {"DEEPSEEK_API_KEY": "offline-dummy-key"}, clear=False):
        doctor_text = agent._doctor()
    check("doctor 显示提供商且不回显密钥", "deepseek" in doctor_text and "DEEPSEEK_API_KEY" in doctor_text and "offline-dummy-key" not in doctor_text, doctor_text)

    workflow_path = test_root / "workflow_failure.yaml"
    workflow_path.write_text("name: failure-test\nvars: {}\nsteps:\n  - id: first\n    task: first task\n  - id: second\n    task: second task\n", encoding="utf-8")

    class FailedWorkflowAgent:
        instances = 0

        def __init__(self, system):
            FailedWorkflowAgent.instances += 1
            self.last_status = "failed"

        def run(self, prompt):
            return "AGENT_ERROR: offline workflow failure"

    with redirect_stdout(io.StringIO()):
        workflow_result = run_workflow(str(workflow_path), {"api_token": "offline-secret-value"}, agent_factory=FailedWorkflowAgent, return_result=True)
    state_text = Path(workflow_result["state_file"]).read_text(encoding="utf-8")
    check("工作流失败立即中止并保存", workflow_result["status"] == "failed" and FailedWorkflowAgent.instances == 1 and "second" not in workflow_result["steps"], str(workflow_result))
    check("工作流状态脱敏与指纹", "offline-secret-value" not in state_text and "***REDACTED***" in state_text and "workflow_sha256" in state_text, state_text)
    saved_state = workflow_result["state_file"]
    workflow_path.write_text(workflow_path.read_text(encoding="utf-8") + "\n# changed\n", encoding="utf-8")
    try:
        run_workflow(str(workflow_path), {}, resume_file=saved_state, agent_factory=FailedWorkflowAgent)
        fingerprint_rejected = False
    except ValueError as e:
        fingerprint_rejected = "内容已变化" in str(e)
    check("工作流变化禁止旧状态续跑", fingerprint_rejected)

    ssrf = tools.run_tool("http_get", {"url": "http://127.0.0.1/admin"})
    check("HTTP 拒绝环回 SSRF", "非公网地址" in ssrf, ssrf)
    tools.register_project_root(str(test_root), "selftest-source")
    check("注册项目根受控写入", "已写入" in tools.project_write_file("selftest-source", "src/main.c", "int main(void){return 0;}\n"))
    check("注册项目根读取", "return 0" in tools.project_read_file("selftest-source", "src/main.c"))
    escaped_write = tools.run_tool("project_write_file", {"root": "selftest-source", "path": "../escaped.txt", "content": "bad"})
    check("项目根阻止路径逃逸", "越出项目根" in escaped_write and not (WORKSPACE / "escaped.txt").exists(), escaped_write)
    check("计算器限制资源消耗", "资源限制" in tools.run_tool("calculator", {"expression": "2**999999"}))

    design_path = ROOT / "agent_design.example.yaml"
    eval_path = ROOT / "agent_eval.example.yaml"
    check("AI 智能体设计示例", "AGENT_DESIGN_PASS" in ai.validate_agent_design(str(design_path)))
    check("AI 工具权限审计", "AGENT_TOOL_AUDIT_PASS" in ai.agent_tool_audit(str(design_path), "calculator,query_knowledge"))
    check("AI 未声明高危工具拒绝", "AGENT_TOOL_AUDIT_FAILED" in ai.agent_tool_audit(str(design_path), "flash_firmware"))
    design_data = yaml.safe_load(design_path.read_text(encoding="utf-8"))
    design_data["tools"][-1]["confirmation_required"] = False
    design_errors, _ = ai._validate_design(design_data)
    check("AI 控制工具必须确认", any("必须人工确认" in error for error in design_errors), str(design_errors))
    eval_data = yaml.safe_load(eval_path.read_text(encoding="utf-8"))
    _, eval_errors = ai._eval_cases(eval_data)
    check("AI 评测示例校验", not eval_errors, str(eval_errors))
    unsafe_eval = dict(eval_data)
    unsafe_eval["cases"] = [dict(eval_data["cases"][0], allowed_tools=["flash_firmware"])]
    _, unsafe_errors = ai._eval_cases(unsafe_eval)
    check("AI 评测禁止硬件工具", bool(unsafe_errors), str(unsafe_errors))
    missing_key_name = "AGENT_SELFTEST_MISSING_KEY"
    previous_key = os.environ.pop(missing_key_name, None)
    try:
        with patch.object(ai.config, "AGENT_API_KEY_ENV", missing_key_name):
            no_key_eval = ai.run_agent_eval(str(eval_path), output_path="selftest/should_not_create_eval.json")
    finally:
        if previous_key is not None:
            os.environ[missing_key_name] = previous_key
    check("无 Key 不执行模型评测", "AGENT_EVAL_FAILED" in no_key_eval and missing_key_name in no_key_eval and not (test_root / "should_not_create_eval.json").exists(), no_key_eval)

    eval_smoke_path = test_root / "eval_smoke.yaml"
    eval_smoke_path.write_text("min_pass_rate: 1.0\ncases:\n  - id: smoke\n    input: offline\n    expected_keywords: [ok]\n    allowed_tools: [calculator]\n", encoding="utf-8")

    class FakeEvalAgent:
        response = "ok"
        status = "completed"

        def __init__(self, **kwargs):
            self.last_status = self.status
            self.tool_calls = []
            self.usage = {"input_tokens": 1, "output_tokens": 1}

        def run(self, task):
            return self.response

    with patch.object(ai.config, "AGENT_API_KEY_ENV", missing_key_name), patch.dict(os.environ, {missing_key_name: "offline-dummy-key"}), patch.object(agent, "Agent", FakeEvalAgent):
        eval_smoke = ai.run_agent_eval(str(eval_smoke_path), output_path="selftest/eval_smoke.json")
    eval_smoke_report = json.loads((test_root / "eval_smoke.json").read_text(encoding="utf-8"))
    check("多模型评测保存提供商证据", "AGENT_EVAL_PASS" in eval_smoke and eval_smoke_report["provider"] == ai.config.AGENT_PROVIDER and eval_smoke_report["model"] == ai.config.AGENT_MODEL, eval_smoke)

    class FailedEvalAgent(FakeEvalAgent):
        response = "AGENT_ERROR: ok"
        status = "failed"

    with patch.object(ai.config, "AGENT_API_KEY_ENV", missing_key_name), patch.dict(os.environ, {missing_key_name: "offline-dummy-key"}), patch.object(agent, "Agent", FailedEvalAgent):
        failed_eval = ai.run_agent_eval(str(eval_smoke_path), output_path="selftest/eval_failed.json")
    failed_eval_report = json.loads((test_root / "eval_failed.json").read_text(encoding="utf-8"))
    check("评测 Agent 错误不能按关键词误判通过", "AGENT_EVAL_FAILED" in failed_eval and failed_eval_report["results"][0]["status"] == "fail" and bool(failed_eval_report["aborted"]), failed_eval)

    insecure = test_root / "ai_backend"
    insecure.mkdir()
    dummy_secret = "offline-dummy-secret-123"
    (insecure / "demo.py").write_text(f'api_key = "{dummy_secret}"\n' + "subprocess.run(cmd, shell=" + "True)\n", encoding="utf-8")
    audit = ai.check_ai_backend_security(str(insecure), output_path="selftest/ai_security_audit.json")
    check("AI 后端静态安全扫描", "AI_SECURITY_AUDIT_FAILED" in audit and (test_root / "ai_security_audit.json").is_file(), audit)
    check("安全扫描不回显秘密", dummy_secret not in audit)
    check("APP/AI 知识库", "BLE" in query_knowledge("android_app", "platforms") and "RAG" in query_knowledge("ai_agent", "platforms"))

    fresh_apk = test_root / "fresh.apk"
    old_apk = test_root / "old.apk"
    fresh_apk.write_bytes(b"fresh")
    old_apk.write_bytes(b"old")
    os.utime(old_apk, (1, 1))
    fresh_artifacts = android._new_artifacts(test_root, fresh_apk.stat().st_mtime)
    check("Android 只选择本次新产物", fresh_artifacts == [fresh_apk], str(fresh_artifacts))
    check("Android 仪器测试要求明确设备", "必须明确 serial" in android.android_instrumented_test(str(test_root), ""))

    spec_rel = "selftest/requirements.yaml"
    requirements = json.dumps([{
        "id": "FR-001", "title": "版本查询", "acceptance": "发送 version 100 次均在 1 秒内返回 0.1.0，错误数为 0", "method": "hil_test"
    }], ensure_ascii=False)
    result = req.create_requirement_spec("selftest", "stm32", requirements, output_path=spec_rel)
    check("创建需求规格", "已创建" in result, result)
    escaped_spec = req.create_requirement_spec("escape", "stm32", requirements, output_path="../escaped-requirements.yaml")
    check("需求输出阻止路径逃逸", "越出工作区" in escaped_spec and not (WORKSPACE.parent / "escaped-requirements.yaml").exists(), escaped_spec)
    check("需求规格校验", "校验通过" in req.validate_requirements(spec_rel))
    check("初始交付门禁阻塞", "DELIVERY_BLOCKED" in delivery.check_delivery_gate(spec_rel))
    result = req.update_traceability(spec_rel, "FR-001", design="design.md#version", code="Core/Src/main.c", tests="TEST-VERSION-100")
    check("更新追踪", "已更新" in result, result)
    check("无验收仍阻塞", "DELIVERY_BLOCKED" in delivery.check_delivery_gate(spec_rel))
    evidence = test_root / "version_test.log"
    evidence.write_text("100/100 version responses matched 0.1.0\n", encoding="utf-8")
    result = req.record_acceptance_result(spec_rel, "FR-001", "pass", evidence="selftest/version_test.log", notes="离线自检模拟证据，仅测试门禁逻辑")
    check("记录验收", "pass" in result, result)
    check("追踪报告", "DELIVERY" in req.traceability_report(spec_rel) or "交付门禁: PASS" in req.traceability_report(spec_rel))
    check("完整交付门禁", "DELIVERY_PASS" in delivery.check_delivery_gate(spec_rel))
    missing_result = req.record_acceptance_result(spec_rel, "FR-001", "pass", evidence="selftest/missing.log")
    check("缺失证据禁止记录 pass", "证据文件不存在" in missing_result, missing_result)
    notes_only = req.record_acceptance_result(spec_rel, "FR-001", "pass", evidence="", notes="仅说明")
    check("notes 不能替代 pass 证据", "不能用 notes 替代" in notes_only, notes_only)
    results_file = test_root / "acceptance_results.yaml"
    valid_results = results_file.read_text(encoding="utf-8")
    tampered_results = yaml.safe_load(valid_results)
    tampered_results["results"]["FR-001"]["evidence"] = "selftest/missing.log"
    results_file.write_text(yaml.safe_dump(tampered_results, allow_unicode=True), encoding="utf-8")
    check("缺失证据文件阻塞交付", "DELIVERY_BLOCKED" in delivery.check_delivery_gate(spec_rel))
    results_file.write_text(valid_results, encoding="utf-8")
    req.record_acceptance_result(spec_rel, "FR-001", "pass", evidence="selftest/version_test.log", notes="离线自检模拟证据，仅测试门禁逻辑")

    artifact = test_root / "firmware.bin"
    artifact.write_bytes(b"offline-selftest-firmware")
    result = delivery.package_delivery(spec_rel, "0.1.0", str(artifact), output_dir="selftest/delivery")
    check("生成交付包", "交付包已生成" in result, result)
    zips = list((test_root / "delivery").glob("*.zip"))
    check("交付 ZIP 唯一", len(zips) == 1, str(zips))
    if zips:
        check("交付包哈希验证", "校验通过" in delivery.verify_delivery_package(str(zips[0])))
    comma_artifact = test_root / "firmware,revA.bin"
    comma_artifact.write_bytes(b"comma-path")
    comma_result = delivery.package_delivery(spec_rel, "0.1.1", json.dumps([str(comma_artifact)]), output_dir="selftest/comma_delivery")
    check("交付支持含逗号 JSON 路径", "交付包已生成" in comma_result, comma_result)
    duplicate_a = test_root / "duplicate-a"
    duplicate_b = test_root / "duplicate-b"
    duplicate_a.mkdir()
    duplicate_b.mkdir()
    (duplicate_a / "same.bin").write_bytes(b"a")
    (duplicate_b / "same.bin").write_bytes(b"b")
    duplicate_result = delivery.package_delivery(spec_rel, "0.1.2", json.dumps([str(duplicate_a / "same.bin"), str(duplicate_b / "same.bin")]), output_dir="selftest/duplicate_delivery")
    check("交付拒绝同名产物覆盖", "同名" in duplicate_result and not (test_root / "duplicate_delivery").exists(), duplicate_result)
    malicious_zip = test_root / "malicious.zip"
    with zipfile.ZipFile(malicious_zip, "w") as zf:
        zf.writestr("malicious/manifest.json", json.dumps({"files": [], "delivery_gate": "PASS", "project": {"name": "bad"}}))
        zf.writestr("malicious/../evil.txt", "bad")
    malicious_zip.with_suffix(".zip.sha256").write_text(f"{delivery._sha256(malicious_zip)}  malicious.zip\n", encoding="utf-8")
    check("交付校验拒绝 ZIP 路径穿越", "非法路径" in delivery.verify_delivery_package(str(malicious_zip)))

    blocked_spec = "selftest/blocked_requirements.yaml"
    req.create_requirement_spec("blocked", "esp32", requirements, output_path=blocked_spec)
    result = delivery.package_delivery(blocked_spec, "0.1.0", str(artifact), output_dir="selftest/blocked_delivery")
    check("未验收禁止打包", "DELIVERY_BLOCKED" in result and not (test_root / "blocked_delivery").exists(), result)

    partitions = test_root / "partitions.csv"
    partitions.write_text("# Name,Type,SubType,Offset,Size\nnvs,data,nvs,0x9000,0x6000\notadata,data,ota,0xf000,0x2000\nota_0,app,ota_0,0x20000,1M\nota_1,app,ota_1,0x120000,1M\n", encoding="utf-8")
    result = esp32.validate_esp32_partitions(str(partitions), "4MB")
    check("ESP32 分区校验", "通过" in result, result)
    bad = test_root / "bad_partitions.csv"
    bad.write_text("a,app,ota_0,0x20000,1M\nb,app,ota_1,0x21000,1M\n", encoding="utf-8")
    check("ESP32 重叠检测", "重叠" in esp32.validate_esp32_partitions(str(bad), "4MB"))

    log = "HardFault: CFSR=0x00008200 pc=0x08001234"
    check("HardFault 日志诊断", "addr2line" in debug.analyze_embedded_log(log, "stm32"))
    check("ESP32 日志诊断", "Backtrace" in debug.analyze_embedded_log("Guru Meditation Error\nBacktrace: 0x42001234", "esp32"))

    driver = test_root / "demo.c"
    driver.write_text("#include <linux/module.h>\nstatic int __init x(void){return 0;}\nmodule_init(x);\n", encoding="utf-8")
    check("Linux 驱动静态检查", "扫描" in linux.linux_driver_static_check(str(driver)))

    dangerous_remote = [
        remote.device_run("ip link set eth0 down"),
        remote.device_run("find /tmp -delete"),
        remote.device_run("dmesg -C"),
        remote.device_run("journalctl --rotate"),
    ]
    check("SSH 只读白名单拒绝危险子命令", all("错误" in result for result in dangerous_remote), str(dangerous_remote))
    quoted_fw = test_root / "fw [rev]$1.bin"
    quoted_fw.write_bytes(b"firmware")
    with patch.object(flash.subprocess, "run", return_value=SimpleNamespace(returncode=0, stdout="ok", stderr="")) as mocked_flash:
        openocd_result = flash.flash_firmware(str(quoted_fw), method="openocd", chip="STM32F103VE")
    command_argv = mocked_flash.call_args.args[0]
    program_command = command_argv[command_argv.index("-c") + 1]
    check("OpenOCD 固件路径 Jim 引用", openocd_result.startswith("OpenOCD 烧录成功") and program_command.startswith("program {") and "$1" in program_command, program_command)
    check("OpenOCD 芯片配置不匹配拒绝", "不匹配" in flash.flash_firmware(str(quoted_fw), method="openocd", chip="STM32F407VG"))
    check("UART 未实现不会误报烧录成功", flash.flash_firmware(str(quoted_fw), method="uart").startswith("错误：UART"))

    fake_idf = test_root / "fake-idf"
    (fake_idf / "tools").mkdir(parents=True)
    (fake_idf / "tools" / "idf.py").write_text("# offline mock\n", encoding="utf-8")
    esp_project = test_root / "esp-build-project"
    esp_project.mkdir()
    with patch.object(build.config, "IDF_PATH", str(fake_idf)), patch.object(build.subprocess, "run", return_value=SimpleNamespace(returncode=1, stdout="", stderr="target failed")) as mocked_build:
        target_failure = build.build_esp32(str(esp_project), target="esp32s3")
    check("ESP32 set-target 失败禁止继续构建", "已禁止继续构建" in target_failure and mocked_build.call_count == 1, target_failure)

    old_project = test_root / "old-firmware-project"
    old_project.mkdir()
    (old_project / "old.hex").write_bytes(b"old")
    with patch.object(build, "build_project", return_value="编译成功。"), patch.object(flash, "flash_firmware", return_value="烧录成功: old") as mocked_old_flash:
        old_firmware_result = hardware_test.run_build_test(str(old_project), "[]")
    check("构建测试拒绝烧录旧固件", "旧固件" in old_firmware_result and mocked_old_flash.call_count == 0, old_firmware_result)

    class FakeSerial:
        def __init__(self, responses=(), write_error=None):
            self.responses = list(responses)
            self.write_error = write_error

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def reset_input_buffer(self):
            pass

        def write(self, data):
            if self.write_error:
                raise self.write_error
            return len(data)

        def flush(self):
            pass

        def readline(self):
            return self.responses.pop(0) if self.responses else b""

    delayed_serial = FakeSerial([b"first line\n", b"", b"second EXPECTED line\n"])
    with patch.object(hardware_test.serial, "Serial", return_value=delayed_serial):
        delayed_result = hardware_test.run_serial_test(json.dumps([{"cmd": "query", "expect": "EXPECTED"}]), port="COM99", timeout=1)
    check("串口等待延迟多行响应", "PASS" in delayed_result and "second EXPECTED" in delayed_result, delayed_result)
    disconnected_serial = FakeSerial(write_error=debug.serial.SerialException("offline disconnect"))
    with patch.object(debug.serial, "Serial", return_value=disconnected_serial):
        aborted_stress = debug.run_stress_test("cycle", "OK", 3, report_name="selftest_aborted.json")
    aborted_report = json.loads((WORKSPACE / "test_reports" / "selftest_aborted.json").read_text(encoding="utf-8"))
    check("压力测试断线保存 ABORTED 证据", "ABORTED" in aborted_stress and aborted_report["executed_cycles"] == 0 and aborted_report["error"], aborted_stress)

    from procutil import CommandError
    with patch.object(stm32, "run_command", side_effect=[CommandError("read failed"), "resumed"]) as mocked_snapshot:
        snapshot_result = stm32.stm32_fault_snapshot(resume=True)
    check("故障采集失败仍独立 resume", mocked_snapshot.call_count == 2 and "resume" in mocked_snapshot.call_args.args[0] and "故障快照失败" in snapshot_result, snapshot_result)
    with patch.object(vcs.subprocess, "run", return_value=SimpleNamespace(returncode=128, stdout="", stderr="not a git repository")):
        check("非 Git 目录不误报干净", "错误：git status 失败" in vcs.git_status(str(test_root)))
    ioc_dir = test_root / "ioc"
    ioc_dir.mkdir()
    (ioc_dir / "other-board.ioc").write_text("Mcu.Pins=0\n", encoding="utf-8")
    check("IOC 缺失不自动替换板卡", "不会自动替换" in ioc.parse_ioc(str(ioc_dir / "missing.ioc")))

    ota_project = test_root / "ota_project"
    ota_build = ota_project / "build"
    (ota_build / "bootloader").mkdir(parents=True)
    (ota_build / "partition_table").mkdir()
    (ota_build / "ota_data").mkdir()
    (ota_build / "demo.bin").write_bytes(b"app")
    (ota_build / "bootloader" / "bootloader.bin").write_bytes(b"boot")
    (ota_build / "partition_table" / "partition-table.bin").write_bytes(b"part")
    (ota_build / "ota_data" / "ota_data_initial.bin").write_bytes(b"ota")
    (ota_build / "flasher_args.json").write_text(json.dumps({
        "app": {"file": "demo.bin"},
        "flash_args": {"0x0": "bootloader/bootloader.bin", "0x8000": "partition_table/partition-table.bin", "0xd000": "ota_data/ota_data_initial.bin", "0x10000": "demo.bin"},
    }), encoding="utf-8")
    (ota_project / "sdkconfig").write_text('CONFIG_IDF_TARGET="esp32s3"\n', encoding="utf-8")
    ota_result = esp32.prepare_esp32_ota(str(ota_project), "1.0.0", output_dir="selftest/ota_output")
    check("ESP32 OTA 收集标准子目录产物", "OTA 发布文件已准备" in ota_result and all((test_root / "ota_output" / name).is_file() for name in ("app.bin", "bootloader.bin", "partition-table.bin", "ota_data_initial.bin")), ota_result)

    from procutil import windows_to_wsl
    check("WSL 路径转换", windows_to_wsl("D:/Agent/project") == "/mnt/d/Agent/project")

    project_file = test_root / "project.yaml"
    project_file.write_text("project:\n  name: selftest\n  version: 0.1.0\n  platform: stm32\n  requirement_spec: requirements.yaml\n  source_dir: ''\nhardware:\n  serial_port: COM99\nbuild:\n  jobs: 4\n", encoding="utf-8")
    from product import _project, _vars
    loaded_path, loaded = _project(str(project_file))
    project_vars = _vars(loaded_path, loaded)
    check("项目启动器变量", project_vars["spec_path"] == str(test_root / "requirements.yaml") and project_vars["serial_port"] == "COM99", str(project_vars))

    android_project_file = test_root / "project_android.yaml"
    android_project_file.write_text(
        "project:\n  name: android-selftest\n  version: 1.0.0\n  platform: android_app\n  requirement_spec: android_requirements.yaml\n  source_dir: ''\n"
        "hardware:\n  android_serial: emulator-5554\nbuild:\n  method: custom\n  gradle_task: assembleRelease\n",
        encoding="utf-8",
    )
    android_path, android_data = _project(str(android_project_file))
    android_vars = _vars(android_path, android_data)
    check(
        "Android 项目启动器变量",
        android_vars["build_method"] == "custom" and android_vars["gradle_task"] == "assembleRelease" and android_vars["android_serial"] == "emulator-5554",
        str(android_vars),
    )
    android_spec = req.create_requirement_spec("android-selftest", "android_app", requirements, output_path="selftest/android_requirements.yaml")
    check("Android 需求平台接入", "已创建" in android_spec and "校验通过" in req.validate_requirements("selftest/android_requirements.yaml"), android_spec)

    opc_project_file = test_root / "project_opcua.yaml"
    opc_project_file.write_text(
        "project:\n  name: opcua-selftest\n  version: 1.0.0\n  platform: opc_ua\n  requirement_spec: opcua_requirements.yaml\n  source_dir: ''\n",
        encoding="utf-8",
    )
    opc_path, opc_data = _project(str(opc_project_file))
    opc_data["_config_path"] = str(opc_path)
    from product import doctor
    opc_doctor = doctor(opc_data)
    check("OPC UA 项目入口与环境检查", "OPCUA_ENVIRONMENT_CHECK" in opc_doctor and _vars(opc_path, opc_data)["spec_path"] == str(test_root / "opcua_requirements.yaml"), opc_doctor)
    opc_spec = req.create_requirement_spec("opcua-selftest", "opc_ua", requirements, output_path="selftest/opcua_requirements.yaml")
    opc_knowledge = query_knowledge("opc_ua", "platforms")
    check("OPC UA 需求平台与知识库", "已创建" in opc_spec and "校验通过" in req.validate_requirements("selftest/opcua_requirements.yaml") and "SignAndEncrypt" in opc_knowledge, opc_spec)

    demo_endpoint = str(opcua.config.opcua_cfg["demo_endpoint"])
    demo_result = opcua.opcua_run_demo(output_path="selftest/opcua_demo.json")
    demo_evidence = json.loads((test_root / "opcua_demo.json").read_text(encoding="utf-8"))
    check(
        "OPC UA 环回真实协议集成",
        demo_result.startswith("OPCUA_DEMO_PASS") and demo_evidence["status"] == "PASS" and all(demo_evidence["checks"].values()),
        demo_result,
    )
    unconfirmed_write = opcua.opcua_write(demo_endpoint, "ns=2;s=Demo.Setpoint", "25.5", False)
    check("OPC UA 未确认写入拒绝", "必须显式 confirmed=true" in unconfirmed_write, unconfirmed_write)
    unauthorized_write = opcua.opcua_write(demo_endpoint, "ns=2;s=Demo.Temperature", "21.0", True)
    check("OPC UA 白名单外写入拒绝", "不在 opcua.writable_nodes" in unauthorized_write, unauthorized_write)
    with patch.object(opcua.socket, "getaddrinfo", return_value=[(2, 1, 6, "", ("192.0.2.1", 4840))]):
        remote_read = opcua.opcua_read("opc.tcp://192.0.2.1:4840", "i=85")
    check("OPC UA 未授权远程 endpoint 拒绝", "必须在 opcua.allowed_endpoints" in remote_read, remote_read)
    remote_config = copy.deepcopy(opcua.config.opcua_cfg)
    remote_config.update({"allowed_endpoints": ["opc.tcp://192.0.2.1:4840"], "security_policy": "Basic256Sha256"})
    with (
        patch.object(opcua.config, "opcua_cfg", remote_config),
        patch.object(opcua.socket, "getaddrinfo", return_value=[(2, 1, 6, "", ("192.0.2.1", 4840))]),
        patch.dict(os.environ, {"OPCUA_USERNAME": "offline-user", "OPCUA_PASSWORD": "offline-password"}),
    ):
        unpinned_read = opcua.opcua_read("opc.tcp://192.0.2.1:4840", "i=85")
    check("OPC UA 远程缺少固定服务器证书拒绝", "固定 server_certificate" in unpinned_read, unpinned_read)

    print(f"\n自检完成: {len(passed)} passed, {len(failed)} failed")
    if failed:
        print("\n".join(failed))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
