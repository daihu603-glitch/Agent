"""OPC UA 本地演示、受限客户端读写、浏览和数据变化订阅。"""
from __future__ import annotations

import asyncio
import ipaddress
import json
import os
import socket
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from tools import _safe_path, tool
import config

try:
    from asyncua import Client, Server, ua
    from asyncua.common.utils import ServiceError
    HAS_ASYNCUA = True
except ImportError:
    HAS_ASYNCUA = False


def _run(coro):
    return asyncio.run(coro)


def _endpoint(endpoint: str) -> tuple[str, bool]:
    parsed = urlsplit(endpoint)
    if parsed.scheme != "opc.tcp" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("仅允许不含 URL 凭据的 opc.tcp endpoint")
    try:
        port = parsed.port or 4840
        addresses = socket.getaddrinfo(parsed.hostname, port, type=socket.SOCK_STREAM)
    except (ValueError, socket.gaierror) as e:
        raise ValueError(f"OPC UA endpoint 地址无效: {e}") from None
    loopback = bool(addresses) and all(ipaddress.ip_address(item[4][0]).is_loopback for item in addresses)
    allowed = {str(item).rstrip("/") for item in config.opcua_cfg.get("allowed_endpoints", [])}
    if not loopback and endpoint.rstrip("/") not in allowed:
        raise ValueError("非环回 OPC UA endpoint 必须在 opcua.allowed_endpoints 中显式配置")
    return endpoint, loopback


def _credentials() -> tuple[str, str]:
    username = os.environ.get(str(config.opcua_cfg.get("username_env", "OPCUA_USERNAME")), "")
    password = os.environ.get(str(config.opcua_cfg.get("password_env", "OPCUA_PASSWORD")), "")
    return username, password


async def _validate_server_certificate(certificate, _application_description):
    now = datetime.now(timezone.utc)
    if now < certificate.not_valid_before_utc or now > certificate.not_valid_after_utc:
        raise ServiceError(ua.StatusCodes.BadCertificateTimeInvalid)


async def _client(endpoint: str, timeout: float):
    endpoint, loopback = _endpoint(endpoint)
    demo_endpoint = str(config.opcua_cfg.get("demo_endpoint", "")).rstrip("/")
    if endpoint.rstrip("/") == demo_endpoint:
        return Client(endpoint, timeout=timeout)
    policy = str(config.opcua_cfg.get("security_policy", "None"))
    username, password = _credentials()
    if not loopback and (policy == "None" or not username or not password):
        raise ValueError("远程 OPC UA 必须同时启用证书 SignAndEncrypt 和环境变量用户名/密码")
    client = Client(endpoint, timeout=timeout)
    if policy != "None":
        certificate = str(config.opcua_cfg.get("certificate", ""))
        private_key = str(config.opcua_cfg.get("private_key", ""))
        server_certificate = str(config.opcua_cfg.get("server_certificate", ""))
        if not all(Path(path).is_file() for path in (certificate, private_key, server_certificate)):
            raise ValueError("OPC UA 加密模式需要存在的 certificate、private_key 和固定 server_certificate")
        await client.set_security_string(f"{policy},SignAndEncrypt,{certificate},{private_key},{server_certificate}")
        client.certificate_validator = _validate_server_certificate
    if username:
        client.set_user(username)
    if password:
        client.set_password(password)
    return client


@asynccontextmanager
async def _connected(endpoint: str, timeout: float):
    client = await _client(endpoint, timeout)
    async with client:
        yield client


async def _browse_async(endpoint: str, node_id: str, max_nodes: int, timeout: float) -> list[dict[str, str]]:
    async with _connected(endpoint, timeout) as client:
        node = client.get_node(node_id)
        children = await node.get_children()
        rows = []
        for child in children[:max_nodes]:
            display = await child.read_display_name()
            rows.append({
                "node_id": child.nodeid.to_string(),
                "name": display.Text or child.nodeid.to_string(),
                "class": str(await child.read_node_class()),
            })
        return rows


async def _read_async(endpoint: str, node_id: str, timeout: float) -> Any:
    async with _connected(endpoint, timeout) as client:
        return await client.get_node(node_id).read_value()


async def _write_async(endpoint: str, node_id: str, value_json: str, confirmed: bool, timeout: float) -> Any:
    if not confirmed:
        raise ValueError("OPC UA 写操作必须显式 confirmed=true，并在工作流中保留人工确认")
    if node_id not in set(config.opcua_cfg.get("writable_nodes", [])):
        raise ValueError(f"节点不在 opcua.writable_nodes 白名单: {node_id}")
    try:
        value = json.loads(value_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"value_json 无效: {e}") from None
    if isinstance(value, (dict, list)) or value is None:
        raise ValueError("当前写工具仅支持布尔、数字和字符串标量")
    async with _connected(endpoint, timeout) as client:
        node = client.get_node(node_id)
        variant_type = await node.read_data_type_as_variant_type()
        await node.write_value(ua.DataValue(ua.Variant(value, variant_type)))
        return await node.read_value()


class _ChangeCollector:
    def __init__(self):
        self.changes: list[dict[str, Any]] = []

    def datachange_notification(self, node, value, data):
        self.changes.append({
            "node_id": node.nodeid.to_string(),
            "value": value,
            "recorded_at": datetime.now(timezone.utc).isoformat(),
        })


async def _subscribe_async(endpoint: str, node_id: str, period_ms: int, duration: float, timeout: float) -> list[dict[str, Any]]:
    collector = _ChangeCollector()
    async with _connected(endpoint, timeout) as client:
        subscription = await client.create_subscription(period_ms, collector)
        handle = await subscription.subscribe_data_change(client.get_node(node_id))
        try:
            await asyncio.sleep(duration)
        finally:
            await subscription.unsubscribe(handle)
            await subscription.delete()
    return collector.changes


@tool(
    "opcua_environment_check",
    "检查 asyncua、环回演示 endpoint、远程加密配置和写节点白名单，不连接真实设备。",
    {},
    [],
)
def opcua_environment_check() -> str:
    demo = str(config.opcua_cfg.get("demo_endpoint", ""))
    lines = [f"asyncua: {'已安装' if HAS_ASYNCUA else '未安装'}", f"demo_endpoint: {demo or '未配置'}"]
    if demo:
        try:
            _, loopback = _endpoint(demo)
            lines.append(f"演示 endpoint 环回检查: {'PASS' if loopback else 'FAIL'}")
        except ValueError as e:
            lines.append(f"演示 endpoint 检查: FAIL ({e})")
    lines.append(f"远程 endpoint 白名单: {len(config.opcua_cfg.get('allowed_endpoints', []))} 个")
    lines.append(f"写节点白名单: {len(config.opcua_cfg.get('writable_nodes', []))} 个")
    lines.append(f"security_policy: {config.opcua_cfg.get('security_policy', 'None')}（None 仅应用于本地匿名演示）")
    server_certificate = str(config.opcua_cfg.get("server_certificate", ""))
    lines.append(f"固定服务器证书: {'文件已配置' if Path(server_certificate).is_file() else '未配置或文件不存在（远程连接受阻）'}")
    lines.append("凭据: 只从 OPCUA_USERNAME/OPCUA_PASSWORD 或配置的环境变量名读取，不显示内容")
    lines.append("边界: 本地仿真通过不代表真实 PLC、设备或客户验收通过")
    return "OPCUA_ENVIRONMENT_CHECK\n" + "\n".join(lines)


@tool(
    "opcua_browse",
    "浏览 OPC UA 节点的直接子节点。非环回 endpoint 必须显式授权并使用证书加密。",
    {
        "endpoint": {"type": "string"}, "node_id": {"type": "string", "description": "默认 i=85（Objects）"},
        "max_nodes": {"type": "integer"}, "timeout": {"type": "number"},
    },
    ["endpoint"],
)
def opcua_browse(endpoint: str, node_id: str = "i=85", max_nodes: int = 100, timeout: float = 5) -> str:
    if not HAS_ASYNCUA:
        return "OPCUA_ERROR: 未安装 asyncua"
    try:
        rows = _run(_browse_async(endpoint, node_id, max(1, min(max_nodes, 500)), min(max(timeout, 1), 30)))
        return "OPCUA_BROWSE_OK\n" + (json.dumps(rows, ensure_ascii=False, indent=2) if rows else "(无子节点)")
    except Exception as e:
        return f"OPCUA_ERROR: {type(e).__name__}: {e}"


@tool(
    "opcua_read",
    "读取一个 OPC UA 节点值。只允许环回或明确配置的加密 endpoint。",
    {"endpoint": {"type": "string"}, "node_id": {"type": "string"}, "timeout": {"type": "number"}},
    ["endpoint", "node_id"],
)
def opcua_read(endpoint: str, node_id: str, timeout: float = 5) -> str:
    if not HAS_ASYNCUA:
        return "OPCUA_ERROR: 未安装 asyncua"
    try:
        value = _run(_read_async(endpoint, node_id, min(max(timeout, 1), 30)))
        return f"OPCUA_READ_OK\nnode_id={node_id}\nvalue={json.dumps(value, ensure_ascii=False, default=str)}"
    except Exception as e:
        return f"OPCUA_ERROR: {type(e).__name__}: {e}"


@tool(
    "opcua_write",
    "写入白名单 OPC UA 标量节点并回读核验。必须 confirmed=true，value_json 例如 25.5、true 或 \"auto\"。",
    {
        "endpoint": {"type": "string"}, "node_id": {"type": "string"}, "value_json": {"type": "string"},
        "confirmed": {"type": "boolean"}, "timeout": {"type": "number"},
    },
    ["endpoint", "node_id", "value_json", "confirmed"],
)
def opcua_write(endpoint: str, node_id: str, value_json: str, confirmed: bool = False, timeout: float = 5) -> str:
    if not HAS_ASYNCUA:
        return "OPCUA_ERROR: 未安装 asyncua"
    try:
        value = _run(_write_async(endpoint, node_id, value_json, confirmed, min(max(timeout, 1), 30)))
        return f"OPCUA_WRITE_OK\nnode_id={node_id}\nreadback={json.dumps(value, ensure_ascii=False, default=str)}"
    except Exception as e:
        return f"OPCUA_ERROR: {type(e).__name__}: {e}"


@tool(
    "opcua_subscribe",
    "订阅 OPC UA 数据变化并保存证据。无变化不能标记测试通过，时长最多 60 秒。",
    {
        "endpoint": {"type": "string"}, "node_id": {"type": "string"}, "period_ms": {"type": "integer"},
        "duration": {"type": "number"}, "timeout": {"type": "number"},
        "output_path": {"type": "string", "description": "相对工作区 JSON 路径"},
    },
    ["endpoint", "node_id"],
)
def opcua_subscribe(endpoint: str, node_id: str, period_ms: int = 200, duration: float = 5, timeout: float = 5, output_path: str = "opcua/subscription.json") -> str:
    if not HAS_ASYNCUA:
        return "OPCUA_ERROR: 未安装 asyncua"
    try:
        changes = _run(_subscribe_async(endpoint, node_id, max(50, min(period_ms, 10000)), min(max(duration, 0.2), 60), min(max(timeout, 1), 30)))
        report = {
            "scope": "PROTOCOL_TEST_NOT_CUSTOMER_ACCEPTANCE",
            "endpoint": endpoint,
            "node_id": node_id,
            "changes": changes,
            "recorded_at": datetime.now(timezone.utc).isoformat(),
        }
        out = _safe_path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        status = "OPCUA_SUBSCRIPTION_OK" if changes else "OPCUA_SUBSCRIPTION_EMPTY"
        return f"{status}\n变化 {len(changes)} 次\n证据: {out}"
    except Exception as e:
        return f"OPCUA_ERROR: {type(e).__name__}: {e}"


async def _create_demo_server():
    endpoint = str(config.opcua_cfg.get("demo_endpoint", "opc.tcp://127.0.0.1:4840/agent/demo"))
    _, loopback = _endpoint(endpoint)
    if not loopback:
        raise ValueError("内置匿名演示服务器只允许绑定环回 endpoint")
    server = Server()
    server.set_security_policy([ua.SecurityPolicyType.NoSecurity])
    server.set_identity_tokens([ua.AnonymousIdentityToken])
    await server.init()
    server.set_endpoint(endpoint)
    server.set_server_name("Product Agent Local OPC UA Demo")
    namespace = await server.register_namespace("urn:qoder:product-agent:demo")
    device = await server.nodes.objects.add_object(ua.NodeId("DemoDevice", namespace), "DemoDevice")
    temperature = await device.add_variable(ua.NodeId("Demo.Temperature", namespace), "Demo.Temperature", 20.0)
    setpoint = await device.add_variable(ua.NodeId("Demo.Setpoint", namespace), "Demo.Setpoint", 20.0)
    await temperature.set_writable(False)
    await setpoint.set_writable()
    return server, endpoint, namespace, temperature, setpoint


async def _demo_async() -> dict[str, Any]:
    server, endpoint, namespace, temperature, setpoint = await _create_demo_server()
    evidence: dict[str, Any] = {
        "scope": "LOCAL_SIMULATION_NOT_DEVICE_OR_CUSTOMER_ACCEPTANCE",
        "security": "ANONYMOUS_LOOPBACK_ONLY",
        "endpoint": endpoint,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    await server.start()
    try:
        async with _connected(endpoint, 5) as client:
            evidence["browse"] = await _browse_async(endpoint, "i=85", 20, 5)
            evidence["initial_temperature"] = await client.get_node(f"ns={namespace};s=Demo.Temperature").read_value()
            setpoint_id = f"ns={namespace};s=Demo.Setpoint"
            evidence["setpoint_before"] = await client.get_node(setpoint_id).read_value()
            evidence["setpoint_after"] = await _write_async(endpoint, setpoint_id, "25.5", True, 5)

            collector = _ChangeCollector()
            subscription = await client.create_subscription(100, collector)
            handle = await subscription.subscribe_data_change(client.get_node(f"ns={namespace};s=Demo.Temperature"))
            try:
                for value in (21.0, 22.0):
                    await temperature.write_value(value)
                    await asyncio.sleep(0.25)
            finally:
                await subscription.unsubscribe(handle)
                await subscription.delete()
            evidence["subscription_changes"] = collector.changes
    finally:
        await server.stop()
    checks = {
        "browse": any(row["name"] == "DemoDevice" for row in evidence.get("browse", [])),
        "read": evidence.get("initial_temperature") == 20.0,
        "write_readback": evidence.get("setpoint_after") == 25.5,
        "subscription": any(change["value"] == 22.0 for change in evidence.get("subscription_changes", [])),
    }
    evidence["checks"] = checks
    evidence["status"] = "PASS" if all(checks.values()) else "FAIL"
    evidence["finished_at"] = datetime.now(timezone.utc).isoformat()
    return evidence


@tool(
    "opcua_run_demo",
    "启动环回匿名 OPC UA 演示服务器，实际执行客户端浏览、读取、白名单写入回读和订阅，保存本地仿真证据。",
    {"output_path": {"type": "string", "description": "相对工作区 JSON 路径"}},
    [],
)
def opcua_run_demo(output_path: str = "opcua/demo_evidence.json") -> str:
    if not HAS_ASYNCUA:
        return "OPCUA_DEMO_FAIL: 未安装 asyncua，请安装 requirements.txt"
    try:
        evidence = _run(_demo_async())
    except Exception as e:
        evidence = {
            "scope": "LOCAL_SIMULATION_NOT_DEVICE_OR_CUSTOMER_ACCEPTANCE",
            "status": "FAIL",
            "error": f"{type(e).__name__}: {e}",
            "recorded_at": datetime.now(timezone.utc).isoformat(),
        }
    try:
        out = _safe_path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as e:
        return f"OPCUA_DEMO_FAIL: 保存证据失败: {e}"
    summary = json.dumps(evidence.get("checks", {}), ensure_ascii=False)
    return f"OPCUA_DEMO_{evidence['status']}\n检查: {summary}\n证据: {out}\n仅证明本地 OPC UA 协议栈与工具链，不代表真实 PLC/设备验收。"


async def _serve_demo():
    server, endpoint, namespace, temperature, _ = await _create_demo_server()
    await server.start()
    print(f"OPC UA 本地匿名演示服务器: {endpoint}")
    print(f"温度节点: ns={namespace};s=Demo.Temperature")
    print(f"可写设定节点: ns={namespace};s=Demo.Setpoint")
    print("仅限环回；Ctrl+C 停止。不能用于生产或真实设备验收。")
    try:
        value = 20.0
        while True:
            value = 20.0 if value >= 30.0 else value + 0.5
            await temperature.write_value(value)
            await asyncio.sleep(1)
    finally:
        await server.stop()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "server":
        if not HAS_ASYNCUA:
            raise SystemExit("请先安装 asyncua")
        try:
            _run(_serve_demo())
        except KeyboardInterrupt:
            pass
    else:
        print(opcua_run_demo())
