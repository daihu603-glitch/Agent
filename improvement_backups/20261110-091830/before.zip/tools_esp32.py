"""ESP-IDF 分区、固件尺寸、OTA 发布包和运行时诊断。"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
from pathlib import Path

from tools import tool, _safe_path
from procutil import CommandError, existing_dir, run_command
import config


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _size(value: str) -> int:
    value = value.strip().lower().replace("bytes", "").replace("byte", "").strip()
    if value.endswith("b"):
        value = value[:-1]
    try:
        if value.endswith("m"):
            return int(float(value[:-1]) * 1024 * 1024)
        if value.endswith("k"):
            return int(float(value[:-1]) * 1024)
        return int(value, 0)
    except ValueError:
        raise ValueError(f"无法解析大小: {value}") from None


@tool(
    "validate_esp32_partitions",
    "校验 ESP-IDF partitions.csv 的偏移、大小、重叠、对齐、app 子类型和 OTA 双分区容量。",
    {"csv_path": {"type": "string"}, "flash_size": {"type": "string", "description": "如 8MB/16MB"}},
    ["csv_path"],
)
def validate_esp32_partitions(csv_path: str, flash_size: str = "") -> str:
    p = Path(csv_path).resolve()
    if not p.is_file():
        return f"错误：分区表不存在: {p}"
    flash = _size(flash_size or config.esp32_cfg.get("flash_size", "8MB").replace("B", ""))
    entries = []
    errors = []
    try:
        with p.open(encoding="utf-8-sig", newline="") as f:
            for line_no, row in enumerate(csv.reader(f), 1):
                if not row or row[0].lstrip().startswith("#"):
                    continue
                row = [c.strip() for c in row]
                if len(row) < 5:
                    errors.append(f"第 {line_no} 行字段不足")
                    continue
                name, kind, subtype, offset, size = row[:5]
                try:
                    off = _size(offset) if offset else (entries[-1]["end"] if entries else 0)
                    sz = _size(size)
                except ValueError as e:
                    errors.append(f"第 {line_no} 行: {e}")
                    continue
                if sz <= 0:
                    errors.append(f"{name}: 大小必须大于 0")
                if kind == "app" and off % 0x10000:
                    errors.append(f"{name}: app 分区偏移必须 64KB 对齐")
                entries.append({"name": name, "type": kind, "subtype": subtype, "offset": off, "size": sz, "end": off + sz})
    except (OSError, UnicodeError) as e:
        return f"错误：读取分区表失败: {e}"
    entries.sort(key=lambda x: x["offset"])
    for prev, curr in zip(entries, entries[1:]):
        if curr["offset"] < prev["end"]:
            errors.append(f"分区重叠: {prev['name']} 与 {curr['name']}")
    for e in entries:
        if e["end"] > flash:
            errors.append(f"{e['name']} 超出 Flash 容量 {flash} bytes")
    apps = [e for e in entries if e["type"] == "app"]
    ota = [e for e in apps if e["subtype"] in {"ota_0", "ota_1"}]
    if ota and len(ota) < 2:
        errors.append("配置 OTA 时需要 ota_0 和 ota_1 两个 app 分区")
    if len(ota) >= 2 and ota[0]["size"] != ota[1]["size"]:
        errors.append("ota_0/ota_1 大小不一致，需确认升级布局")
    lines = [f"{e['name']}: 0x{e['offset']:08x}-0x{e['end']:08x} {e['type']}/{e['subtype']} {e['size']} bytes" for e in entries]
    if errors:
        return "分区表校验失败:\n" + "\n".join(f"- {e}" for e in errors) + "\n\n" + "\n".join(lines)
    return f"分区表静态校验通过，共 {len(entries)} 个分区，Flash {flash} bytes:\n" + "\n".join(lines)


@tool(
    "esp32_size",
    "运行 idf.py size/size-components，分析 Flash/IRAM/DRAM 占用，保留 app.elf 和 map 用于 backtrace。",
    {"project_dir": {"type": "string"}, "components": {"type": "boolean"}},
    ["project_dir"],
)
def esp32_size(project_dir: str, components: bool = False) -> str:
    try:
        proj = existing_dir(project_dir, "ESP-IDF 项目")
        idf_path = config.IDF_PATH
        if not idf_path:
            return "错误：未配置 ESP-IDF 路径"
        idf_py = Path(idf_path) / "tools" / "idf.py"
        env = os.environ.copy()
        env["IDF_PATH"] = idf_path
        args = ["python", str(idf_py), "size-components" if components else "size"]
        output = run_command(args, cwd=proj, env=env, timeout=120, max_output=12000)
        elf = proj / "build" / f"{proj.name}.elf"
        return f"{output}\nELF: {elf} ({'存在，请随测试证据归档' if elf.exists() else '未按默认名称找到，请检查 build 目录'})"
    except CommandError as e:
        return f"ESP32 尺寸分析失败: {e}"


@tool(
    "prepare_esp32_ota",
    "从 ESP-IDF build 目录准备 OTA 发布文件与 manifest，记录应用版本、目标芯片和 SHA256。不执行上传或升级。",
    {
        "project_dir": {"type": "string"}, "version": {"type": "string"},
        "output_dir": {"type": "string", "description": "相对工作区输出目录"},
        "include_flash_images": {"type": "boolean", "description": "是否同时收集 bootloader/partition-table 用于整包烧录"},
    },
    ["project_dir", "version"],
)
def prepare_esp32_ota(project_dir: str, version: str, output_dir: str = "esp32_ota", include_flash_images: bool = True) -> str:
    try:
        proj = existing_dir(project_dir, "ESP-IDF 项目")
    except CommandError as e:
        return str(e)
    build = proj / "build"
    flasher_path = build / "flasher_args.json"
    try:
        flasher = json.loads(flasher_path.read_text(encoding="utf-8")) if flasher_path.is_file() else {}
    except (OSError, json.JSONDecodeError) as e:
        return f"错误：flasher_args.json 无效: {e}"
    app_file = str(flasher.get("app", {}).get("file", ""))
    app = (build / app_file).resolve() if app_file else build / f"{proj.name}.bin"
    if build.resolve() not in app.parents:
        return "错误：app.file 路径越出 build 目录"
    if not app.is_file():
        candidates = [p for p in build.glob("*.bin") if p.name not in {"bootloader.bin", "partition-table.bin", "ota_data_initial.bin"}]
        if len(candidates) == 1:
            app = candidates[0]
        elif len(candidates) > 1:
            return "错误：应用 bin 不唯一，请在 flasher_args.json 的 app.file 中明确指定"
    if not app.is_file():
        return f"错误：未找到应用 bin，请先 idf.py build: {app}"
    try:
        out = _safe_path(output_dir)
    except ValueError as e:
        return f"错误：{e}"
    if out.exists():
        return f"错误：输出目录已存在，避免覆盖旧版本: {out}"

    sdkconfig = proj / "sdkconfig"
    target = ""
    if sdkconfig.is_file():
        for line in sdkconfig.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith('CONFIG_IDF_TARGET="'):
                target = line.split('"', 2)[1]
                break
    if not target:
        return "错误：无法从项目 sdkconfig 确认实际目标芯片，禁止生成目标不明的 OTA 包"

    files = {"app": app}
    if include_flash_images:
        flash_args = flasher.get("flash_args", {})
        if not isinstance(flash_args, dict):
            return "错误：include_flash_images 需要 flasher_args.json 中的 flash_args"
        for name in ("bootloader.bin", "partition-table.bin", "ota_data_initial.bin"):
            matches = [value for value in flash_args.values() if Path(str(value)).name == name]
            if len(matches) != 1:
                return f"错误：flasher_args.json 未唯一声明 {name}"
            src = (build / str(matches[0])).resolve()
            if build.resolve() not in src.parents or not src.is_file():
                return f"错误：{name} 缺失或路径越出 build 目录: {src}"
            files[name] = src

    out.mkdir(parents=True)
    manifest = {"project": proj.name, "version": version, "target": target, "files": {}}
    for label, src in files.items():
        dest_name = "app.bin" if label == "app" else src.name
        dest = out / dest_name
        shutil.copy2(src, dest)
        manifest["files"][label] = {"file": dest_name, "bytes": dest.stat().st_size, "sha256": _file_sha256(dest)}
    elf = build / f"{proj.name}.elf"
    sdkconfig = proj / "sdkconfig"
    for src in (elf, sdkconfig, build / "flasher_args.json"):
        if src.exists():
            shutil.copy2(src, out / src.name)
    (out / "ota_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return f"OTA 发布文件已准备: {out}\n{json.dumps(manifest, ensure_ascii=False, indent=2)}\n注意：HTTPS OTA、签名/安全启动、版本防回滚和升级失败回退需在设备端另行验证。"


@tool(
    "check_esp32_sdkconfig",
    "静态检查 ESP-IDF sdkconfig 的看门狗、Core Dump、OTA、Flash 加密、安全启动、固件签名和优化配置，给出量产建议。",
    {"sdkconfig_path": {"type": "string"}, "production": {"type": "boolean"}},
    ["sdkconfig_path"],
)
def check_esp32_sdkconfig(sdkconfig_path: str, production: bool = True) -> str:
    p = Path(sdkconfig_path).resolve()
    if not p.is_file():
        return f"错误：sdkconfig 不存在: {p}"
    values = {}
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.startswith("CONFIG_") and "=" in line:
            k, v = line.split("=", 1)
            values[k] = v.strip()
    def enabled(key: str) -> bool:
        return values.get(key) == "y"
    checks = [
        (enabled("CONFIG_ESP_TASK_WDT"), "启用 Task WDT"),
        (enabled("CONFIG_ESP_COREDUMP_ENABLE"), "启用 Core Dump"),
        (enabled("CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE"), "启用应用回滚"),
        (enabled("CONFIG_APP_ANTI_ROLLBACK"), "启用防回滚（需规划 eFuse 版本）"),
        (enabled("CONFIG_SECURE_BOOT"), "启用 Secure Boot"),
        (enabled("CONFIG_FLASH_ENCRYPTION_ENABLED"), "启用 Flash Encryption"),
        (enabled("CONFIG_COMPILER_OPTIMIZATION_SIZE") or enabled("CONFIG_COMPILER_OPTIMIZATION_PERF"), "使用明确的发布优化级别"),
    ]
    lines = [f"{'PASS' if ok else 'REVIEW'}: {label}" for ok, label in checks]
    lines += ["", "量产提醒：Secure Boot/Flash Encryption/eFuse 操作不可逆或高风险，必须先在开发样机验证密钥、烧录和救砖流程；不要在智能体中自动烧 eFuse。"]
    return f"sdkconfig 检查: {p}\n" + "\n".join(lines)
