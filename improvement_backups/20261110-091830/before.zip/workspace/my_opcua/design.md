# my-opcua-gateway 设计与验证边界

## 当前实现范围

`gateway.py` 提供环回 OPC UA 客户端：浏览、读取、显式确认的白名单写入与回读、单节点数据变化订阅、服务端状态轮询、断线重连、订阅恢复和资源释放。命令行入口支持 `browse/read/write/monitor`，写命令必须同时提供 `--yes`。

当前客户端只接受环回 IP，不连接远程 PLC。真实远程端点仍需使用 Agent 的 endpoint 授权、SignAndEncrypt、环境变量凭据、客户端证书和固定服务器证书门禁。

## 节点模型

| 节点 | 类型 | 访问 | 用途 |
|---|---|---|---|
| `ns=2;s=Demo.Temperature` | Double | 只读 | 本地订阅与越权写入负例 |
| `ns=2;s=Demo.Setpoint` | Double | 白名单写 | 确认写入和回读核验 |
| `i=85` | Objects | 浏览 | 地址空间检查 |
| `i=2255` | CurrentTime | 只读 | 会话存活轮询 |

测试服务器使用 `urn:my-opcua-gateway:test` 命名空间和显式字符串 NodeId，仅启用 Anonymous + NoSecurity。该配置只用于环回仿真。

## 安全设计

- 非 `opc.tcp`、URL 凭据、主机名和非环回 IP 在建立连接前拒绝。
- 写入必须显式确认，NodeId 必须完整匹配白名单，值只允许标量。
- 写入后回读不一致即失败；白名单外写入不发送 OPC UA 写请求。
- 密钥和私钥不进入节点映射、源码、测试报告或验收日志。

## 重连与资源释放

监控循环创建会话和订阅，并通过服务器 CurrentTime 轮询检测断线。异常后关闭旧订阅和会话，按有限次数重连；成功后重新建立同一 NodeId 的订阅。收到停止事件或任务取消时执行资源清理。重连次数、连接次数、数据变化和错误计数保留在运行指标中。

## 需求覆盖

| 需求 | 当前状态 | 证据或阻塞 |
|---|---|---|
| FR-001 串口版本查询 | 未实现 | 需要实际串口设备、响应协议和 Git SHA 联调，OPC UA 测试不能替代 |
| FR-002 舵机角度控制 | 未实现 | 需要执行器、安全限位和物理角度测量，禁止用设定值回读代替角度验收 |
| NFR-001 24 小时稳定性 | 阻塞 | 已做服务端重启恢复测试，但未执行额定负载 24 小时长稳和资源泄漏测量 |
| SAFE-001 非授权节点写入保护 | 本地 bench 通过 | 连续 10 次白名单外写入均拒绝且目标值不变，另验证未确认写入拒绝 |

## 可重复验证

```bash
python run_protocol_tests.py
```

证据写入 `evidence/local_protocol_tests.json`，固定标记 `LOCAL_SIMULATION_NOT_DEVICE_OR_CUSTOMER_ACCEPTANCE`。本地 PASS 只证明上述协议实现，不代表真实 PLC、串口设备、舵机或客户整体验收通过。
