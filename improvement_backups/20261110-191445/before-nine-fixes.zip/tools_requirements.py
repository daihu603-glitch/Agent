"""客户需求规格、验收结果和需求追踪。"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import yaml

from tools import tool, WORKSPACE
from runtime_support import atomic_write

PLATFORMS = {"stm32", "linux_driver", "linux_app", "esp32", "rk3588", "android_app", "ai_agent_app", "device_app_ai", "opc_ua"}
METHODS = {"inspection", "analysis", "bench_test", "hil_test", "stress_test", "customer_test"}
RESULT_STATES = {"not_run", "pass", "fail", "blocked", "waived"}
REQ_ID = re.compile(r"^(CR|FR|NFR|IF|SAFE)-[A-Za-z0-9][A-Za-z0-9_-]*$")


def _resolve(path: str) -> Path:
    p = Path(path)
    return p.resolve() if p.is_absolute() else (WORKSPACE / path).resolve()


def _workspace_path(path: str) -> Path:
    p = (WORKSPACE / path).resolve()
    if p != WORKSPACE and WORKSPACE not in p.parents:
        raise ValueError(f"输出路径越出工作区: {path}")
    return p


def _load_spec(path: str) -> tuple[Path, dict]:
    p = _resolve(path)
    if not p.is_file():
        raise ValueError(f"需求规格不存在: {p}")
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("需求规格顶层必须是对象")
    return p, data


def _requirements(spec: dict) -> list[dict]:
    reqs = spec.get("requirements", [])
    if not isinstance(reqs, list):
        raise ValueError("requirements 必须是数组")
    return reqs


def _validate_spec(spec: dict) -> list[str]:
    errors = []
    project = spec.get("project", {})
    if not isinstance(project, dict):
        return ["project 必须是对象"]
    if not project.get("name"):
        errors.append("缺少 project.name")
    if not isinstance(project.get("platform"), str) or project["platform"] not in PLATFORMS:
        errors.append(f"project.platform 必须是 {sorted(PLATFORMS)} 之一")
    interfaces = project.get("interfaces", [])
    if not isinstance(interfaces, list) or not all(isinstance(x, str) for x in interfaces):
        errors.append("project.interfaces 必须是字符串数组")
        interfaces = []
    reqs = _requirements(spec)
    if not reqs:
        errors.append("至少需要一条客户需求")
    seen = set()
    for index, req in enumerate(reqs, 1):
        if not isinstance(req, dict):
            errors.append(f"第 {index} 条需求不是对象")
            continue
        rid = str(req.get("id", ""))
        prefix = f"需求[{rid or index}]"
        if not REQ_ID.match(rid):
            errors.append(f"{prefix}: id 应形如 FR-001 / NFR-001")
        if rid in seen:
            errors.append(f"{prefix}: id 重复")
        seen.add(rid)
        for key in ("title", "acceptance", "method"):
            if not str(req.get(key, "")).strip():
                errors.append(f"{prefix}: 缺少 {key}")
        if not isinstance(req.get("method"), str) or req["method"] not in METHODS:
            errors.append(f"{prefix}: method 必须为 {sorted(METHODS)} 之一")
        if req.get("acceptance") and not re.search(r"\d|演示|检查|审查|一致|无错误", str(req["acceptance"])):
            errors.append(f"{prefix}: acceptance 应包含可测量指标或明确检查判据")
        trace = req.get("trace", {})
        if not isinstance(trace, dict):
            errors.append(f"{prefix}: trace 必须是对象")
        else:
            for field in ("design", "code", "tests"):
                if field in trace and (not isinstance(trace[field], list) or not all(isinstance(x, str) and x.strip() for x in trace[field])):
                    errors.append(f"{prefix}: trace.{field} 必须是非空字符串组成的数组")
        if project.get("platform") == "opc_ua":
            text = f"{req.get('title', '')} {req.get('acceptance', '')}"
            for interface, pattern in (("serial", r"串口|115200|8N1"), ("actuator", r"舵机|实测角度"), ("mcu", r"HardFault|看门狗复位")):
                if re.search(pattern, text, re.I) and interface not in interfaces:
                    errors.append(f"{prefix}: OPC UA 基线混入 {interface} 需求；如属真实集成需求，请显式声明 project.interfaces 包含 {interface}")
    return errors


def _results_path(spec_path: Path) -> Path:
    return spec_path.parent / "acceptance_results.yaml"


def _load_results(spec_path: Path) -> dict:
    p = _results_path(spec_path)
    if not p.is_file():
        return {"results": {}}
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict) or not isinstance(data.get("results", {}), dict):
        raise ValueError(f"验收结果格式错误: {p}")
    data.setdefault("results", {})
    if any(not isinstance(result, dict) or not isinstance(result.get("status", "not_run"), str)
           or result.get("status", "not_run") not in RESULT_STATES for result in data["results"].values()):
        raise ValueError(f"验收记录必须为对象并包含有效 status: {p}")
    return data


def requirement_fingerprint(spec: dict, requirement: dict) -> str:
    project = spec.get("project", {})
    payload = {"project": {key: project.get(key) for key in ("name", "platform", "requirement_baseline", "interfaces")},
               "requirement": {key: value for key, value in requirement.items() if key != "trace"}}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def evidence_fingerprints(spec_path: Path, evidence: str) -> dict[str, str]:
    hashes = {}
    for item in (value.strip() for value in evidence.split(",") if value.strip()):
        p = Path(item)
        candidates = [p] if p.is_absolute() else [spec_path.parent / p, WORKSPACE / p]
        path = next((candidate for candidate in candidates if candidate.is_file()), None)
        if path is None:
            raise ValueError(f"证据文件不存在: {item}")
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        hashes[item] = digest.hexdigest()
    return hashes


def acceptance_issues(spec_path: Path, spec: dict, req: dict, result: dict) -> list[str]:
    if not isinstance(result, dict):
        return ["验收结果必须是对象"]
    if result.get("status") != "pass":
        return [f"验收状态为 {result.get('status', 'not_run')}"]
    issues = []
    if result.get("requirement_sha256") != requirement_fingerprint(spec, req):
        issues.append("验收未绑定当前需求基线，必须重新验证")
    evidence = str(result.get("evidence", ""))
    missing = missing_evidence_files(spec_path, evidence)
    if missing:
        issues.append(f"验收证据文件不存在: {', '.join(missing)}")
    elif result.get("evidence_sha256") != evidence_fingerprints(spec_path, evidence):
        issues.append("验收证据内容已变化或缺少哈希，必须重新验证")
    return issues


def missing_evidence_files(spec_path: Path, evidence: str) -> list[str]:
    items = [item.strip() for item in evidence.split(",") if item.strip()]
    if not items:
        return ["(未提供证据文件)"]
    missing = []
    for item in items:
        p = Path(item)
        candidates = [p] if p.is_absolute() else [spec_path.parent / p, WORKSPACE / p]
        if not any(candidate.is_file() for candidate in candidates):
            missing.append(item)
    return missing


@tool(
    "create_requirement_spec",
    "创建客户需求规格。requirements 是 JSON 数组，每项包含 id/title/acceptance/method，可含 priority、source、trace。支持嵌入式、android_app、ai_agent_app、device_app_ai、opc_ua。", 
    {
        "project_name": {"type": "string"},
        "platform": {"type": "string"},
        "requirements": {"type": "string", "description": "需求 JSON 数组"},
        "customer": {"type": "string"},
        "version": {"type": "string", "description": "需求基线版本，默认 0.1.0"},
        "output_path": {"type": "string", "description": "相对工作区路径，默认 <project>/requirements.yaml"},
    },
    ["project_name", "platform", "requirements"],
)
def create_requirement_spec(project_name: str, platform: str, requirements: str, customer: str = "", version: str = "0.1.0", output_path: str = "") -> str:
    try:
        reqs = json.loads(requirements)
    except json.JSONDecodeError as e:
        return f"错误：需求 JSON 无效: {e}"
    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "-", project_name).strip("-") or "project"
    spec = {
        "schema_version": 1,
        "project": {"name": project_name, "customer": customer, "platform": platform, "requirement_baseline": version},
        "requirements": reqs,
        "change_requests": [],
    }
    errors = _validate_spec(spec)
    if errors:
        return "需求规格校验失败:\n" + "\n".join(f"- {e}" for e in errors)
    try:
        out = _workspace_path(output_path or f"{safe_name}/requirements.yaml")
    except ValueError as e:
        return f"错误：{e}"
    if out.exists():
        return f"错误：需求基线已存在，避免覆盖: {out}。请使用 update_traceability 或指定新的版本化 output_path。"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(spec, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return f"已创建需求基线: {out}\n共 {len(reqs)} 条需求；下一步为每条需求补充 trace.design/code/tests。"


@tool(
    "validate_requirements",
    "校验客户需求规格的完整性、唯一 ID、可测验收标准和追踪结构。",
    {"spec_path": {"type": "string"}},
    ["spec_path"],
)
def validate_requirements(spec_path: str) -> str:
    try:
        p, spec = _load_spec(spec_path)
        errors = _validate_spec(spec)
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    if errors:
        return "需求规格校验失败:\n" + "\n".join(f"- {e}" for e in errors)
    reqs = _requirements(spec)
    linked = sum(bool(r.get("trace", {}).get("tests")) for r in reqs)
    return f"需求规格校验通过: {p}\n需求 {len(reqs)} 条，已关联测试 {linked} 条，未关联测试 {len(reqs)-linked} 条。"


@tool(
    "update_traceability",
    "更新单条需求的设计、代码和测试追踪证据。code/tests 为逗号分隔的文件路径或测试 ID。",
    {
        "spec_path": {"type": "string"},
        "requirement_id": {"type": "string"},
        "design": {"type": "string"},
        "code": {"type": "string"},
        "tests": {"type": "string"},
    },
    ["spec_path", "requirement_id"],
)
def update_traceability(spec_path: str, requirement_id: str, design: str = "", code: str = "", tests: str = "") -> str:
    try:
        p, spec = _load_spec(spec_path)
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    for req in _requirements(spec):
        if req.get("id") == requirement_id:
            trace = req.setdefault("trace", {})
            for key, value in (("design", design), ("code", code), ("tests", tests)):
                if value:
                    trace[key] = [x.strip() for x in value.split(",") if x.strip()]
            trace["updated_at"] = datetime.now(timezone.utc).isoformat()
            p.write_text(yaml.safe_dump(spec, allow_unicode=True, sort_keys=False), encoding="utf-8")
            return f"已更新 {requirement_id} 追踪: {trace}"
    return f"错误：找不到需求 {requirement_id}"


@tool(
    "record_acceptance_result",
    "记录一条需求的验收结果。status 只能是 not_run/pass/fail/blocked/waived；pass 必须提供存在的证据文件，waived 必须提供批准说明或证据。", 
    {
        "spec_path": {"type": "string"},
        "requirement_id": {"type": "string"},
        "status": {"type": "string"},
        "evidence": {"type": "string", "description": "日志、截图、报告路径或测试记录"},
        "notes": {"type": "string"},
        "tester": {"type": "string"},
    },
    ["spec_path", "requirement_id", "status"],
)
def record_acceptance_result(spec_path: str, requirement_id: str, status: str, evidence: str = "", notes: str = "", tester: str = "agent") -> str:
    if status not in RESULT_STATES:
        return f"错误：status 必须为 {sorted(RESULT_STATES)}"
    try:
        p, spec = _load_spec(spec_path)
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    errors = _validate_spec(spec)
    if errors:
        return "需求规格校验失败:\n" + "\n".join(errors)
    if requirement_id not in {r.get("id") for r in _requirements(spec)}:
        return f"错误：需求 {requirement_id} 不在基线中"
    if status == "pass" and not evidence.strip():
        return "错误：pass 必须填写证据文件路径，不能用 notes 替代"
    if status == "pass":
        missing = missing_evidence_files(p, evidence)
        if missing:
            return f"错误：pass 证据文件不存在: {', '.join(missing)}"
    if status == "waived" and not (evidence.strip() or notes.strip()):
        return "错误：waived 必须填写 evidence 或批准说明 notes"
    data = _load_results(p)
    data["results"][requirement_id] = {
        "status": status,
        "evidence": evidence,
        "notes": notes,
        "tester": tester,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "requirement_sha256": requirement_fingerprint(spec, next(r for r in _requirements(spec) if r["id"] == requirement_id)),
        "evidence_sha256": evidence_fingerprints(p, evidence) if status == "pass" else {},
    }
    out = _results_path(p)
    atomic_write(out, yaml.safe_dump(data, allow_unicode=True, sort_keys=False))
    return f"已记录 {requirement_id}={status}: {out}"


@tool(
    "traceability_report",
    "生成需求→设计→代码→测试→验收结果追踪报告，并给出交付门禁结论。",
    {
        "spec_path": {"type": "string"},
        "output_path": {"type": "string", "description": "默认与需求文件同目录 traceability_report.md"},
    },
    ["spec_path"],
)
def traceability_report(spec_path: str, output_path: str = "") -> str:
    try:
        p, spec = _load_spec(spec_path)
        errors = _validate_spec(spec)
        results = _load_results(p).get("results", {})
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    if errors:
        return "需求规格校验失败:\n" + "\n".join(f"- {error}" for error in errors)
    lines = [f"# 需求追踪与验收报告", "", f"项目: {spec.get('project', {}).get('name', '')}", f"平台: {spec.get('project', {}).get('platform', '')}", ""]
    lines += ["| 需求 | 设计 | 代码 | 测试 | 验收 | 证据 |", "|---|---|---|---|---|---|"]
    counts = {state: 0 for state in RESULT_STATES}
    blockers = list(errors)
    if spec.get("baseline_status", "approved") != "approved":
        blockers.append("需求基线仍为草案，需客户评审后显式设置 baseline_status: approved")
    for req in _requirements(spec):
        rid = req.get("id", "")
        trace = req.get("trace", {}) or {}
        result = results.get(rid, {})
        status = result.get("status", "not_run")
        counts[status] = counts.get(status, 0) + 1
        for field in ("design", "code", "tests"):
            if not trace.get(field):
                blockers.append(f"{rid} 缺少 trace.{field}")
        blockers.extend(f"{rid} {issue}" for issue in acceptance_issues(p, spec, req, result))
        lines.append("| {id} {title} | {design} | {code} | {tests} | {status} | {evidence} |".format(
            id=rid, title=str(req.get("title", "")).replace("|", "\\|"),
            design=", ".join(trace.get("design", [])) or "缺失",
            code=", ".join(trace.get("code", [])) or "缺失",
            tests=", ".join(trace.get("tests", [])) or "缺失",
            status=status, evidence=str(result.get("evidence", "")).replace("|", "\\|") or "-",
        ))
    ready = not blockers
    lines += ["", f"验收统计: {counts}", f"交付门禁: {'PASS' if ready else 'BLOCKED'}"]
    if blockers:
        lines += ["", "## 阻塞项"] + [f"- {b}" for b in blockers]
    text = "\n".join(lines)
    out = Path(output_path).resolve() if output_path else p.parent / "traceability_report.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    return text + f"\n\n报告: {out}"
