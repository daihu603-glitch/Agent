"""发布门禁、环境记录和带 SHA256 校验的客户交付包。"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import yaml

from tools import tool, WORKSPACE, _safe_path
from tools_requirements import _load_spec, _validate_spec, _load_results, _requirements, missing_evidence_files

ARTIFACT_KEYS = ("firmware", "source", "docs", "test_reports", "tools", "config")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _zip_sha256(zf: zipfile.ZipFile, name: str) -> str:
    digest = hashlib.sha256()
    with zf.open(name) as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _delivery_gate(spec_path: Path, spec: dict) -> list[str]:
    blockers = _validate_spec(spec)
    results = _load_results(spec_path).get("results", {})
    for req in _requirements(spec):
        rid = req.get("id", "")
        trace = req.get("trace", {}) or {}
        for key in ("design", "code", "tests"):
            if not trace.get(key):
                blockers.append(f"{rid}: 缺少追踪 {key}")
        result = results.get(rid, {})
        if result.get("status") != "pass":
            blockers.append(f"{rid}: 验收未通过（{result.get('status', 'not_run')}）")
        if not str(result.get("evidence", "")).strip() and not str(result.get("notes", "")).strip():
            blockers.append(f"{rid}: 缺少验收证据")
        for missing in missing_evidence_files(spec_path, str(result.get("evidence", ""))):
            blockers.append(f"{rid}: 验收证据文件不存在 {missing}")
    return blockers


@tool(
    "check_delivery_gate",
    "检查是否满足最终交付条件：需求规格有效、追踪完整、每条需求均 pass 且有证据。",
    {"spec_path": {"type": "string"}},
    ["spec_path"],
)
def check_delivery_gate(spec_path: str) -> str:
    try:
        p, spec = _load_spec(spec_path)
        blockers = _delivery_gate(p, spec)
    except (ValueError, yaml.YAMLError) as e:
        return f"DELIVERY_BLOCKED\n- {e}"
    if blockers:
        return "DELIVERY_BLOCKED\n" + "\n".join(f"- {b}" for b in blockers)
    return f"DELIVERY_PASS\n{_requirements(spec).__len__()} 条需求全部验收通过，可生成交付包。"


@tool(
    "record_build_environment",
    "记录构建环境、SDK 路径、工具版本和 Git 提交，用于交付复现。不会读取或输出密钥。",
    {
        "project_dir": {"type": "string"},
        "platform_name": {"type": "string"},
        "sdk_path": {"type": "string"},
        "tool_versions": {"type": "string", "description": "JSON 对象，如 {\"gcc\":\"14.3\",\"idf\":\"5.4\"}"},
        "output_path": {"type": "string", "description": "默认 workspace/build_environment.json"},
    },
    ["project_dir", "platform_name"],
)
def record_build_environment(project_dir: str, platform_name: str, sdk_path: str = "", tool_versions: str = "{}", output_path: str = "build_environment.json") -> str:
    try:
        versions = json.loads(tool_versions)
        if not isinstance(versions, dict):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        return "错误：tool_versions 必须是 JSON 对象"
    data = {
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "platform": platform_name,
        "host": {"os": platform.platform(), "python": sys.version.split()[0], "machine": platform.machine()},
        "project_dir": str(Path(project_dir).resolve()),
        "sdk_path": sdk_path,
        "tool_versions": versions,
        "source_revision": "",
        "source_dirty": None,
    }
    proj = Path(project_dir)
    if (proj / ".git").exists():
        import subprocess
        rev = subprocess.run(["git", "rev-parse", "HEAD"], cwd=proj, capture_output=True, text=True)
        dirty = subprocess.run(["git", "status", "--porcelain"], cwd=proj, capture_output=True, text=True)
        data["source_revision"] = rev.stdout.strip() if rev.returncode == 0 else ""
        data["source_dirty"] = bool(dirty.stdout.strip()) if dirty.returncode == 0 else None
    try:
        out = _safe_path(output_path)
    except ValueError as e:
        return f"错误：{e}"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return f"构建环境已记录: {out}\n{json.dumps(data, ensure_ascii=False, indent=2)}"


@tool(
    "package_delivery",
    "生成最终客户交付 ZIP、manifest.json 和 SHA256SUMS.txt。默认强制所有需求验收通过；artifact_paths 为 JSON 路径数组，单个路径或逗号分隔路径。", 
    {
        "spec_path": {"type": "string"},
        "version": {"type": "string"},
        "artifact_paths": {"type": "string", "description": "JSON 路径数组（支持含逗号路径），也兼容单路径或逗号分隔"},
        "release_notes": {"type": "string"},
        "output_dir": {"type": "string", "description": "相对工作区的输出目录，默认 delivery"},
        "allow_incomplete": {"type": "boolean", "description": "仅用于内部调试包；客户正式交付应保持 false"},
    },
    ["spec_path", "version", "artifact_paths"],
)
def package_delivery(spec_path: str, version: str, artifact_paths: str, release_notes: str = "", output_dir: str = "delivery", allow_incomplete: bool = False) -> str:
    try:
        spec_file, spec = _load_spec(spec_path)
        blockers = _delivery_gate(spec_file, spec)
    except (ValueError, yaml.YAMLError) as e:
        return f"交付终止: {e}"
    if blockers and not allow_incomplete:
        return "DELIVERY_BLOCKED，未创建交付包:\n" + "\n".join(f"- {b}" for b in blockers)

    try:
        if artifact_paths.lstrip().startswith("["):
            raw_artifacts = json.loads(artifact_paths)
            if not isinstance(raw_artifacts, list) or not all(isinstance(item, str) for item in raw_artifacts):
                return "交付终止：artifact_paths JSON 必须是字符串数组"
        else:
            raw_artifacts = artifact_paths.split(",")
    except json.JSONDecodeError as e:
        return f"交付终止：artifact_paths JSON 无效: {e}"
    artifacts = [Path(item.strip()).resolve() for item in raw_artifacts if item.strip()]
    missing = [str(p) for p in artifacts if not p.exists()]
    if missing:
        return "交付终止，以下产物不存在:\n" + "\n".join(missing)
    if not artifacts:
        return "交付终止：至少需要一个交付产物"

    project = str(spec.get("project", {}).get("name", "project"))
    safe_project = "".join(c if c.isalnum() or c in "._-" else "-" for c in project)
    safe_version = "".join(c if c.isalnum() or c in "._-" else "-" for c in version)
    duplicate_names = len({src.name.casefold() for src in artifacts}) != len(artifacts)
    if duplicate_names:
        return "交付终止：不同产物存在同名文件/目录，请先重命名，避免 payload 覆盖"
    try:
        package_root = _safe_path(str(Path(output_dir) / f"{safe_project or 'project'}-{safe_version or 'version'}"))
    except ValueError as e:
        return f"交付终止：{e}"
    zip_path = package_root.with_suffix(".zip")
    if package_root.exists() or zip_path.exists():
        return f"交付终止：目标目录或 ZIP 已存在，避免覆盖历史版本: {package_root}"
    package_root.mkdir(parents=True)
    payload = package_root / "payload"
    payload.mkdir()

    files = []
    total_bytes = 0
    try:
        for src in artifacts:
            dest = payload / src.name
            if src.is_dir():
                shutil.copytree(src, dest)
                sources = [p for p in dest.rglob("*") if p.is_file()]
            else:
                shutil.copy2(src, dest)
                sources = [dest]
            for file in sources:
                size = file.stat().st_size
                total_bytes += size
                files.append({"path": file.relative_to(package_root).as_posix(), "bytes": size, "sha256": _sha256(file)})
    except (OSError, shutil.Error) as e:
        shutil.rmtree(package_root, ignore_errors=True)
        return f"交付终止：复制或哈希产物失败，已清理不完整目录: {e}"

    results = _load_results(spec_file).get("results", {})
    manifest = {
        "schema_version": 1,
        "project": spec.get("project", {}),
        "release_version": version,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "internal_debug_package": bool(allow_incomplete and blockers),
        "delivery_gate": "WAIVED_INTERNAL_ONLY" if allow_incomplete and blockers else "PASS",
        "gate_blockers": blockers,
        "requirements": [{"id": r.get("id"), "title": r.get("title"), "acceptance": r.get("acceptance"), "result": results.get(r.get("id"), {"status": "not_run"})} for r in _requirements(spec)],
        "files": files,
        "total_bytes": total_bytes,
        "release_notes": release_notes,
    }
    (package_root / "requirements.yaml").write_text(yaml.safe_dump(spec, allow_unicode=True, sort_keys=False), encoding="utf-8")
    (package_root / "acceptance_results.yaml").write_text(yaml.safe_dump({"results": results}, allow_unicode=True, sort_keys=False), encoding="utf-8")
    (package_root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    checksum_lines = [f"{_sha256(p)}  {p.relative_to(package_root).as_posix()}" for p in sorted(package_root.rglob("*")) if p.is_file() and p.name != "SHA256SUMS.txt"]
    (package_root / "SHA256SUMS.txt").write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")

    try:
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for file in sorted(package_root.rglob("*")):
                if file.is_file():
                    zf.write(file, arcname=f"{package_root.name}/{file.relative_to(package_root).as_posix()}")
        zip_hash = _sha256(zip_path)
        hash_file = zip_path.with_suffix(".zip.sha256")
        hash_file.write_text(f"{zip_hash}  {zip_path.name}\n", encoding="utf-8")
    except OSError as e:
        zip_path.unlink(missing_ok=True)
        shutil.rmtree(package_root, ignore_errors=True)
        return f"交付终止：ZIP 创建失败，已清理不完整产物: {e}"
    return f"交付包已生成: {zip_path}\nSHA256: {zip_hash}\n文件 {len(files)} 个，payload {total_bytes} bytes\n门禁: {manifest['delivery_gate']}"


@tool(
    "verify_delivery_package",
    "校验交付 ZIP 内 manifest 和每个 payload 文件的 SHA256，并确认门禁状态。",
    {"zip_path": {"type": "string"}},
    ["zip_path"],
)
def verify_delivery_package(zip_path: str) -> str:
    p = Path(zip_path)
    if not p.is_absolute():
        p = WORKSPACE / p
    if not p.is_file():
        return f"错误：交付包不存在: {p}"
    hash_file = p.with_suffix(".zip.sha256")
    if not hash_file.is_file():
        return f"交付包校验失败：缺少外部 SHA256 文件: {hash_file.name}"
    expected_zip_hash = hash_file.read_text(encoding="utf-8").split(maxsplit=1)[0].lower()
    if _sha256(p) != expected_zip_hash:
        return "交付包校验失败：ZIP 外部 SHA256 不匹配"
    try:
        with zipfile.ZipFile(p) as zf:
            names = zf.namelist()
            for entry in names:
                entry_path = PurePosixPath(entry)
                if entry_path.is_absolute() or ".." in entry_path.parts or "\\" in entry:
                    return f"交付包校验失败：ZIP 含非法路径 {entry}"
            manifest_names = [n for n in names if n.endswith("/manifest.json")]
            if len(manifest_names) != 1:
                return "校验失败：manifest.json 缺失或不唯一"
            root = manifest_names[0].split("/")[0]
            manifest = json.loads(zf.read(manifest_names[0]))
            errors = []
            seen_paths = set()
            for item in manifest.get("files", []):
                raw_path = str(item["path"])
                item_path = PurePosixPath(raw_path)
                if item_path.is_absolute() or ".." in item_path.parts or "\\" in raw_path or not raw_path.startswith("payload/") or raw_path in seen_paths:
                    errors.append(f"manifest 非法或重复路径 {raw_path}")
                    continue
                seen_paths.add(raw_path)
                name = f"{root}/{raw_path}"
                try:
                    actual = _zip_sha256(zf, name)
                    actual_size = zf.getinfo(name).file_size
                except KeyError:
                    errors.append(f"缺失 {item['path']}")
                    continue
                if actual != item.get("sha256"):
                    errors.append(f"哈希不匹配 {item['path']}")
                if actual_size != item.get("bytes"):
                    errors.append(f"大小不匹配 {item['path']}")
            if manifest.get("delivery_gate") != "PASS":
                errors.append(f"非正式交付门禁: {manifest.get('delivery_gate')}")
            if errors:
                return "交付包校验失败:\n" + "\n".join(errors)
            return f"交付包校验通过: {p.name}\n项目 {manifest.get('project', {}).get('name')} 版本 {manifest.get('release_version')}，{len(manifest.get('files', []))} 个文件哈希一致。"
    except (zipfile.BadZipFile, json.JSONDecodeError, KeyError) as e:
        return f"交付包校验失败: {e}"
