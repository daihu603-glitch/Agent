"""Rockchip RK3588 SDK 构建、固件打包、烧录与版本核验。"""
from __future__ import annotations

import hashlib
import re
import shlex
from pathlib import Path

from tools import tool
from procutil import CommandError, existing_dir, find_artifact, run_command, windows_to_wsl
import config

COMPONENT_COMMANDS = {
    "uboot": "uboot",
    "kernel": "kernel",
    "rootfs": "rootfs",
    "recovery": "recovery",
    "all": "all",
    "firmware": "firmware",
    "updateimg": "updateimg",
}


def _sdk(path: str = "") -> Path:
    sdk = path or config.toolchain.get("rk3588_sdk", "")
    if not sdk:
        raise CommandError("请在 config.yaml 配置 toolchain.rk3588_sdk")
    return existing_dir(sdk, "RK3588 SDK")


def _script(sdk: Path, build_script: str = "") -> str:
    script = build_script or config.toolchain.get("rk3588_build_script", "./build.sh")
    if not re.match(r"^(\./)?[A-Za-z0-9_./-]+$", script) or ".." in script:
        raise CommandError("build_script 路径非法")
    return script


@tool(
    "rk3588_environment_check",
    "检查 RK3588 SDK 布局、build.sh、板级配置、内核/U-Boot/rootfs 目录以及烧录工具。",
    {"sdk_root": {"type": "string"}, "build_script": {"type": "string"}},
    [],
)
def rk3588_environment_check(sdk_root: str = "", build_script: str = "") -> str:
    try:
        sdk = _sdk(sdk_root)
        script = _script(sdk, build_script)
        expected = ("u-boot", "kernel", "rootfs", "buildroot", "yocto", "device/rockchip", "rkbin", "tools")
        lines = [f"SDK: {sdk}", f"build script: {script} ({'存在' if (sdk / script).exists() else '未找到'})"]
        for name in expected:
            lines.append(f"{name}: {'存在' if (sdk / name).exists() else '未找到'}")
        configs = list((sdk / "device" / "rockchip" / ".chip").glob("*")) if (sdk / "device" / "rockchip" / ".chip").exists() else []
        board_cfgs = list(sdk.glob("device/rockchip/rk3588/*.mk")) + list(sdk.glob("device/rockchip/rk3588/*/*.mk"))
        lines.append(f"板级 .mk 配置: {len(board_cfgs)} 个")
        lines += [f"  {p.relative_to(sdk)}" for p in board_cfgs[:20]]
        for tool_name in (config.toolchain.get("rk3588_upgrade_tool", "upgrade_tool"), config.toolchain.get("rk3588_rkdeveloptool", "rkdeveloptool")):
            try:
                lines.append(f"{tool_name}: {run_command([tool_name, '-v'], timeout=10, max_output=500)}")
            except CommandError as e:
                lines.append(f"{tool_name}: 不可用 ({e})")
        return "\n".join(lines)
    except CommandError as e:
        return f"RK3588 环境检查失败: {e}"


@tool(
    "build_rk3588",
    "构建 RK3588 SDK 的 uboot/kernel/rootfs/recovery/all/firmware/updateimg。执行 SDK build.sh，长任务有超时；打包与烧录步骤在工作流中需确认。",
    {
        "sdk_root": {"type": "string"}, "component": {"type": "string"},
        "board_config": {"type": "string", "description": "可选 BoardConfig*.mk 文件名或相对 SDK 路径"},
        "build_script": {"type": "string"}, "jobs": {"type": "integer"},
        "use_wsl": {"type": "boolean"}, "wsl_distro": {"type": "string"},
        "timeout": {"type": "integer"},
    },
    ["component"],
)
def build_rk3588(component: str, sdk_root: str = "", board_config: str = "", build_script: str = "", jobs: int = 8, use_wsl: bool = False, wsl_distro: str = "", timeout: int = 3600) -> str:
    if component not in COMPONENT_COMMANDS:
        return f"错误：component 必须为 {sorted(COMPONENT_COMMANDS)}"
    try:
        sdk = _sdk(sdk_root)
        script = _script(sdk, build_script)
        if use_wsl:
            distro = wsl_distro or config.toolchain.get("wsl_distro", "")
            prefix = ["wsl.exe"] + (["-d", distro] if distro else []) + ["--", "bash", "-lc"]
            sdk_wsl = windows_to_wsl(sdk)
            command = f"cd {shlex.quote(sdk_wsl)} && "
            if board_config:
                if not re.match(r"^[A-Za-z0-9_./-]+$", board_config) or ".." in board_config:
                    return "错误：board_config 路径非法"
                command += f"./{script.removeprefix('./')} {board_config} && "
            command += f"./{script.removeprefix('./')} {COMPONENT_COMMANDS[component]}"
            output = run_command(prefix + [command], timeout=min(timeout, 7200), max_output=20000)
        else:
            if board_config:
                if not re.match(r"^[A-Za-z0-9_./-]+$", board_config) or ".." in board_config:
                    return "错误：board_config 路径非法"
                run_command(["bash", script, board_config], cwd=sdk, timeout=120)
            output = run_command(["bash", script, COMPONENT_COMMANDS[component]], cwd=sdk, timeout=min(timeout, 7200), max_output=20000)
        artifacts = []
        for pattern in ("*.img", "*.dtb", "*.ko"):
            for p in sdk.rglob(pattern):
                if p.is_file() and ("output" in p.parts or "rockdev" in p.parts or "IMAGE" in p.parts):
                    artifacts.append(p)
        latest = sorted(artifacts, key=lambda p: p.stat().st_mtime, reverse=True)[:15]
        listing = "\n".join(f"  {p} ({p.stat().st_size} bytes)" for p in latest)
        return f"RK3588 {component} 构建完成。\n产物:\n{listing or '  请检查 SDK rockdev/output 目录'}\n{output[-2500:]}"
    except CommandError as e:
        return f"RK3588 {component} 构建失败: {e}"


@tool(
    "verify_rk3588_images",
    "核验 RK3588 update.img、parameter、MiniLoader、U-Boot、boot、rootfs 等镜像是否齐全，记录大小和 SHA256，不修改固件。",
    {"image_dir": {"type": "string"}, "require_update_img": {"type": "boolean"}},
    ["image_dir"],
)
def verify_rk3588_images(image_dir: str, require_update_img: bool = True) -> str:
    try:
        root = existing_dir(image_dir, "固件目录")
        images = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in {".img", ".bin", ".dtb"}]
        if not images:
            return "固件核验失败：未找到 .img/.bin/.dtb"
        update = list(root.rglob("update.img"))
        problems = []
        if require_update_img and not update:
            problems.append("缺少 update.img")
        lines = []
        for p in sorted(images):
            size = p.stat().st_size
            if size == 0:
                problems.append(f"空文件: {p}")
            digest = hashlib.sha256()
            with p.open("rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    digest.update(chunk)
            lines.append(f"{p.relative_to(root)}: {size} bytes SHA256={digest.hexdigest()}")
        if problems:
            return "固件核验失败:\n" + "\n".join(problems) + "\n" + "\n".join(lines)
        return f"固件文件完整性检查通过（尚未验证镜像内部签名/分区布局）:\n" + "\n".join(lines)
    except CommandError as e:
        return f"固件核验失败: {e}"


@tool(
    "flash_rk3588",
    "用 Rockchip upgrade_tool uf update.img 烧录完整固件。设备需已处于 Loader/MaskROM；会重写目标存储，工作流中必须人工确认。",
    {
        "update_img": {"type": "string"}, "upgrade_tool": {"type": "string"},
        "timeout": {"type": "integer"},
    },
    ["update_img"],
)
def flash_rk3588(update_img: str, upgrade_tool: str = "", timeout: int = 1800) -> str:
    image = Path(update_img).resolve()
    if not image.is_file() or image.stat().st_size == 0:
        return f"错误：update.img 不存在或为空: {image}"
    exe = upgrade_tool or config.toolchain.get("rk3588_upgrade_tool", "upgrade_tool")
    if not re.match(r"^[A-Za-z0-9_./\\:+-]+$", exe):
        return "错误：烧录工具路径非法"
    try:
        output = run_command([exe, "uf", str(image)], timeout=min(timeout, 3600), max_output=10000)
        return f"RK3588 固件烧录命令完成，请通过串口/SSH 验证启动和版本:\n{output}"
    except CommandError as e:
        return f"RK3588 烧录失败，不要反复复位或断电，先检查 Loader 状态和 USB: {e}"


@tool(
    "rk3588_runtime_check",
    "生成 RK3588 运行时验收检查清单，结合 device_health/device_run/device_capture_logs 验证内核、设备树、驱动、NPU、视频与存储。",
    {"sdk_release": {"type": "string"}, "expected_kernel": {"type": "string"}},
    [],
)
def rk3588_runtime_check(sdk_release: str = "", expected_kernel: str = "") -> str:
    return f"""RK3588 运行时验收清单（期望 SDK={sdk_release or '未指定'}, kernel={expected_kernel or '未指定'}）：
1. device_health：记录 model、uname、uptime、内存、/ 与 /userdata 剩余空间、温度。
2. device_run cat /proc/cmdline：核对 bootargs、root 分区和 console。
3. device_run cat /proc/device-tree/compatible：核对板型与 SDK 配置。
4. device_run lsmod 与 dmesg：确认无 probe deferral 循环、IOMMU、regulator、clock 错误。
5. 外设逐项：camera 用 media-ctl/v4l2-ctl；display 检查 modetest（需人工执行）；NVMe/USB/网口做读写与压力测试。
6. NPU：按 RKNPU2/rknn_server 版本运行客户模型，记录精度、FPS、内存、温度、连续运行结果。
7. 多媒体：MPP 编解码和 RGA 零拷贝链路记录分辨率、帧率、端到端延迟、丢帧。
8. device_capture_logs 保存证据，任何 Kernel panic/Oops/硬件 watchdog reset 均为阻塞项。
9. 断电重启、升级回滚和 A/B 分区（若项目要求）必须单独测试。"""
