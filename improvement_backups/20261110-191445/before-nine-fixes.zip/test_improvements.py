"""Regression tests for execution correctness, evidence binding and setup boundaries."""
from __future__ import annotations

import io
import os
import runpy
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import yaml

import agent
import manage
import model_client
import runtime_support
import tools
import tools_ai_agent as ai
import tools_delivery as delivery
import tools_discovery as discovery
import tools_requirements as requirements
import workflow
from requirement_templates import requirement_template


class ImprovementTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="improvement-tests-", dir=tools.WORKSPACE)
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def save(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")
        return path

    def run_workflow(self, text="done\nSTEP_STATUS: COMPLETED", variables=None, **options):
        path = self.root / "test-flow.yaml"
        if not path.exists():
            self.save(path.name, {"vars": {}, "steps": [{"id": "one", "task": "work"}]})
        fake = lambda **kwargs: SimpleNamespace(last_status="completed", run=lambda prompt: text,
                                               tool_calls=[], usage={"input_tokens": 2})
        with patch.object(workflow, "WORKSPACE", self.root), redirect_stdout(io.StringIO()):
            return workflow.run_workflow(str(path), variables or {}, agent_factory=fake, return_result=True, **options)

    def valid_requirement(self):
        spec = requirement_template("stm32", "test")
        spec["baseline_status"] = "approved"
        spec["requirements"] = spec["requirements"][:1]
        spec["requirements"][0]["trace"] = {"design": ["design.md"], "code": ["main.c"], "tests": ["test-version"]}
        path = self.save("requirements.yaml", spec)
        evidence = self.root / "evidence.log"
        evidence.write_text("100 responses matched\n", encoding="utf-8")
        result = requirements.record_acceptance_result(str(path), "FR-001", "pass", str(evidence))
        self.assertIn("已记录", result)
        return path, spec, evidence

    def test_no_marker_is_failure(self):
        self.assertEqual(self.run_workflow("looks completed")["status"], "failed")

    def test_marker_quoted_earlier_cannot_override_last_line(self):
        self.assertEqual(self.run_workflow("STEP_STATUS: COMPLETED\nactually unavailable")["status"], "failed")

    def test_blocked_marker_stops_flow(self):
        self.assertEqual(self.run_workflow("missing SDK\nSTEP_STATUS: BLOCKED")["status"], "blocked")

    def test_state_is_versioned_and_keeps_token_counts(self):
        result = self.run_workflow()
        state = yaml.safe_load(Path(result["state_file"]).read_text(encoding="utf-8"))
        self.assertEqual(state["schema_version"], 2)
        self.assertEqual(state["step_evidence"]["one"]["usage"]["input_tokens"], 2)

    def test_resume_changed_project_is_rejected(self):
        result = self.run_workflow(variables={"project_dir": "board-A"})
        with self.assertRaisesRegex(ValueError, "变量已变化"):
            self.run_workflow(variables={"project_dir": "board-B"}, resume_file=result["state_file"])

    def test_resume_identical_variables_skips_completed(self):
        result = self.run_workflow(variables={"project_dir": "board-A"})
        again = self.run_workflow(variables={}, resume_file=result["state_file"])
        self.assertEqual(again["step_states"], {"one": "completed"})

    def test_resume_requires_redacted_variables(self):
        result = self.run_workflow(variables={"api_token": "offline-secret-value"})
        self.assertNotIn("offline-secret-value", Path(result["state_file"]).read_text(encoding="utf-8"))
        with self.assertRaisesRegex(ValueError, "重新提供"):
            self.run_workflow(resume_file=result["state_file"])

    def test_duplicate_steps_and_bad_confirm_rejected_before_execution(self):
        for steps in ([{"id": "x", "task": "a"}, {"id": "x", "task": "b"}], [{"id": "x", "task": "a", "confirm": "false"}]):
            with self.subTest(steps=steps), self.assertRaises(ValueError):
                workflow._validate_workflow({"steps": steps})

    def test_required_tool_cannot_be_satisfied_by_model_claim(self):
        self.save("test-flow.yaml", {"steps": [{"id": "one", "task": "work", "allowed_tools": ["calculator"], "required_tools": ["calculator"]}]})
        result = self.run_workflow()
        self.assertEqual(result["status"], "failed")
        self.assertIn("缺少真实成功工具调用", result["steps"]["one"])

    def test_advisory_timeout_does_not_corrupt_completion_marker(self):
        self.save("test-flow.yaml", {"steps": [{"id": "one", "task": "work", "timeout": 1}]})
        with patch.object(workflow.time, "monotonic", side_effect=[1, 4]):
            result = self.run_workflow()
        self.assertEqual(result["status"], "completed")
        self.assertTrue(result["step_evidence"]["one"]["timeout_warning"])

    def test_invalid_spec_or_result_blocks_without_crashing(self):
        malformed = self.save("bad.yaml", {"project": []})
        self.assertIn("校验失败", requirements.traceability_report(str(malformed)))
        path, spec, evidence = self.valid_requirement()
        self.save("acceptance_results.yaml", {"results": {"FR-001": "pass"}})
        self.assertIn("DELIVERY_BLOCKED", delivery.check_delivery_gate(str(path)))

    def test_truncated_tool_response_never_executes(self):
        response = {"choices": [{"message": {"tool_calls": [{"id": "x", "function": {"name": "calculator", "arguments": '{"expression":"6*7"}'}}]}, "finish_reason": "length"}]}
        normalized = model_client._normalize_openai_response(response)
        client = SimpleNamespace(messages=SimpleNamespace(create=lambda **kwargs: normalized))
        runner = agent.Agent(client=client, verbose=False)
        with patch.object(tools, "run_tool") as execute:
            self.assertIn("AGENT_ERROR", runner.run("test"))
            execute.assert_not_called()
        self.assertEqual(len(runner.messages), 1)

    def test_duplicate_tool_ids_rejected(self):
        call = {"type": "tool_use", "id": "duplicate", "name": "calculator", "input": {"expression": "1+1"}}
        client = SimpleNamespace(messages=SimpleNamespace(create=lambda **kwargs: {"content": [call, call], "stop_reason": "tool_use"}))
        with patch.object(tools, "run_tool") as execute:
            self.assertIn("id 缺失或重复", agent.Agent(client=client, verbose=False).run("test"))
            execute.assert_not_called()

    def test_api_error_redacts_environment_key(self):
        secret = "offline-secret-123456"
        def fail(**kwargs):
            raise RuntimeError(f"failed with {secret}")
        with patch.dict(os.environ, {"DEEPSEEK_API_KEY": secret}):
            output = agent.Agent(client=SimpleNamespace(messages=SimpleNamespace(create=fail)), verbose=False).run("test")
        self.assertNotIn(secret, output)
        self.assertIn("REDACTED", output)

    def test_all_platform_templates_validate(self):
        for platform in requirements.PLATFORMS:
            with self.subTest(platform=platform):
                self.assertEqual(requirements._validate_spec(requirement_template(platform, "test")), [])

    def test_opcua_cannot_silently_use_servo_template(self):
        spec = requirement_template("stm32", "opcua-test")
        spec["project"]["platform"] = "opc_ua"
        self.assertTrue(any("serial" in error for error in requirements._validate_spec(spec)))
        spec["project"]["interfaces"] = ["serial"]
        self.assertEqual(requirements._validate_spec(spec), [])

    def test_malformed_trace_is_validation_error(self):
        spec = requirement_template("stm32", "test")
        spec["requirements"][0]["trace"] = {"tests": "fake.py"}
        self.assertTrue(any("trace.tests" in error for error in requirements._validate_spec(spec)))
        self.assertTrue(requirements._validate_spec({"project": []}))

    def test_evidence_content_change_invalidates_pass(self):
        path, spec, evidence = self.valid_requirement()
        self.assertTrue(delivery.check_delivery_gate(str(path)).startswith("DELIVERY_PASS"))
        evidence.write_text("changed after recording", encoding="utf-8")
        self.assertIn("证据内容已变化", delivery.check_delivery_gate(str(path)))

    def test_acceptance_change_invalidates_old_pass(self):
        path, spec, evidence = self.valid_requirement()
        spec["requirements"][0]["acceptance"] += "，另要求 1000 次验证"
        self.save(path.name, spec)
        self.assertIn("未绑定当前需求基线", delivery.check_delivery_gate(str(path)))

    def test_updating_trace_does_not_invalidate_acceptance(self):
        path, spec, evidence = self.valid_requirement()
        requirements.update_traceability(str(path), "FR-001", tests="new-test-id")
        self.assertTrue(delivery.check_delivery_gate(str(path)).startswith("DELIVERY_PASS"))

    def test_template_draft_cannot_pass_delivery(self):
        path, spec, evidence = self.valid_requirement()
        spec["baseline_status"] = "draft_requires_customer_review"
        self.save(path.name, spec)
        self.assertIn("仍为草案", delivery.check_delivery_gate(str(path)))

    def test_init_is_platform_specific_and_refuses_overwrite(self):
        target = self.root / "new-opcua"
        manage.init_project(str(target), "opc_ua")
        saved = (target / "requirements.yaml").read_text(encoding="utf-8")
        self.assertEqual(yaml.safe_load(saved)["project"]["platform"], "opc_ua")
        self.assertNotIn("舵机", saved)
        with self.assertRaises(ValueError):
            manage.init_project(str(target), "stm32")
        self.assertEqual(saved, (target / "requirements.yaml").read_text(encoding="utf-8"))

    def test_init_rejects_path_escape(self):
        with self.assertRaises(ValueError):
            manage.init_project("../escaped-project", "opc_ua")

    def test_ai_init_supplies_design_and_eval_inputs(self):
        target = manage.init_project(str(self.root / "new-ai"), "ai_agent_app")
        self.assertTrue((target / "agent_design.yaml").is_file())
        self.assertTrue((target / "agent_eval.yaml").is_file())

    def test_provider_override_does_not_reuse_other_vendor_endpoint_or_key(self):
        config_file = self.save("config.yaml", {"agent": {"provider": "deepseek", "model": "deepseek-chat", "base_url": "https://api.deepseek.com", "api_key_env": "DEEPSEEK_API_KEY"}})
        with patch.dict(os.environ, {"AGENT_CONFIG": str(config_file), "AGENT_PROVIDER": "openai"}):
            # Drop only model-specific overrides, keeping unrelated host environment intact.
            with patch.dict(os.environ, {}, clear=False):
                for key in ("AGENT_MODEL", "AGENT_BASE_URL", "AGENT_API_KEY_ENV"):
                    os.environ.pop(key, None)
                resolved = runpy.run_path(str(manage.ROOT / "config.py"))
        self.assertEqual(resolved["AGENT_BASE_URL"], "https://api.openai.com/v1")
        self.assertEqual(resolved["AGENT_API_KEY_ENV"], "OPENAI_API_KEY")
        self.assertNotEqual(resolved["AGENT_MODEL"], "deepseek-chat")

    def test_smoke_missing_key_writes_blocked_without_network(self):
        with patch.object(manage, "WORKSPACE", self.root), patch.object(model_client, "has_api_key", return_value=False), patch.object(ai, "run_agent_eval") as evaluate:
            report, path = manage.smoke_test()
        self.assertEqual(report["status"], "BLOCKED")
        self.assertTrue(path.is_file())
        evaluate.assert_not_called()

    def test_atomic_replace_failure_preserves_previous_report(self):
        path = self.root / "report.json"
        path.write_text("old", encoding="utf-8")
        with patch.object(runtime_support.os, "replace", side_effect=OSError("disk error")), self.assertRaises(OSError):
            runtime_support.atomic_write(path, "new")
        self.assertEqual(path.read_text(encoding="utf-8"), "old")
        self.assertEqual(list(self.root.glob("*.tmp")), [])

    def test_html_report_escapes_requirement_text(self):
        path, spec, evidence = self.valid_requirement()
        spec["requirements"][0]["title"] = "<script>alert(1)</script>"
        self.save(path.name, spec)
        project = self.save("project.yaml", {"project": {"name": "<img src=x onerror=alert(1)>", "platform": "stm32"}})
        with patch.object(manage, "WORKSPACE", self.root):
            report, output = manage.project_status(str(project), True)
        text = output.read_text(encoding="utf-8")
        self.assertNotIn("<script>", text)
        self.assertIn("&lt;script&gt;", text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
