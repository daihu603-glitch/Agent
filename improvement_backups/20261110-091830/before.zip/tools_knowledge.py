"""领域知识查阅工具：从本地 knowledge/ 目录和 datasheet PDF 中提取信息。"""
from __future__ import annotations

from pathlib import Path

from tools import tool, WORKSPACE

KNOWLEDGE_DIR = Path(__file__).parent / "knowledge"

try:
    import pymupdf as fitz
    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


@tool(
    "query_knowledge",
    "查阅本地知识库（芯片手册摘要、外设驱动参考、代码模板、设计规则）。输入关键词返回相关文档内容。",
    {
        "query": {"type": "string", "description": "查询关键词，如 PCA9685、F103 引脚、I2C 地址"},
        "category": {"type": "string", "description": "限定分类: chips | peripherals | templates | rules，留空搜全部"},
    },
    ["query"],
)
def query_knowledge(query: str, category: str = "") -> str:
    if not KNOWLEDGE_DIR.exists():
        return "错误：knowledge/ 目录不存在"

    search_dir = KNOWLEDGE_DIR / category if category else KNOWLEDGE_DIR
    if not search_dir.exists():
        return f"错误：分类目录不存在: {category}"

    keywords = [k.strip().lower() for k in query.replace("，", ",").split(",") if k.strip()]
    if not keywords:
        keywords = [query.lower()]

    results = []
    for f in sorted(search_dir.rglob("*.md")):
        content = f.read_text(encoding="utf-8", errors="replace")
        lower_content = (str(f.relative_to(KNOWLEDGE_DIR)) + "\n" + content).lower()
        score = sum(1 for kw in keywords if kw in lower_content)
        if score > 0:
            rel = f.relative_to(KNOWLEDGE_DIR)
            results.append((score, str(rel), content))

    if not results:
        available = [str(f.relative_to(KNOWLEDGE_DIR)) for f in KNOWLEDGE_DIR.rglob("*.md")]
        return f"未找到匹配 '{query}' 的文档。可用文档:\n" + "\n".join(f"  - {a}" for a in available)

    results.sort(key=lambda x: -x[0])
    output = []
    for score, name, content in results[:3]:
        output.append(f"=== {name} (相关度 {score}) ===\n{content[:3000]}")
    return "\n\n".join(output)


@tool(
    "read_datasheet",
    "从本地 PDF datasheet 中提取指定章节或关键词相关内容。",
    {
        "path": {"type": "string", "description": "PDF 文件路径"},
        "keywords": {"type": "string", "description": "搜索关键词（逗号分隔）"},
        "pages": {"type": "string", "description": "指定页码范围如 10-20，留空搜全部"},
        "max_chars": {"type": "integer", "description": "最大返回字符数，默认 5000"},
    },
    ["path", "keywords"],
)
def read_datasheet(path: str, keywords: str, pages: str = "", max_chars: int = 5000) -> str:
    if not HAS_PYMUPDF:
        return "错误：未安装 PyMuPDF，请 pip install pymupdf"
    p = Path(path)
    if not p.is_absolute():
        p = WORKSPACE / path
    if not p.exists():
        return f"错误：文件不存在: {path}"

    doc = fitz.open(str(p))
    page_range = range(len(doc))
    if pages:
        try:
            parts = pages.split("-")
            start = int(parts[0]) - 1
            end = int(parts[-1]) if len(parts) > 1 else start + 1
            page_range = range(max(0, start), min(len(doc), end))
        except ValueError:
            pass

    kws = [k.strip().lower() for k in keywords.split(",") if k.strip()]
    collected = []
    total = 0
    for i in page_range:
        text = doc[i].get_text()
        paragraphs = text.split("\n\n")
        for para in paragraphs:
            if any(kw in para.lower() for kw in kws):
                snippet = para.strip()[:800]
                collected.append(f"[第{i+1}页] {snippet}")
                total += len(snippet)
                if total >= max_chars:
                    break
        if total >= max_chars:
            break

    doc.close()
    if not collected:
        return f"在 {Path(path).name} 中未找到包含 '{keywords}' 的内容（共 {len(doc)} 页）。"
    return f"来源: {Path(path).name}\n\n" + "\n\n".join(collected)


@tool(
    "list_knowledge",
    "列出知识库中所有可用文档。",
    {},
    [],
)
def list_knowledge() -> str:
    if not KNOWLEDGE_DIR.exists():
        return "knowledge/ 目录为空"
    files = sorted(KNOWLEDGE_DIR.rglob("*"))
    docs = [str(f.relative_to(KNOWLEDGE_DIR)) for f in files if f.is_file()]
    return f"知识库文档 ({len(docs)}):\n" + "\n".join(f"  {d}" for d in docs)