"""嵌入式智能体全局配置，从 config.yaml 加载。"""
from __future__ import annotations

import os
from pathlib import Path

import yaml

_CONFIG_PATH = Path(os.environ.get("AGENT_CONFIG", Path(__file__).parent / "config.yaml"))


def _load() -> dict:
    if _CONFIG_PATH.exists():
        return yaml.safe_load(_CONFIG_PATH.read_text(encoding="utf-8")) or {}
    return {}


_cfg = _load()

hardware = _cfg.get("hardware", {})
toolchain = _cfg.get("toolchain", {})
serial_cfg = hardware.get("stm32", {})
esp32_cfg = hardware.get("esp32", {})
android_cfg = _cfg.get("android", {})
ai_cfg = _cfg.get("ai", {})
agent_cfg = _cfg.get("agent", {})
opcua_cfg = _cfg.get("opcua", {})

ARM_GCC = toolchain.get("arm_gcc", "")
CUBEIDE = toolchain.get("cubeide", "")
PROGRAMMER_CLI = toolchain.get("programmer_cli", "")
IDF_PATH = esp32_cfg.get("idf_path", "")
ANDROID_SDK = android_cfg.get("sdk_root", "")
ANDROID_JDK = android_cfg.get("jdk_home", "")
ANDROID_BUILD_TOOLS = str(android_cfg.get("build_tools", ""))
ANDROID_PLATFORM = android_cfg.get("platform", "android-35")
ANDROID_GRADLE = android_cfg.get("gradle", "")
AI_EVAL_TOOLS = list(ai_cfg.get("eval_tool_allowlist", ["calculator", "read_file", "list_files", "query_knowledge"]))
AI_EVAL_MAX_STEPS = int(ai_cfg.get("eval_max_steps", 8))
AGENT_PROVIDER = os.environ.get("AGENT_PROVIDER", str(agent_cfg.get("provider", "anthropic"))).strip().lower().replace("_", "-")
_MODEL_DEFAULTS = {"anthropic": "claude-sonnet-5-5", "deepseek": "deepseek-chat", "openai": "gpt-4o-mini", "openai-compatible": ""}
_URL_DEFAULTS = {"anthropic": "", "deepseek": "https://api.deepseek.com", "openai": "https://api.openai.com/v1", "openai-compatible": ""}
_KEY_ENV_DEFAULTS = {"anthropic": "ANTHROPIC_API_KEY", "deepseek": "DEEPSEEK_API_KEY", "openai": "OPENAI_API_KEY", "openai-compatible": "OPENAI_API_KEY"}
AGENT_MODEL = os.environ.get("AGENT_MODEL", str(agent_cfg.get("model") or _MODEL_DEFAULTS.get(AGENT_PROVIDER, "")))
AGENT_BASE_URL = os.environ.get("AGENT_BASE_URL", str(agent_cfg.get("base_url") or _URL_DEFAULTS.get(AGENT_PROVIDER, ""))).rstrip("/")
AGENT_API_KEY_ENV = os.environ.get("AGENT_API_KEY_ENV", str(agent_cfg.get("api_key_env") or _KEY_ENV_DEFAULTS.get(AGENT_PROVIDER, "")))
AGENT_MAX_STEPS = int(os.environ.get("AGENT_MAX_STEPS", str(agent_cfg.get("max_steps", 30))))
AGENT_PROJECT_ROOTS = list(agent_cfg.get("project_roots", []))
_configured_workspace = Path(str(agent_cfg.get("workspace", "./workspace"))).expanduser()
AGENT_WORKSPACE = (_configured_workspace if _configured_workspace.is_absolute() else Path(__file__).resolve().parent / _configured_workspace).resolve()


def get_adb() -> Path | None:
    configured = android_cfg.get("adb", "")
    candidates = [Path(configured)] if configured else []
    if ANDROID_SDK:
        candidates.append(Path(ANDROID_SDK) / "platform-tools" / ("adb.exe" if os.name == "nt" else "adb"))
    return next((p for p in candidates if p.is_file()), None)


def get_java() -> Path | None:
    if not ANDROID_JDK:
        return None
    java = Path(ANDROID_JDK) / "bin" / ("java.exe" if os.name == "nt" else "java")
    return java if java.is_file() else None


def get_arm_gcc_bin() -> Path | None:
    if ARM_GCC:
        p = Path(ARM_GCC)
        if p.exists():
            return p
    ide = Path(CUBEIDE) if CUBEIDE else None
    if ide and ide.exists():
        for gcc in ide.rglob("arm-none-eabi-gcc.exe"):
            return gcc.parent
    return None


def get_cubeide_headless() -> Path | None:
    if CUBEIDE:
        exe = Path(CUBEIDE) / "stm32cubeidec.exe"
        if exe.exists():
            return exe
    return None