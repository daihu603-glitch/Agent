"""编译构建工具：调用 ARM GCC 或 CubeIDE headless 编译 STM32 项目。"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from tools import tool
import config


def _find_make(project_dir: Path) -> str:
    if (project_dir / "Makefile").exists():
        return "make"
    return ""


@tool(
    "build_project",
    "编译 STM32 项目。支持 Makefile（arm-gcc）和 CubeIDE headless 两种方式。返回编译结果和固件大小。",
    {
        "project_dir": {"type": "string", "description": "项目目录的绝对路径"},
        "method": {"type": "string", "description": "编译方式: make | cubeide，默认自动选择"},
        "target": {"type": "string", "description": "Makefile target，默认 all"},
        "clean": {"type": "boolean", "description": "是否先 clean 再编译"},
    },
    ["project_dir"],
)
def build_project(project_dir: str, method: str = "", target: str = "all", clean: bool = False) -> str:
    proj = Path(project_dir)
    if not proj.exists():
        return f"错误：项目目录不存在: {project_dir}"

    gcc_bin = config.get_arm_gcc_bin()
    env = os.environ.copy()
    if gcc_bin:
        env["PATH"] = str(gcc_bin) + os.pathsep + env.get("PATH", "")

    if not method:
        method = "make" if (proj / "Makefile").exists() else "cubeide"

    if method == "make":
        return _build_make(proj, env, target, clean)
    elif method == "cubeide":
        return _build_cubeide(proj)
    else:
        return f"错误：未知编译方式 {method}"


def _build_make(proj: Path, env: dict, target: str, clean: bool) -> str:
    results = []
    if clean:
        r = subprocess.run(
            ["make", "clean"], cwd=str(proj), env=env,
            capture_output=True, text=True, timeout=60
        )
        results.append(f"[clean] exit={r.returncode}")

    try:
        r = subprocess.run(
            ["make", target, "-j4"], cwd=str(proj), env=env,
            capture_output=True, text=True, timeout=180
        )
    except FileNotFoundError:
        return "错误：找不到 make 命令。请安装 make 或使用 cubeide 方式编译。"
    except subprocess.TimeoutExpired:
        return "错误：编译超时（180s）"

    output = r.stdout + r.stderr
    if r.returncode != 0:
        errors = [l for l in output.splitlines() if "error" in l.lower()]
        return f"编译失败 (exit={r.returncode}):\n" + "\n".join(errors[:20]) + "\n\n完整输出末尾:\n" + output[-2000:]

    size_info = ""
    for f in proj.rglob("*.bin"):
        size_info += f"\n  {f.name}: {f.stat().st_size} bytes"
    for f in proj.rglob("*.hex"):
        size_info += f"\n  {f.name}: {f.stat().st_size} bytes"
    for f in proj.rglob("*.elf"):
        size_info += f"\n  {f.name}: {f.stat().st_size} bytes"

    return f"编译成功。\n固件:{size_info}\n\n输出末尾:\n{output[-800:]}"


def _build_cubeide(proj: Path) -> str:
    ide = config.get_cubeide_headless()
    if not ide:
        return "错误：找不到 CubeIDE headless 可执行文件，请检查 config.yaml 中 toolchain.cubeide 路径。"

    workspace = proj.parent / ".agent_cubeide_ws"
    workspace.mkdir(exist_ok=True)

    cmd = [
        str(ide),
        "--launcher.suppressErrors",
        "-nosplash",
        "-application", "org.eclipse.cdt.managedbuilder.core.headlessbuild",
        "-data", str(workspace),
        "-import", str(proj),
        "-build", "all",
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except subprocess.TimeoutExpired:
        return "错误：CubeIDE 编译超时（300s）"

    output = r.stdout + r.stderr
    if r.returncode != 0 or "error" in output.lower():
        errors = [l for l in output.splitlines() if "error" in l.lower()]
        return f"CubeIDE 编译失败:\n" + "\n".join(errors[:20]) + "\n" + output[-1500:]
    return f"CubeIDE 编译成功。\n{output[-800:]}"


@tool(
    "build_esp32",
    "编译 ESP-IDF 项目（idf.py build）。",
    {
        "project_dir": {"type": "string", "description": "ESP-IDF 项目目录"},
        "target": {"type": "string", "description": "目标芯片，默认 esp32s3"},
    },
    ["project_dir"],
)
def build_esp32(project_dir: str, target: str = "") -> str:
    proj = Path(project_dir)
    if not proj.exists():
        return f"错误：目录不存在: {project_dir}"

    import config as cfg
    idf_path = cfg.IDF_PATH or cfg.esp32_cfg.get("idf_path", "")
    if not idf_path:
        return "错误：未配置 ESP-IDF 路径 (config.yaml → hardware.esp32.idf_path)"

    target = target or cfg.esp32_cfg.get("target") or "esp32s3"
    env = os.environ.copy()
    env["IDF_PATH"] = idf_path

    export_script = Path(idf_path) / "export.bat"
    idf_py = Path(idf_path) / "tools" / "idf.py"

    try:
        target_result = subprocess.run(
            ["python", str(idf_py), "set-target", target],
            cwd=str(proj), env=env, capture_output=True, text=True, timeout=60
        )
        target_output = target_result.stdout + target_result.stderr
        if target_result.returncode != 0:
            return f"ESP32 set-target 失败，已禁止继续构建:\n{target_output[-2000:]}"
        sdkconfig = proj / "sdkconfig"
        if sdkconfig.is_file() and f'CONFIG_IDF_TARGET="{target}"' not in sdkconfig.read_text(encoding="utf-8", errors="replace"):
            return f"ESP32 set-target 失败：sdkconfig 未确认目标 {target}，已禁止继续构建"
        r = subprocess.run(
            ["python", str(idf_py), "build"],
            cwd=str(proj), env=env, capture_output=True, text=True, timeout=300
        )
    except subprocess.TimeoutExpired:
        return "错误：ESP32 编译超时（300s）"
    except FileNotFoundError as e:
        return f"错误：{e}"

    output = target_output + "\n" + r.stdout + r.stderr
    if r.returncode != 0:
        errors = [l for l in output.splitlines() if "error" in l.lower()]
        return f"ESP32 编译失败:\n" + "\n".join(errors[:20]) + "\n" + output[-2000:]

    bin_file = proj / "build" / f"{proj.name}.bin"
    size = f" ({bin_file.stat().st_size} bytes)" if bin_file.exists() else ""
    return f"ESP32 编译成功{size}。\n{output[-500:]}"