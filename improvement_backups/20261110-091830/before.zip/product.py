"""客户项目启动器：按 project.yaml 选择平台工作流，或独立执行环境检查/交付门禁。

用法：
  python product.py doctor path/to/project.yaml
  python product.py run path/to/project.yaml --dry-run
  python product.py run path/to/project.yaml
  python product.py gate path/to/project.yaml
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

from workflow import run_workflow

ROOT = Path(__file__).parent.resolve()
WORKFLOWS = {
    "stm32": "stm32_product.yaml",
    "linux_driver": "linux_driver_product.yaml",
    "linux_app": "linux_app_product.yaml",
    "esp32": "esp32_product.yaml",
    "rk3588": "rk3588_product.yaml",
    "android_app": "android_app_product.yaml",
    "ai_agent_app": "ai_agent_app_product.yaml",
    "device_app_ai": "device_app_ai_product.yaml",
    "opc_ua": "opc_ua_product.yaml",
}


def _project(path: str) -> tuple[Path, dict]:
    p = Path(path).resolve()
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    project = data.get("project", {})
    if project.get("platform") not in WORKFLOWS:
        raise ValueError(f"project.platform 必须为 {sorted(WORKFLOWS)}")
    if not project.get("name"):
        raise ValueError("缺少 project.name")
    return p, data


def _vars(config_path: Path, data: dict) -> dict:
    project = data["project"]
    hardware = data.get("hardware", {})
    build = data.get("build", {})
    ai = data.get("ai", {})
    components = data.get("components", {})
    base = config_path.parent
    spec = Path(project.get("requirement_spec", "requirements.yaml"))
    source = Path(project.get("source_dir", "")) if project.get("source_dir") else base

    def path_value(value) -> str:
        path = Path(str(value))
        return str(path if path.is_absolute() else (base / path).resolve())

    variables = {
        "spec_path": str(spec if spec.is_absolute() else (base / spec).resolve()),
        "project_dir": str(source if source.is_absolute() else (base / source).resolve()),
        "version": str(project.get("version", "0.1.0")),
        "serial_port": str(hardware.get("serial_port", "")),
        "target": str(hardware.get("chip") or "esp32s3") if project["platform"] == "esp32" else "",
        "use_wsl": str(build.get("use_wsl", False)).lower(),
        "jobs": str(build.get("jobs", 4)),
        "android_serial": str(hardware.get("android_serial", "")),
        "build_method": str(build.get("method", "auto")),
        "gradle_task": str(build.get("gradle_task", "assembleDebug")),
        "agent_design": path_value(ai.get("design", "agent_design.yaml")),
        "eval_dataset": path_value(ai.get("eval_dataset", "agent_eval.yaml")),
        "backend_dir": path_value(ai.get("backend_dir") or components.get("backend_dir") or source),
        "firmware_dir": path_value(components.get("firmware_dir") or source),
        "android_dir": path_value(components.get("android_dir") or source),
    }
    for key in ("sdk_root", "board_config", "kdir", "module_name", "toolchain_file", "update_img", "partitions", "build_script"):
        if key in build:
            variables[key] = str(build[key])
    for key in ("stress_command", "stress_expect", "stress_cycles"):
        if key in data.get("acceptance", {}):
            variables[key] = str(data["acceptance"][key])
    return variables


def _register_project_roots(variables: dict) -> None:
    import tools
    for key, alias in (("project_dir", "source"), ("backend_dir", "backend"), ("firmware_dir", "firmware"), ("android_dir", "android")):
        path = Path(variables[key])
        if path.is_dir():
            tools.register_project_root(str(path), alias)


def doctor(data: dict) -> str:
    platform_name = data["project"]["platform"]
    variables = _vars(Path(data["_config_path"]), data)
    if platform_name == "stm32":
        from tools_stm32 import stm32_environment_check
        return stm32_environment_check(variables["project_dir"])
    if platform_name == "linux_driver":
        from tools_linux import linux_environment_check
        return linux_environment_check(kdir=variables.get("kdir", ""), use_wsl=variables["use_wsl"] == "true")
    if platform_name == "linux_app":
        from tools_linux import linux_environment_check
        from tools_remote import device_health
        return linux_environment_check(use_wsl=variables["use_wsl"] == "true") + "\n" + device_health()
    if platform_name == "esp32":
        from tools_knowledge import query_knowledge
        import config
        idf = Path(config.IDF_PATH) if config.IDF_PATH else None
        idf_status = "未配置" if not idf else ("存在" if idf.exists() else "不存在")
        return f"IDF_PATH: {idf or '未配置'} ({idf_status})\n项目: {variables['project_dir']}\ntarget: {variables['target']}\n" + query_knowledge("ESP32", "platforms")
    if platform_name == "rk3588":
        from tools_rk3588 import rk3588_environment_check
        return rk3588_environment_check(sdk_root=variables.get("sdk_root", ""), build_script=variables.get("build_script", ""))
    if platform_name == "android_app":
        from tools_android import android_environment_check
        return android_environment_check(variables["project_dir"])
    if platform_name == "ai_agent_app":
        from tools_ai_agent import validate_agent_design
        return f"AI 后端: {variables['backend_dir']}\n" + validate_agent_design(variables["agent_design"])
    if platform_name == "device_app_ai":
        from tools_android import android_environment_check
        from tools_ai_agent import validate_agent_design
        return (
            f"固件目录: {variables['firmware_dir']}\nAI 后端: {variables['backend_dir']}\n"
            + android_environment_check(variables["android_dir"])
            + "\n"
            + validate_agent_design(variables["agent_design"])
        )
    if platform_name == "opc_ua":
        from tools_opcua import opcua_environment_check
        return f"项目: {variables['project_dir']}\n" + opcua_environment_check()
    return "未知平台"


def main() -> int:
    parser = argparse.ArgumentParser(description="嵌入式、Android、AI 与 OPC UA 产品启动器")
    parser.add_argument("command", choices=("run", "doctor", "gate"))
    parser.add_argument("project_file")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--resume", default="")
    parser.add_argument("--yes", "-y", action="store_true", help="明确授权跳过硬件/交付确认")
    parser.add_argument("--set", action="append", default=[], help="覆盖变量 key=value")
    args = parser.parse_args()
    try:
        config_path, data = _project(args.project_file)
        data["_config_path"] = str(config_path)
        variables = _vars(config_path, data)
        _register_project_roots(variables)
        if args.command == "doctor":
            print(doctor(data))
            return 0
        if args.command == "gate":
            from tools_requirements import traceability_report
            from tools_delivery import check_delivery_gate
            print(traceability_report(variables["spec_path"]))
            gate = check_delivery_gate(variables["spec_path"])
            print(gate)
            return 0 if gate.startswith("DELIVERY_PASS") else 1
        variables.update(dict(v.split("=", 1) for v in args.set))
        workflow = ROOT / "workflows" / WORKFLOWS[data["project"]["platform"]]
        result = run_workflow(str(workflow), variables, auto_confirm=args.yes, dry_run=args.dry_run, resume_file=args.resume, return_result=True)
        return 0 if result["status"] in {"completed", "dry_run"} else 1
    except (OSError, ValueError, yaml.YAMLError) as e:
        print(f"错误：{e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
