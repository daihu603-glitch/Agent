"""嵌入式故障日志分析与硬件在环压力测试。"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path

from tools import tool, WORKSPACE

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False


@tool(
    "analyze_embedded_log",
    "分析 STM32 HardFault/Watchdog、ESP32 Guru Meditation/backtrace、Linux Oops/panic 日志，给出寄存器与代码定位建议。可传日志文本或工作区文件路径。",
    {
        "log": {"type": "string", "description": "日志文本，或日志文件路径"},
        "platform_name": {"type": "string", "description": "stm32/esp32/linux/rk3588，留空自动判断"},
        "elf_path": {"type": "string", "description": "可选 ELF 文件，用于后续 addr2line 定位"},
    },
    ["log"],
)
def analyze_embedded_log(log: str, platform_name: str = "", elf_path: str = "") -> str:
    p = Path(log)
    if ("\n" not in log and len(log) < 500 and p.is_file()):
        text = p.read_text(encoding="utf-8", errors="replace")
    elif "\n" not in log and len(log) < 500 and (WORKSPACE / log).is_file():
        text = (WORKSPACE / log).read_text(encoding="utf-8", errors="replace")
    else:
        text = log
    lower = text.lower()
    findings = []
    if any(k in lower for k in ("hardfault", "cfsr", "hfsr", "mmfar", "bfar")):
        findings += [
            "检测到 Cortex-M HardFault。保存进入异常时的 r0-r3/r12/lr/pc/xPSR 堆栈和 SCB->CFSR/HFSR/MMFAR/BFAR。",
            "优先检查空指针、数组越界、非对齐访问、除零、栈溢出、中断优先级和已关闭外设时钟。",
            "用 arm-none-eabi-addr2line -e firmware.elf -f -C < stacked PC> 定位源码，map/ELF 必须与烧录固件一致。",
        ]
    if "assert" in lower or "assert_param" in lower:
        findings.append("检测到断言：记录文件和行号，检查 HAL 参数、RTOS 对象状态与调用上下文。")
    if any(k in lower for k in ("guru meditation", "backtrace", "xtensa panic", "storeprohibited", "loadprohibited")):
        findings += [
            "检测到 ESP32 异常。Backtrace 地址用 xtensa-esp32s3-elf-addr2line -e <app.elf> -f -C 解析。",
            "StoreProhibited/LoadProhibited 常为空/野指针；Interrupt wdt 检查长时间关中断或死循环；Cache disabled 检查 flash 操作期间 ISR/IRAM_ATTR。",
            "建议启用 Core Dump、CONFIG_COMPILER_OPTIMIZATION_ASSERTIONS_ENABLE，并保存 app.elf、map、sdkconfig。",
        ]
    if any(k in lower for k in ("kernel panic", "kernel oops", "call trace:", "unable to handle kernel")):
        findings += [
            "检测到 Linux 内核异常。保留完整 PC/LR、Call trace、模块列表和 vmlinux/System.map。",
            "用 scripts/faddr2line vmlinux <function+offset> 或 aarch64-linux-gnu-addr2line 定位，调试符号必须与运行内核一致。",
            "重点检查 DMA 一致性、ISR/进程上下文休眠、用户拷贝、资源释放、设备树地址/中断/时钟，并启用 KASAN/lockdep。",
        ]
    if any(k in lower for k in ("i2c", "iic")) and any(k in lower for k in ("timeout", "nack", "arbitration")):
        findings.append("I2C 超时/NACK：核对地址左移、上拉、电源、SCL/SDA 波形、总线锁死恢复和外设复位时序。")
    if "watchdog" in lower or "task wdt" in lower or "interrupt wdt" in lower:
        findings.append("看门狗复位：检查低优先级任务饥饿、长临界区、阻塞 I/O、死锁及喂狗策略，不要仅关闭看门狗掩盖问题。")
    if any(k in lower for k in ("brownout", "undervoltage")):
        findings.append("欠压复位：测量峰值负载电源跌落与纹波，检查供电能力、地线、去耦和连接器压降。")
    if not findings:
        findings.append("未识别常见崩溃特征。请保留复位原因、启动日志、故障前后输入、固件版本、map/ELF 和完整串口日志。")
    addresses = sorted(set(re.findall(r"(?i)\b(?:0x)?[0-9a-f]{8}\b", text)))
    result = "\n".join(f"- {x}" for x in findings)
    if addresses:
        result += "\n\n可尝试定位的地址（需人工筛选 PC/backtrace 地址）:\n" + " ".join(addresses[:30])
    if elf_path:
        result += f"\nELF: {elf_path}（当前工具未自动执行 addr2line，避免误用不匹配工具链）"
    result += "\n\n原始日志末尾:\n" + text[-1800:]
    return result


@tool(
    "run_stress_test",
    "执行硬件在环循环测试：周期发送命令、检查响应关键词、统计失败并保存完整证据。测试执行器前必须在工作流确认。",
    {
        "command": {"type": "string"}, "expect": {"type": "string"},
        "cycles": {"type": "integer"}, "interval": {"type": "number"},
        "port": {"type": "string"}, "baudrate": {"type": "integer"},
        "response_timeout": {"type": "number"},
        "stop_on_fail": {"type": "boolean"},
        "report_name": {"type": "string"},
    },
    ["command", "expect", "cycles"],
)
def run_stress_test(command: str, expect: str, cycles: int, interval: float = 1.0, port: str = "", baudrate: int = 0, response_timeout: float = 2.0, stop_on_fail: bool = False, report_name: str = "stress_report.json") -> str:
    if not HAS_SERIAL:
        return "错误：未安装 pyserial"
    cycles = max(1, min(cycles, 100000))
    interval = max(0.0, min(interval, 3600))
    response_timeout = max(0.1, min(response_timeout, 60))
    if interval + response_timeout > 3600:
        return "错误：单周期等待时间过长"
    from tools_serial import _get_port, _get_baud
    port = _get_port(port)
    baud = _get_baud(baudrate)
    results = {"command": command, "expect": expect, "requested_cycles": cycles, "port": port, "baudrate": baud, "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "pass": 0, "fail": 0, "failures": []}
    started = time.monotonic()
    try:
        with serial.Serial(port, baud, timeout=0.1, write_timeout=5) as ser:
            for i in range(1, cycles + 1):
                ser.reset_input_buffer()
                ser.write((command + "\n").encode())
                ser.flush()
                response = bytearray()
                deadline = time.monotonic() + response_timeout
                while time.monotonic() < deadline:
                    chunk = ser.read(ser.in_waiting or 1)
                    if chunk:
                        response.extend(chunk)
                text = response.decode("utf-8", errors="replace")
                ok = expect.lower() in text.lower()
                results["pass" if ok else "fail"] += 1
                if not ok:
                    results["failures"].append({"cycle": i, "response": text[-1000:], "elapsed": round(time.monotonic() - started, 3)})
                    if stop_on_fail:
                        break
                if i < cycles and interval:
                    time.sleep(interval)
    except serial.SerialException as e:
        results["error"] = f"{type(e).__name__}: {e}"
    results["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    results["duration_seconds"] = round(time.monotonic() - started, 3)
    results["executed_cycles"] = results["pass"] + results["fail"]
    results["result"] = "ABORTED" if results.get("error") else ("PASS" if results["fail"] == 0 and results["executed_cycles"] == cycles else "FAIL")
    out = WORKSPACE / "test_reports" / Path(report_name).name
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    return f"压力测试 {results['result']}: {results['pass']} pass / {results['fail']} fail，{results['duration_seconds']}s\n报告: {out}\n最近失败: {json.dumps(results['failures'][-3:], ensure_ascii=False)}"


@tool(
    "compare_firmware_version",
    "通过串口版本命令确认设备运行版本与本次构建一致，防止用旧固件做无效验收。",
    {
        "expected_version": {"type": "string"}, "command": {"type": "string"},
        "port": {"type": "string"}, "baudrate": {"type": "integer"},
        "build_id": {"type": "string", "description": "可选 Git SHA/构建号，响应中也应包含"},
    },
    ["expected_version"],
)
def compare_firmware_version(expected_version: str, command: str = "version", port: str = "", baudrate: int = 0, build_id: str = "") -> str:
    from tools_serial import serial_send_read
    response = serial_send_read(command, port=port, baudrate=baudrate, timeout=3)
    version_ok = expected_version in response
    build_ok = build_id in response if build_id else True
    status = "PASS" if version_ok and build_ok else "FAIL"
    return f"固件版本核验 {status}: 期望 version={expected_version}, build_id={build_id or '未指定'}\n{response}"
