"""STM32 SDK 环境、固件内存占用、崩溃地址符号化和在线故障快照。"""
from __future__ import annotations

import os
import re
from pathlib import Path

from tools import tool
from procutil import CommandError, run_command
import config


@tool(
    "stm32_environment_check",
    "检查 STM32CubeIDE、ARM GCC、make、ST-Link/OpenOCD、串口和项目 SDK/HAL 文件。",
    {"project_dir": {"type": "string"}},
    [],
)
def stm32_environment_check(project_dir: str = "") -> str:
    lines = []
    gcc = config.get_arm_gcc_bin()
    lines.append(f"ARM GCC bin: {gcc or '未找到'}")
    if gcc:
        try:
            lines.append(run_command([str(gcc / "arm-none-eabi-gcc.exe"), "--version"], timeout=10, max_output=400))
        except CommandError as e:
            lines.append(f"GCC 执行失败: {e}")
    lines.append(f"CubeIDE headless: {config.get_cubeide_headless() or '未找到'}")
    if project_dir:
        p = Path(project_dir)
        lines.append(f"项目: {p} ({'存在' if p.exists() else '不存在'})")
        for pattern in ("*.ioc", "*.ld", "Makefile", "*HAL_Driver*", "*.cproject"):
            files = list(p.rglob(pattern))[:8] if p.exists() else []
            lines.append(f"{pattern}: {len(files)} 个" + ("；例如 " + str(files[0]) if files else ""))
    from tools_serial import serial_list_ports
    lines.append("串口:\n" + serial_list_ports())
    return "\n".join(lines)


@tool(
    "stm32_firmware_size",
    "分析 STM32 ELF 的 Flash/RAM 占用和各段尺寸，检查是否超过指定容量。保留 ELF/map 供 HardFault 定位。",
    {
        "elf_path": {"type": "string"}, "flash_kb": {"type": "integer"}, "ram_kb": {"type": "integer"},
    },
    ["elf_path"],
)
def stm32_firmware_size(elf_path: str, flash_kb: int = 512, ram_kb: int = 64) -> str:
    elf = Path(elf_path).resolve()
    if not elf.is_file():
        return f"错误：ELF 不存在: {elf}"
    gcc = config.get_arm_gcc_bin()
    if not gcc:
        return "错误：未找到 ARM GCC 工具链"
    exe = gcc / ("arm-none-eabi-size.exe" if os.name == "nt" else "arm-none-eabi-size")
    try:
        output = run_command([str(exe), "-A", str(elf)], timeout=30, max_output=10000)
        sizes = {}
        for line in output.splitlines():
            parts = line.split()
            if len(parts) >= 2 and parts[0].startswith("."):
                try:
                    sizes[parts[0]] = int(parts[1])
                except ValueError:
                    pass
        flash = sum(sizes.get(k, 0) for k in (".isr_vector", ".text", ".rodata", ".ARM.extab", ".ARM.exidx", ".init_array", ".fini_array", ".preinit_array", ".data"))
        ram = sum(sizes.get(k, 0) for k in (".data", ".bss", ".heap", ".stack", "._user_heap_stack"))
        problems = []
        if flash > flash_kb * 1024:
            problems.append(f"Flash 超限 {flash}/{flash_kb*1024}")
        if ram > ram_kb * 1024:
            problems.append(f"RAM 估算超限 {ram}/{ram_kb*1024}；注意实际还需栈/堆余量")
        return f"Flash 估算: {flash} bytes / {flash_kb}KB\nRAM 估算: {ram} bytes / {ram_kb}KB\n{'；'.join(problems) or '容量静态检查通过，仍需运行时栈/堆高水位测试'}\n{output}"
    except CommandError as e:
        return f"尺寸分析失败: {e}"


@tool(
    "symbolize_addresses",
    "用 addr2line 将 STM32/ESP32/Linux 崩溃 PC/backtrace 地址映射到函数、文件和行号。ELF 必须与设备运行固件一致。",
    {
        "elf_path": {"type": "string"}, "addresses": {"type": "string", "description": "逗号或空格分隔的 0x 地址"},
        "platform_name": {"type": "string", "description": "stm32/esp32/linux/rk3588"},
        "addr2line_path": {"type": "string", "description": "可选显式工具路径"},
    },
    ["elf_path", "addresses", "platform_name"],
)
def symbolize_addresses(elf_path: str, addresses: str, platform_name: str, addr2line_path: str = "") -> str:
    elf = Path(elf_path).resolve()
    if not elf.is_file():
        return f"错误：ELF 不存在: {elf}"
    addrs = [a for a in re.split(r"[\s,]+", addresses.strip()) if a]
    if not addrs or any(not re.match(r"^0x[0-9A-Fa-f]+$", a) for a in addrs):
        return "错误：地址必须是 0x 开头的十六进制，逗号或空格分隔"
    if len(addrs) > 100:
        return "错误：一次最多解析 100 个地址"
    exe = addr2line_path
    if not exe:
        if platform_name == "stm32":
            gcc = config.get_arm_gcc_bin()
            exe = str(gcc / ("arm-none-eabi-addr2line.exe" if os.name == "nt" else "arm-none-eabi-addr2line")) if gcc else ""
        elif platform_name == "esp32":
            target = config.esp32_cfg.get("target", "esp32s3")
            exe = "riscv32-esp-elf-addr2line" if target.startswith(("esp32c", "esp32h")) else f"xtensa-{target}-elf-addr2line"
        elif platform_name in {"linux", "rk3588"}:
            exe = f"{config.toolchain.get('linux_cross_compile', 'aarch64-linux-gnu-')}addr2line"
        else:
            return "错误：platform_name 必须为 stm32/esp32/linux/rk3588"
    try:
        output = run_command([exe, "-e", str(elf), "-f", "-C", "-i", *addrs], timeout=30, max_output=10000)
        unresolved = output.count("??")
        return f"符号化完成，未解析标记 {unresolved} 个。若地址不符，检查 ELF 是否匹配、是否被优化内联、异常地址是否需要减指令长度。\n{output}"
    except CommandError as e:
        return f"符号化失败: {e}"


@tool(
    "stm32_fault_snapshot",
    "通过 OpenOCD halt 目标并读取寄存器及 SCB 故障状态（0xE000ED28 等）。会暂停设备运行，工作流中必须确认。",
    {
        "interface_cfg": {"type": "string"}, "target_cfg": {"type": "string"},
        "resume": {"type": "boolean", "description": "采集后是否继续运行，默认 false 保留故障现场"},
    },
    [],
)
def stm32_fault_snapshot(interface_cfg: str = "interface/stlink.cfg", target_cfg: str = "", resume: bool = False) -> str:
    exe = config.toolchain.get("openocd", "openocd")
    target = target_cfg or config.serial_cfg.get("openocd_cfg", "target/stm32f1x.cfg")
    if any(".." in x or "\n" in x or "\r" in x for x in (interface_cfg, target)):
        return "错误：OpenOCD 配置路径非法"
    args = [exe, "-f", interface_cfg, "-f", target, "-c", "init", "-c", "reset halt", "-c", "reg"]
    for addr in ("0xE000ED28", "0xE000ED2C", "0xE000ED30", "0xE000ED34", "0xE000ED38"):
        args += ["-c", f"mdw {addr}"]
    args += ["-c", "shutdown"]
    output = ""
    snapshot_error = ""
    resume_error = ""
    try:
        output = run_command(args, timeout=45, max_output=12000)
    except CommandError as e:
        snapshot_error = str(e)
    finally:
        if resume:
            resume_args = [exe, "-f", interface_cfg, "-f", target, "-c", "init", "-c", "resume", "-c", "shutdown"]
            try:
                output += "\n独立恢复运行:\n" + run_command(resume_args, timeout=20, max_output=3000)
            except CommandError as e:
                resume_error = str(e)
    if snapshot_error:
        return f"故障快照失败: {snapshot_error}" + (f"\n恢复运行也失败: {resume_error}" if resume_error else "")
    if resume_error:
        return f"故障快照已采集，但恢复运行失败: {resume_error}\n{output}"
    return f"故障快照已采集。CFSR=0xE000ED28, HFSR=0xE000ED2C, DFSR=0xE000ED30, MMFAR=0xE000ED34, BFAR=0xE000ED38。\n请结合异常堆栈 PC 和 symbolize_addresses 定位。\n{output}"
