"""Android APP 环境、构建、静态检查、ADB 联调和发布产物验证。"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import time
import zipfile
from pathlib import Path

import config
from procutil import CommandError, existing_dir, run_command
from tools import WORKSPACE, tool

_TASK = re.compile(r"^[A-Za-z0-9:_-]+$")
_SERIAL = re.compile(r"^[A-Za-z0-9._:-]+$")


def _sdk() -> Path:
    return Path(config.ANDROID_SDK).expanduser() if config.ANDROID_SDK else Path()


def _build_tools() -> Path | None:
    if not config.ANDROID_SDK:
        return None
    root = _sdk() / "build-tools"
    if config.ANDROID_BUILD_TOOLS:
        candidate = root / config.ANDROID_BUILD_TOOLS
        if candidate.is_dir():
            return candidate
    if not root.is_dir():
        return None
    versions = [p for p in root.iterdir() if p.is_dir()]
    if not versions:
        return None
    return max(versions, key=lambda p: [int(x) if x.isdigit() else x for x in re.split(r"[.-]", p.name)])


def _env() -> dict[str, str]:
    env = os.environ.copy()
    if config.ANDROID_SDK:
        env["ANDROID_HOME"] = config.ANDROID_SDK
        env["ANDROID_SDK_ROOT"] = config.ANDROID_SDK
    if config.ANDROID_BUILD_TOOLS:
        env["ANDROID_BUILD_TOOLS"] = config.ANDROID_BUILD_TOOLS
    if config.ANDROID_JDK:
        env["JAVA_HOME"] = config.ANDROID_JDK
        env["PATH"] = str(Path(config.ANDROID_JDK) / "bin") + os.pathsep + env.get("PATH", "")
    return env


def _gradle_command(project: Path) -> list[str]:
    if os.name == "nt" and (project / "gradlew.bat").is_file():
        return ["cmd.exe", "/d", "/c", str(project / "gradlew.bat")]
    if os.name != "nt" and (project / "gradlew").is_file():
        return ["bash", str(project / "gradlew")]
    if config.ANDROID_GRADLE:
        return [config.ANDROID_GRADLE]
    gradle = shutil.which("gradle")
    if gradle:
        return [gradle]
    raise CommandError("找不到 Gradle Wrapper 或全局 Gradle；自定义构建可选择 method=custom")


def _has_gradle(project: Path) -> bool:
    return any((project / name).exists() for name in ("settings.gradle", "settings.gradle.kts"))


def _run_gradle(project_dir: str, tasks: list[str], timeout: int, serial: str = "") -> str:
    project = existing_dir(project_dir, "Android 项目")
    if not _has_gradle(project):
        raise CommandError("缺少 settings.gradle/settings.gradle.kts")
    for task in tasks:
        if not _TASK.fullmatch(task):
            raise CommandError(f"非法 Gradle task: {task}")
    timeout = max(60, min(int(timeout), 3600))
    command = _gradle_command(project) + ["--no-daemon", "--stacktrace"] + tasks
    env = _env()
    if serial:
        if not _SERIAL.fullmatch(serial):
            raise CommandError("ADB 设备序列号格式非法")
        env["ANDROID_SERIAL"] = serial
    return run_command(command, cwd=project, env=env, timeout=timeout, max_output=24000)


def _custom_script(project: Path, build_script: str) -> Path:
    script = (project / build_script).resolve()
    if project.resolve() not in script.parents or not script.is_file():
        raise CommandError("自定义构建脚本必须位于项目目录内且真实存在")
    if script.suffix.lower() != ".ps1":
        raise CommandError("当前自定义构建仅支持项目内 .ps1 脚本")
    return script


def _run_custom(project_dir: str, build_script: str, timeout: int) -> str:
    project = existing_dir(project_dir, "Android 项目")
    script = _custom_script(project, build_script)
    powershell = shutil.which("powershell.exe") or shutil.which("pwsh.exe") or shutil.which("pwsh")
    if not powershell:
        raise CommandError("找不到 PowerShell，无法执行自定义 Android 构建")
    timeout = max(60, min(int(timeout), 3600))
    return run_command(
        [powershell, "-NoProfile", "-File", str(script)],
        cwd=project,
        env=_env(),
        timeout=timeout,
        max_output=24000,
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _new_artifacts(project: Path, started: float) -> list[Path]:
    files = []
    for pattern in ("*.apk", "*.aab"):
        for path in project.rglob(pattern):
            if path.is_file() and path.stat().st_mtime >= started - 2:
                files.append(path)
    return sorted(set(files), key=lambda p: p.stat().st_mtime, reverse=True)


@tool(
    "android_environment_check",
    "检查 Android SDK、JDK、Build Tools、ADB、Gradle/自定义构建脚本及项目结构，不构建或操作设备。",
    {"project_dir": {"type": "string", "description": "Android 项目目录，可选"}},
    [],
)
def android_environment_check(project_dir: str = "") -> str:
    lines = []
    ready = True
    sdk = _sdk()
    sdk_ok = bool(config.ANDROID_SDK) and sdk.is_dir()
    ready &= sdk_ok
    lines.append(f"SDK: {config.ANDROID_SDK or '未配置'} ({'存在' if sdk_ok else '不存在'})")
    android_jar = sdk / "platforms" / config.ANDROID_PLATFORM / "android.jar"
    jar_ok = android_jar.is_file()
    ready &= jar_ok
    lines.append(f"Android 平台: {android_jar} ({'存在' if jar_ok else '不存在'})")
    tools = _build_tools()
    tools_ok = bool(tools and (tools / ("aapt2.exe" if os.name == "nt" else "aapt2")).is_file())
    ready &= tools_ok
    lines.append(f"Build Tools: {tools or '未发现'} ({'可用' if tools_ok else '不可用'})")
    java = config.get_java()
    lines.append(f"JDK: {config.ANDROID_JDK or '未配置'} ({'可用' if java else '不可用'})")
    ready &= bool(java)
    if java:
        try:
            version = run_command([str(java), "-version"], timeout=20, max_output=1000)
            lines.append(f"Java 版本: {version.splitlines()[0]}")
        except CommandError as e:
            ready = False
            lines.append(f"Java 检查失败: {e}")
    adb = config.get_adb()
    lines.append(f"ADB: {adb or '未发现'}")
    if adb:
        try:
            lines.append(f"ADB 版本: {run_command([str(adb), 'version'], timeout=20, max_output=1000).splitlines()[0]}")
        except CommandError as e:
            lines.append(f"ADB 检查失败: {e}")
    else:
        ready = False
    if project_dir:
        try:
            project = existing_dir(project_dir, "Android 项目")
            lines.append(f"项目: {project}")
            wrapper = (project / "gradlew.bat").is_file() or (project / "gradlew").is_file()
            custom = (project / "build.ps1").is_file()
            lines.append(f"Gradle 工程: {'是' if _has_gradle(project) else '否'}；Wrapper: {'是' if wrapper else '否'}；build.ps1: {'是' if custom else '否'}")
            manifest = list((project / "app" / "src").glob("*/AndroidManifest.xml"))
            lines.append(f"APP Manifest: {manifest[0] if manifest else '未在 app/src 下发现'}")
            if not _has_gradle(project) and not custom:
                ready = False
                lines.append("缺少可用构建入口")
        except CommandError as e:
            ready = False
            lines.append(str(e))
    lines.append(f"环境结论: {'ANDROID_ENV_READY' if ready else 'ANDROID_ENV_BLOCKED'}")
    return "\n".join(lines)


@tool(
    "build_android_app",
    "构建 Android APK/AAB。auto 优先 Gradle Wrapper，其次项目 build.ps1；只报告本次新生成的产物。",
    {
        "project_dir": {"type": "string"},
        "method": {"type": "string", "description": "auto | gradle | custom"},
        "task": {"type": "string", "description": "Gradle task，如 assembleDebug、assembleRelease、bundleRelease"},
        "build_script": {"type": "string", "description": "项目内 PowerShell 脚本，默认 build.ps1"},
        "clean": {"type": "boolean"},
        "timeout": {"type": "integer"},
    },
    ["project_dir"],
)
def build_android_app(project_dir: str, method: str = "auto", task: str = "assembleDebug", build_script: str = "build.ps1", clean: bool = False, timeout: int = 1800) -> str:
    try:
        project = existing_dir(project_dir, "Android 项目")
        if method == "auto":
            has_wrapper = (project / "gradlew.bat").is_file() or (project / "gradlew").is_file()
            has_global = bool(config.ANDROID_GRADLE or shutil.which("gradle"))
            method = "gradle" if _has_gradle(project) and (has_wrapper or has_global) else "custom"
        started = time.time()
        if method == "gradle":
            tasks = (["clean"] if clean else []) + [task]
            output = _run_gradle(str(project), tasks, timeout)
        elif method == "custom":
            if clean:
                return "错误：custom 模式的清理策略由项目脚本管理，不自动删除构建目录"
            output = _run_custom(str(project), build_script, timeout)
        else:
            return "错误：method 必须为 auto/gradle/custom"
        artifacts = _new_artifacts(project, started)
        if not artifacts:
            return "ANDROID_BUILD_BLOCKED\n构建命令退出成功，但未发现本次新生成的 APK/AAB；检查 task、脚本输出路径和系统时间。\n" + output[-3000:]
        details = []
        for path in artifacts[:12]:
            details.append(f"- {path} ({path.stat().st_size} bytes)\n  SHA256: {_sha256(path)}")
        return f"ANDROID_BUILD_SUCCESS\nmethod={method}\n" + "\n".join(details) + f"\n\n构建输出末尾:\n{output[-2500:]}"
    except (CommandError, OSError) as e:
        return f"ANDROID_BUILD_FAILED\n{e}"


@tool(
    "android_lint",
    "运行 Android Gradle Lint 并保存完整文本报告到 workspace/logs。",
    {"project_dir": {"type": "string"}, "task": {"type": "string", "description": "默认 lint"}, "timeout": {"type": "integer"}},
    ["project_dir"],
)
def android_lint(project_dir: str, task: str = "lint", timeout: int = 1200) -> str:
    try:
        output = _run_gradle(project_dir, [task], timeout)
        out = WORKSPACE / "logs" / "android_lint.log"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output, encoding="utf-8")
        return f"ANDROID_LINT_COMPLETED\n日志: {out}\n{output[-4000:]}"
    except CommandError as e:
        return f"ANDROID_LINT_FAILED\n{e}"


@tool(
    "android_unit_test",
    "运行 Android 本地 JVM 单元测试，默认 testDebugUnitTest；不代表真机或仪器测试已通过。",
    {"project_dir": {"type": "string"}, "task": {"type": "string"}, "timeout": {"type": "integer"}},
    ["project_dir"],
)
def android_unit_test(project_dir: str, task: str = "testDebugUnitTest", timeout: int = 1200) -> str:
    try:
        output = _run_gradle(project_dir, [task], timeout)
        out = WORKSPACE / "logs" / "android_unit_test.log"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output, encoding="utf-8")
        return f"ANDROID_UNIT_TEST_PASS\n日志: {out}\n{output[-4000:]}"
    except CommandError as e:
        return f"ANDROID_UNIT_TEST_FAILED\n{e}"


@tool(
    "android_instrumented_test",
    "在明确指定的单一 Android 设备上运行 Gradle 仪器测试并保存日志；属于设备操作，工作流必须先确认。",
    {"project_dir": {"type": "string"}, "serial": {"type": "string"}, "task": {"type": "string"}, "timeout": {"type": "integer"}},
    ["project_dir", "serial"],
)
def android_instrumented_test(project_dir: str, serial: str, task: str = "connectedDebugAndroidTest", timeout: int = 1800) -> str:
    if not serial:
        return "ANDROID_INSTRUMENTED_TEST_FAILED\n必须明确 serial，避免误写多台设备"
    try:
        output = _run_gradle(project_dir, [task], timeout, serial=serial)
        out = WORKSPACE / "logs" / "android_instrumented_test.log"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output, encoding="utf-8")
        return f"ANDROID_INSTRUMENTED_TEST_PASS\n设备: {serial}\n日志: {out}\n{output[-4000:]}"
    except CommandError as e:
        return f"ANDROID_INSTRUMENTED_TEST_FAILED\n{e}"


def _adb_command(serial: str = "") -> list[str]:
    adb = config.get_adb()
    if not adb:
        raise CommandError("ADB 不可用，请检查 config.yaml 的 android.sdk_root/adb")
    if serial and not _SERIAL.fullmatch(serial):
        raise CommandError("ADB 设备序列号格式非法")
    return [str(adb)] + (["-s", serial] if serial else [])


@tool(
    "adb_devices",
    "列出 ADB 设备并区分 authorized、unauthorized、offline；不会安装应用或修改设备。",
    {},
    [],
)
def adb_devices() -> str:
    try:
        output = run_command(_adb_command() + ["devices", "-l"], timeout=30, max_output=5000)
        rows = [line for line in output.splitlines()[1:] if line.strip()]
        authorized = [line for line in rows if re.search(r"\sdevice(\s|$)", line)]
        status = "ADB_DEVICE_READY" if len(authorized) == 1 else ("ADB_MULTIPLE_DEVICES" if authorized else "ADB_NO_AUTHORIZED_DEVICE")
        return f"{status}\n{output}\n已授权设备数: {len(authorized)}"
    except CommandError as e:
        return f"ADB_DEVICE_CHECK_FAILED\n{e}"


@tool(
    "adb_install_apk",
    "通过 ADB 安装指定 APK。属于设备写操作，工作流必须先确认；默认不自动授予运行时权限。",
    {"apk_path": {"type": "string"}, "serial": {"type": "string"}, "replace": {"type": "boolean"}, "grant_permissions": {"type": "boolean"}},
    ["apk_path"],
)
def adb_install_apk(apk_path: str, serial: str = "", replace: bool = True, grant_permissions: bool = False) -> str:
    apk = Path(apk_path).resolve()
    if not apk.is_file() or apk.suffix.lower() != ".apk":
        return "ADB_INSTALL_FAILED\nAPK 文件不存在或扩展名不是 .apk"
    try:
        with zipfile.ZipFile(apk) as zf:
            if "AndroidManifest.xml" not in zf.namelist() or zf.testzip():
                return "ADB_INSTALL_FAILED\nAPK ZIP 结构或 CRC 校验失败"
        args = _adb_command(serial) + ["install"]
        if replace:
            args.append("-r")
        if grant_permissions:
            args.append("-g")
        args.append(str(apk))
        output = run_command(args, timeout=300, max_output=6000)
        if not re.search(r"(^|\n)Success(\r?\n|$)", output):
            return f"ADB_INSTALL_FAILED\n{output}"
        return f"ADB_INSTALL_SUCCESS\n设备: {serial or 'ADB 默认设备'}\nAPK: {apk}\n{output}"
    except (CommandError, zipfile.BadZipFile, OSError) as e:
        return f"ADB_INSTALL_FAILED\n{e}"


@tool(
    "adb_capture_logs",
    "导出设备当前 logcat 到 workspace/logs，包含时间戳；不会清空设备日志。",
    {"serial": {"type": "string"}, "lines": {"type": "integer"}, "output_name": {"type": "string"}},
    [],
)
def adb_capture_logs(serial: str = "", lines: int = 1500, output_name: str = "android_logcat.txt") -> str:
    lines = max(100, min(int(lines), 10000))
    try:
        output = run_command(_adb_command(serial) + ["logcat", "-d", "-v", "threadtime", "-t", str(lines)], timeout=90, max_output=4000000)
        safe_name = Path(output_name).name
        if not safe_name or safe_name in {".", ".."}:
            return "错误：日志文件名非法"
        out = WORKSPACE / "logs" / safe_name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output + "\n", encoding="utf-8")
        alerts = [word for word in ("FATAL EXCEPTION", "ANR in", "SIGSEGV", "SecurityException") if word in output]
        return f"日志已保存: {out}\n异常关键词: {alerts or '无'}\n日志末尾:\n{output[-4000:]}"
    except (CommandError, OSError) as e:
        return f"ADB_LOG_CAPTURE_FAILED\n{e}"


@tool(
    "verify_android_artifact",
    "校验 APK/AAB ZIP 完整性、Manifest 和签名；APK 同时读取包版本信息并计算 SHA256。",
    {"artifact_path": {"type": "string"}, "require_signature": {"type": "boolean"}},
    ["artifact_path"],
)
def verify_android_artifact(artifact_path: str, require_signature: bool = True) -> str:
    path = Path(artifact_path).resolve()
    if not path.is_file() or path.suffix.lower() not in {".apk", ".aab"}:
        return "ARTIFACT_VERIFY_FAILED\n文件不存在或仅支持 .apk/.aab"
    errors = []
    details = []
    try:
        with zipfile.ZipFile(path) as zf:
            bad = zf.testzip()
            if bad:
                errors.append(f"ZIP CRC 失败: {bad}")
            if path.suffix.lower() == ".apk" and "AndroidManifest.xml" not in zf.namelist():
                errors.append("APK 缺少根 AndroidManifest.xml")
            if path.suffix.lower() == ".aab" and "base/manifest/AndroidManifest.xml" not in zf.namelist():
                errors.append("AAB 缺少 base/manifest/AndroidManifest.xml")
    except (zipfile.BadZipFile, OSError) as e:
        return f"ARTIFACT_VERIFY_FAILED\n{e}"
    details.append(f"SHA256: {_sha256(path)}")
    if require_signature and not errors:
        try:
            if path.suffix.lower() == ".apk":
                java = config.get_java()
                tools = _build_tools()
                signer = tools / "lib" / "apksigner.jar" if java and tools else None
                if not signer or not signer.is_file():
                    raise CommandError("找不到 JDK 或 apksigner.jar")
                output = run_command([str(java), "-jar", str(signer), "verify", "--verbose", "--print-certs", str(path)], timeout=90, max_output=6000)
            else:
                jarsigner = Path(config.ANDROID_JDK) / "bin" / ("jarsigner.exe" if os.name == "nt" else "jarsigner")
                if not jarsigner.is_file():
                    raise CommandError("找不到 jarsigner")
                output = run_command([str(jarsigner), "-verify", str(path)], timeout=90, max_output=4000)
                if "jar is unsigned" in output.lower():
                    errors.append("AAB 未签名")
            details.append(output)
        except CommandError as e:
            errors.append(f"签名验证失败: {e}")
    if path.suffix.lower() == ".apk" and not errors:
        tools = _build_tools()
        aapt2 = tools / ("aapt2.exe" if os.name == "nt" else "aapt2") if tools else None
        if aapt2 and aapt2.is_file():
            try:
                details.append(run_command([str(aapt2), "dump", "badging", str(path)], timeout=60, max_output=3000))
            except CommandError as e:
                details.append(f"包信息读取警告: {e}")
    status = "ARTIFACT_VERIFY_PASS" if not errors else "ARTIFACT_VERIFY_FAILED"
    return f"{status}\n文件: {path}\n大小: {path.stat().st_size} bytes\n" + "\n".join(details + errors)
