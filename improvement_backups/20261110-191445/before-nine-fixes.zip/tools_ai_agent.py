"""AI 智能体设计校验、最小权限审计、安全扫描和受限工具评测。"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import yaml

import config
import tools
from model_client import api_key_env, has_api_key
from tools import WORKSPACE, tool
from runtime_support import atomic_write, redact_secrets

_SAFE_EVAL_TOOLS = {"calculator", "read_file", "list_files", "query_knowledge"}
_RISKS = {"read", "write", "control", "critical"}
_TOOL_MIN_RISK = {
    "write_file": "write",
    "device_upload": "write",
    "adb_install_apk": "control",
    "device_driver_test": "control",
    "run_stress_test": "control",
    "flash_firmware": "critical",
    "flash_esp32": "critical",
    "flash_rk3588": "critical",
}


def _structured_path(path: str) -> Path:
    p = Path(path)
    return p.resolve() if p.is_absolute() else (WORKSPACE / path).resolve()


def _load_structured(path: str) -> tuple[Path, dict]:
    p = _structured_path(path)
    if not p.is_file():
        raise ValueError(f"文件不存在: {p}")
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("顶层必须是对象")
    return p, data


def _validate_design(data: dict) -> tuple[list[str], list[str]]:
    errors = []
    warnings = []
    for key in ("name", "purpose"):
        if not str(data.get(key, "")).strip():
            errors.append(f"缺少 {key}")
    model = data.get("model", {})
    if not isinstance(model, dict):
        errors.append("model 必须是对象")
    else:
        for key in ("provider", "name"):
            if not str(model.get(key, "")).strip():
                errors.append(f"缺少 model.{key}")
    security = data.get("security", {})
    if not isinstance(security, dict):
        errors.append("security 必须是对象")
        security = {}
    if security.get("secrets_from_env") is not True:
        errors.append("security.secrets_from_env 必须为 true；密钥不得写入客户端、设计文件或仓库")
    hosts = security.get("allowed_hosts", [])
    if not isinstance(hosts, list) or not hosts:
        errors.append("security.allowed_hosts 必须是非空域名白名单")
    else:
        for host in hosts:
            if not isinstance(host, str) or not re.fullmatch(r"[A-Za-z0-9.-]+(?::\d+)?", host) or "*" in host:
                errors.append(f"非法模型/API 域名白名单项: {host}")
    if security.get("data_classification") not in {"public", "internal", "confidential", "restricted"}:
        errors.append("security.data_classification 必须为 public/internal/confidential/restricted")
    retention = security.get("memory_retention_days")
    if not isinstance(retention, int) or isinstance(retention, bool) or not 0 <= retention <= 3650:
        errors.append("security.memory_retention_days 必须为 0..3650 的整数")
    elif retention > 90:
        warnings.append("记忆保留超过 90 天，需确认必要性和删除机制")
    redact = security.get("redact_fields", [])
    if not isinstance(redact, list) or not {"authorization", "api_key", "token", "password"}.issubset({str(x).lower() for x in redact}):
        errors.append("security.redact_fields 至少包含 authorization/api_key/token/password")
    if not str(security.get("untrusted_content_policy", "")).strip():
        errors.append("缺少 security.untrusted_content_policy，需声明提示注入和不可信内容隔离策略")
    if security.get("rag_enabled") and not str(security.get("rag_access_control", "")).strip():
        errors.append("启用 RAG 时必须填写 security.rag_access_control")
    entries = data.get("tools", [])
    if not isinstance(entries, list):
        errors.append("tools 必须是数组")
        entries = []
    seen = set()
    for index, entry in enumerate(entries, 1):
        if not isinstance(entry, dict):
            errors.append(f"第 {index} 个工具不是对象")
            continue
        name = str(entry.get("name", ""))
        label = name or f"第 {index} 个工具"
        if not name:
            errors.append(f"{label}: 缺少 name")
        if name in seen:
            errors.append(f"{label}: 工具定义重复")
        seen.add(name)
        risk = entry.get("risk")
        if risk not in _RISKS:
            errors.append(f"{label}: risk 必须为 read/write/control/critical")
        if not isinstance(entry.get("scopes"), list) or not entry.get("scopes"):
            errors.append(f"{label}: scopes 必须明确最小资源范围")
        if not isinstance(entry.get("confirmation_required"), bool):
            errors.append(f"{label}: confirmation_required 必须为布尔值")
        elif risk in {"write", "control", "critical"} and not entry.get("confirmation_required"):
            errors.append(f"{label}: {risk} 工具必须人工确认")
    evaluation = data.get("evaluation", {})
    if not isinstance(evaluation, dict):
        errors.append("evaluation 必须是对象")
    else:
        if not str(evaluation.get("dataset", "")).strip():
            errors.append("缺少 evaluation.dataset")
        threshold = evaluation.get("min_pass_rate")
        if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0 < threshold <= 1:
            errors.append("evaluation.min_pass_rate 必须在 (0,1] 区间")
    return errors, warnings


@tool(
    "validate_agent_design",
    "校验 AI 智能体 YAML 设计：模型域名、后端密钥、数据分级、记忆/RAG、工具最小权限、人工确认、日志脱敏和评测阈值。",
    {"design_path": {"type": "string", "description": "智能体设计 YAML，绝对路径或相对工作区路径"}},
    ["design_path"],
)
def validate_agent_design(design_path: str) -> str:
    try:
        path, data = _load_structured(design_path)
        errors, warnings = _validate_design(data)
    except (ValueError, OSError, yaml.YAMLError) as e:
        return f"AGENT_DESIGN_FAILED\n{e}"
    status = "AGENT_DESIGN_FAILED" if errors else "AGENT_DESIGN_PASS"
    lines = [status, f"设计: {path}"]
    lines += [f"错误: {item}" for item in errors]
    lines += [f"警告: {item}" for item in warnings]
    if not errors:
        lines.append("设计结构校验通过不代表后端、模型质量或真实权限配置已经验收。")
    return "\n".join(lines)


@tool(
    "agent_tool_audit",
    "根据智能体设计审计 requested_tools（逗号分隔）是否已声明最小范围、风险等级和必要人工确认。",
    {"design_path": {"type": "string"}, "requested_tools": {"type": "string"}},
    ["design_path", "requested_tools"],
)
def agent_tool_audit(design_path: str, requested_tools: str) -> str:
    try:
        _, data = _load_structured(design_path)
        errors, _ = _validate_design(data)
    except (ValueError, OSError, yaml.YAMLError) as e:
        return f"AGENT_TOOL_AUDIT_FAILED\n{e}"
    requested = [item.strip() for item in requested_tools.split(",") if item.strip()]
    if not requested:
        return "AGENT_TOOL_AUDIT_FAILED\nrequested_tools 不能为空"
    entries = {str(item.get("name")): item for item in data.get("tools", []) if isinstance(item, dict)}
    registered = {item["name"] for item in tools.schemas()}
    rank = {"read": 0, "write": 1, "control": 2, "critical": 3}
    warnings = []
    for name in requested:
        entry = entries.get(name)
        if not entry:
            errors.append(f"{name}: 未在设计 tools 白名单中声明")
            continue
        required_risk = _TOOL_MIN_RISK.get(name)
        if required_risk and rank.get(str(entry.get("risk")), -1) < rank[required_risk]:
            errors.append(f"{name}: 设计风险 {entry.get('risk')} 低于工具要求 {required_risk}")
        if required_risk in {"write", "control", "critical"} and not entry.get("confirmation_required"):
            errors.append(f"{name}: 写设备/控制工具必须确认")
        if name not in registered:
            warnings.append(f"{name}: 当前未注册，需由宿主应用实现同一权限约束")
    status = "AGENT_TOOL_AUDIT_FAILED" if errors else "AGENT_TOOL_AUDIT_PASS"
    return "\n".join([status, f"请求工具: {', '.join(requested)}"] + [f"错误: {e}" for e in errors] + [f"警告: {w}" for w in warnings])


def _eval_cases(data: dict) -> tuple[list[dict], list[str]]:
    cases = data.get("cases", [])
    errors = []
    if not isinstance(cases, list) or not cases:
        return [], ["cases 必须是非空数组"]
    if len(cases) > 50:
        return [], ["单次评测最多 50 条，避免未经确认的批量 API 消耗"]
    threshold = data.get("min_pass_rate", 1.0)
    if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0 < threshold <= 1:
        errors.append("min_pass_rate 必须在 (0,1] 区间")
    safe_default = set(config.AI_EVAL_TOOLS) & _SAFE_EVAL_TOOLS
    ids = set()
    for index, case in enumerate(cases, 1):
        if not isinstance(case, dict):
            errors.append(f"第 {index} 条不是对象")
            continue
        cid = str(case.get("id", ""))
        if not cid or cid in ids:
            errors.append(f"第 {index} 条 id 缺失或重复")
        ids.add(cid)
        if not str(case.get("input", "")).strip():
            errors.append(f"{cid or index}: 缺少 input")
        if not case.get("expected_keywords") and not case.get("expected_tools"):
            errors.append(f"{cid or index}: 至少需要 expected_keywords 或 expected_tools")
        allowed = case.get("allowed_tools", sorted(safe_default))
        if not isinstance(allowed, list) or not all(isinstance(x, str) for x in allowed) or not set(allowed).issubset(_SAFE_EVAL_TOOLS):
            errors.append(f"{cid or index}: allowed_tools 只能包含 {sorted(_SAFE_EVAL_TOOLS)}")
        for key in ("expected_keywords", "expected_tools", "forbidden_keywords", "forbidden_tools"):
            if key in case and (not isinstance(case[key], list) or not all(isinstance(x, str) for x in case[key])):
                errors.append(f"{cid or index}: {key} 必须是字符串数组")
        max_steps = case.get("max_steps", config.AI_EVAL_MAX_STEPS)
        expected_results = case.get("expected_tool_results", {})
        if not isinstance(expected_results, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in expected_results.items()):
            errors.append(f"{cid or index}: expected_tool_results 必须是工具名称到结果字符串的对象")
        if isinstance(max_steps, bool) or not isinstance(max_steps, int) or not 1 <= max_steps <= config.AI_EVAL_MAX_STEPS:
            errors.append(f"{cid or index}: max_steps 必须为 1..{config.AI_EVAL_MAX_STEPS} 的整数")
    return cases, errors


@tool(
    "run_agent_eval",
    "运行当前配置的真实模型 API 评测并保存 JSON 证据。执行层仅允许安全只读/计算工具；需要对应 API Key 环境变量，单次最多 50 条。",
    {"dataset_path": {"type": "string"}, "output_path": {"type": "string", "description": "相对工作区的 JSON 输出路径"}},
    ["dataset_path"],
)
def run_agent_eval(dataset_path: str, output_path: str = "") -> str:
    try:
        key_name = api_key_env()
    except ValueError as e:
        return f"AGENT_EVAL_FAILED\n{e}"
    if not has_api_key():
        return f"AGENT_EVAL_FAILED\n未设置 {key_name}；未调用模型，不能生成通过结论"
    try:
        path, data = _load_structured(dataset_path)
        cases, errors = _eval_cases(data)
    except (ValueError, OSError, yaml.YAMLError) as e:
        return f"AGENT_EVAL_FAILED\n{e}"
    if errors:
        return "AGENT_EVAL_FAILED\n" + "\n".join(f"- {e}" for e in errors)
    if output_path:
        out = (WORKSPACE / output_path).resolve()
        if WORKSPACE not in out.parents or out.suffix.lower() != ".json":
            return "AGENT_EVAL_FAILED\noutput_path 必须是工作区内 .json 路径"
    else:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        out = WORKSPACE / "evaluations" / f"{path.stem}-{stamp}.json"
    from agent import Agent

    safe_default = set(config.AI_EVAL_TOOLS) & _SAFE_EVAL_TOOLS
    results = []
    totals = {"input_tokens": 0, "output_tokens": 0}
    aborted = ""
    for index, case in enumerate(cases):
        if aborted:
            results.append({"id": case.get("id"), "status": "not_run", "reason": aborted})
            continue
        allowed = set(case.get("allowed_tools", sorted(safe_default)))
        max_steps = min(config.AI_EVAL_MAX_STEPS, max(1, int(case.get("max_steps", config.AI_EVAL_MAX_STEPS))))
        system = "你是受限评测智能体。只使用当前白名单工具完成任务；不得请求或编造硬件、SSH、烧录、部署结果。输出简洁中文。"
        try:
            runner = Agent(system=system, verbose=False, allowed_tools=allowed, max_steps=max_steps)
            response = runner.run(str(case["input"]))
        except Exception as e:  # noqa: BLE001
            aborted = redact_secrets(f"API/评测执行中止于 {case.get('id')}: {type(e).__name__}: {e}")
            results.append({"id": case.get("id"), "status": "fail", "error": aborted})
            continue
        called = [call["name"] for call in runner.tool_calls]
        totals["input_tokens"] += runner.usage["input_tokens"]
        totals["output_tokens"] += runner.usage["output_tokens"]
        lower = response.casefold()
        missing = [word for word in case.get("expected_keywords", []) if word.casefold() not in lower]
        forbidden = [word for word in case.get("forbidden_keywords", []) if word.casefold() in lower]
        missing_tools = sorted(set(case.get("expected_tools", [])) - set(called))
        forbidden_tools = sorted(set(case.get("forbidden_tools", [])) & set(called))
        denied_attempts = sorted(set(called) - allowed)
        wrong_results = [name for name, expected in case.get("expected_tool_results", {}).items()
                         if not any(call["name"] == name and call.get("result", "").strip() == expected for call in runner.tool_calls)]
        passed = runner.last_status == "completed" and not any((missing, forbidden, missing_tools, forbidden_tools, denied_attempts, wrong_results))
        results.append({
            "id": case["id"],
            "status": "pass" if passed else "fail",
            "agent_status": runner.last_status,
            "response": response,
            "tool_calls": runner.tool_calls,
            "missing_keywords": missing,
            "forbidden_keywords": forbidden,
            "missing_tools": missing_tools,
            "forbidden_tools_called": forbidden_tools,
            "denied_tool_attempts": denied_attempts,
            "wrong_tool_results": wrong_results,
            "usage": runner.usage,
        })
        if response.startswith("AGENT_ERROR:"):
            aborted = f"API/评测执行中止于 {case.get('id')}: {response}"
    executed = [r for r in results if r["status"] != "not_run"]
    passed_count = sum(r["status"] == "pass" for r in executed)
    pass_rate = passed_count / len(cases)
    threshold = float(data.get("min_pass_rate", 1.0))
    report = {
        "dataset": str(path),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "provider": config.AGENT_PROVIDER,
        "model": config.AGENT_MODEL,
        "safe_tool_allowlist": sorted(safe_default),
        "case_count": len(cases),
        "passed": passed_count,
        "pass_rate_all_cases": pass_rate,
        "required_pass_rate": threshold,
        "usage": totals,
        "aborted": aborted,
        "results": results,
    }
    atomic_write(out, redact_secrets(json.dumps(report, ensure_ascii=False, indent=2)))
    status = "AGENT_EVAL_PASS" if not aborted and pass_rate >= threshold else "AGENT_EVAL_FAILED"
    return f"{status}\n模型: {config.AGENT_PROVIDER}/{config.AGENT_MODEL}\n通过 {passed_count}/{len(cases)}，通过率 {pass_rate:.2%}，要求 {threshold:.2%}\nToken: {totals}\n报告: {out}" + (f"\n{aborted}" if aborted else "")


_SECRET_PATTERNS = [
    ("private_key", "critical", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("anthropic_or_openai_key", "critical", re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b")),
    ("google_api_key", "critical", re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("hardcoded_secret", "critical", re.compile(r"(?i)(?:api[_-]?key|client[_-]?secret|access[_-]?token|password)\s*[=:]\s*[\"'][^\"'\n]{12,}[\"']")),
]
_CODE_PATTERNS = [
    ("shell_true", "high", re.compile(r"\bshell\s*=\s*True\b")),
    ("os_system", "high", re.compile(r"\bos\.system\s*\(")),
    ("dynamic_code_execution", "high", re.compile(r"(?<![\w.])(?:eval|exec)\s*\(")),
    ("tls_verify_disabled", "high", re.compile(r"\bverify\s*=\s*False\b")),
    ("debug_enabled", "medium", re.compile(r"(?i)(?:debuggable|debug)\s*[=:]\s*[\"']?true\b")),
    ("cleartext_traffic", "high", re.compile(r"usesCleartextTraffic\s*=\s*[\"']true[\"']")),
]
_SCAN_SUFFIXES = {".py", ".js", ".ts", ".java", ".kt", ".kts", ".xml", ".json", ".yaml", ".yml", ".toml", ".properties", ".env", ".cfg", ".conf", ".pem", ".key"}
_SKIP_DIRS = {".git", ".gradle", ".idea", ".venv", "venv", "node_modules", "build", "dist", "__pycache__"}


@tool(
    "check_ai_backend_security",
    "静态扫描 AI 后端/APP 源码中的硬编码密钥、私钥、shell=True、动态执行、关闭 TLS 校验和明文流量；只报告位置，不回显秘密。",
    {"project_dir": {"type": "string"}, "output_path": {"type": "string", "description": "相对工作区的 JSON 报告路径"}},
    ["project_dir"],
)
def check_ai_backend_security(project_dir: str, output_path: str = "logs/ai_security_audit.json") -> str:
    root = Path(project_dir).resolve()
    if not root.is_dir():
        return f"AI_SECURITY_AUDIT_FAILED\n目录不存在: {root}"
    findings = []
    scanned = 0
    for path in root.rglob("*"):
        if not path.is_file() or any(part in _SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        if path.suffix.lower() not in _SCAN_SUFFIXES and path.name not in {".env", "local.properties"}:
            continue
        if path.stat().st_size > 1024 * 1024:
            findings.append({"file": path.relative_to(root).as_posix(), "line": 0, "rule": "large_file_not_scanned", "severity": "medium"})
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            findings.append({"file": path.relative_to(root).as_posix(), "line": 0, "rule": f"read_error:{type(e).__name__}", "severity": "medium"})
            continue
        scanned += 1
        for rule, severity, pattern in _SECRET_PATTERNS + _CODE_PATTERNS:
            for match in pattern.finditer(text):
                findings.append({
                    "file": path.relative_to(root).as_posix(),
                    "line": text.count("\n", 0, match.start()) + 1,
                    "rule": rule,
                    "severity": severity,
                })
    findings = findings[:500]
    counts = {level: sum(item["severity"] == level for item in findings) for level in ("critical", "high", "medium")}
    report = {
        "project_dir": str(root),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "scanned_files": scanned,
        "counts": counts,
        "findings": findings,
        "limitations": "静态规则扫描不代表完整安全测试；不会验证密钥是否有效，也不会回显匹配内容。",
    }
    out = (WORKSPACE / output_path).resolve()
    if WORKSPACE not in out.parents or out.suffix.lower() != ".json":
        return "AI_SECURITY_AUDIT_FAILED\noutput_path 必须是工作区内 .json 路径"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    status = "AI_SECURITY_AUDIT_FAILED" if counts["critical"] or counts["high"] else "AI_SECURITY_AUDIT_COMPLETED"
    lines = [status, f"扫描文件: {scanned}，发现: {counts}", f"报告: {out}"]
    lines += [f"- {item['severity']} {item['rule']} {item['file']}:{item['line']}" for item in findings[:40]]
    lines.append("无高危规则命中不等于安全验收通过；仍需人工权限、依赖、网络和运行时测试。")
    return "\n".join(lines)
