"""可插拔模型客户端：Anthropic 与 OpenAI 兼容工具调用协议。"""
from __future__ import annotations

import json
import os
import re
from typing import Any

import config

_PROVIDERS = {"anthropic", "deepseek", "openai", "openai-compatible"}
_BASE_URLS = {"anthropic": "", "deepseek": "https://api.deepseek.com", "openai": "https://api.openai.com/v1", "openai-compatible": ""}
_ENV_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def _attr(value: Any, name: str, default: Any = None) -> Any:
    return value.get(name, default) if isinstance(value, dict) else getattr(value, name, default)


def normalize_provider(provider: str) -> str:
    normalized = str(provider).strip().lower().replace("_", "-")
    if normalized not in _PROVIDERS:
        raise ValueError(f"不支持的模型提供商: {normalized or '(空)'}；可选 {sorted(_PROVIDERS)}")
    return normalized


def api_key_env(provider: str | None = None, configured_name: str | None = None) -> str:
    name = configured_name or config.AGENT_API_KEY_ENV
    if provider and provider != config.AGENT_PROVIDER and not configured_name:
        name = {"anthropic": "ANTHROPIC_API_KEY", "deepseek": "DEEPSEEK_API_KEY"}.get(provider, "OPENAI_API_KEY")
    if not _ENV_NAME.fullmatch(str(name)):
        raise ValueError("agent.api_key_env 必须是环境变量名（如 DEEPSEEK_API_KEY），不能填写真实密钥")
    return str(name)


def has_api_key(provider: str | None = None) -> bool:
    return bool(os.environ.get(api_key_env(provider)))


def _openai_tools(schemas: list[dict]) -> list[dict]:
    return [{
        "type": "function",
        "function": {
            "name": schema["name"],
            "description": schema.get("description", ""),
            "parameters": schema.get("input_schema", {"type": "object", "properties": {}}),
        },
    } for schema in schemas]


def _openai_messages(system: str, messages: list[dict]) -> list[dict]:
    converted = [{"role": "system", "content": system}] if system else []
    for message in messages:
        role = message.get("role", "")
        content = message.get("content", "")
        if isinstance(content, str):
            if role not in {"user", "assistant"}:
                raise ValueError(f"不支持的消息角色: {role}")
            converted.append({"role": role, "content": content})
            continue
        if role == "assistant":
            text = []
            calls = []
            for block in content:
                block_type = _attr(block, "type", "")
                if block_type == "text":
                    text.append(str(_attr(block, "text", "")))
                elif block_type == "tool_use":
                    call_id = str(_attr(block, "id", ""))
                    name = str(_attr(block, "name", ""))
                    arguments = _attr(block, "input", {}) or {}
                    if not call_id or not name or not isinstance(arguments, dict):
                        raise ValueError("assistant 工具调用缺少有效 id、name 或对象参数")
                    calls.append({
                        "id": call_id,
                        "type": "function",
                        "function": {"name": name, "arguments": json.dumps(arguments, ensure_ascii=False)},
                    })
                else:
                    raise ValueError(f"不支持的 assistant 消息块: {block_type}")
            assistant_message = {"role": "assistant", "content": "".join(text) or None}
            if calls:
                assistant_message["tool_calls"] = calls
            converted.append(assistant_message)
        elif role == "user":
            for block in content:
                block_type = _attr(block, "type", "")
                if block_type == "tool_result":
                    call_id = str(_attr(block, "tool_use_id", ""))
                    if not call_id:
                        raise ValueError("tool_result 缺少 tool_use_id")
                    converted.append({"role": "tool", "tool_call_id": call_id, "content": str(_attr(block, "content", ""))})
                elif block_type == "text":
                    converted.append({"role": "user", "content": str(_attr(block, "text", ""))})
                else:
                    raise ValueError(f"不支持的 user 消息块: {block_type}")
        else:
            raise ValueError(f"不支持的消息角色: {role}")
    return converted


def _response_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(str(_attr(part, "text", "")) for part in content if _attr(part, "type", "") in {"text", "output_text"})
    raise ValueError("模型 message.content 类型不受支持")


def _normalize_openai_response(response: Any) -> dict:
    choices = list(_attr(response, "choices", []) or [])
    if not choices:
        raise ValueError("模型响应缺少 choices")
    choice = choices[0]
    message = _attr(choice, "message", None)
    if message is None:
        raise ValueError("模型响应缺少 message")
    text = _response_text(_attr(message, "content", ""))
    content = [{"type": "text", "text": text}] if text else []
    raw_calls = list(_attr(message, "tool_calls", []) or [])
    for call in raw_calls:
        function = _attr(call, "function", None)
        call_id = str(_attr(call, "id", ""))
        name = str(_attr(function, "name", ""))
        arguments = _attr(function, "arguments", "{}") or "{}"
        if not call_id or not name:
            raise ValueError("模型工具调用缺少 id 或 function.name")
        try:
            parsed = json.loads(arguments) if isinstance(arguments, str) else arguments
        except (json.JSONDecodeError, TypeError) as exc:
            raise ValueError(f"工具 {name} 的 arguments 不是合法 JSON") from exc
        if not isinstance(parsed, dict):
            raise ValueError(f"工具 {name} 的 arguments 必须是 JSON 对象")
        content.append({"type": "tool_use", "id": call_id, "name": name, "input": parsed})
    finish_reason = str(_attr(choice, "finish_reason", "") or "")
    stop_reason = "tool_use" if raw_calls else {"stop": "end_turn", "length": "max_tokens", "tool_calls": "tool_use"}.get(finish_reason, finish_reason)
    usage = _attr(response, "usage", {}) or {}
    return {
        "content": content,
        "stop_reason": stop_reason,
        "usage": {
            "input_tokens": _attr(usage, "prompt_tokens", 0) or 0,
            "output_tokens": _attr(usage, "completion_tokens", 0) or 0,
        },
    }


class OpenAICompatibleMessages:
    def __init__(self, client: Any):
        self._client = client

    def create(self, *, model: str, max_tokens: int, system: str, tools: list[dict], messages: list[dict]) -> dict:
        request = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": _openai_messages(system, messages),
        }
        if tools:
            request["tools"] = _openai_tools(tools)
        response = self._client.chat.completions.create(**request)
        return _normalize_openai_response(response)


class OpenAICompatibleClient:
    def __init__(self, client: Any):
        self.messages = OpenAICompatibleMessages(client)


def create_model_client(
    provider: str | None = None,
    base_url: str | None = None,
    configured_api_key_env: str | None = None,
) -> Any:
    selected = normalize_provider(provider or config.AGENT_PROVIDER)
    key_name = api_key_env(selected, configured_api_key_env)
    key = os.environ.get(key_name)
    if not key:
        raise RuntimeError(f"未设置模型密钥环境变量 {key_name}")
    if base_url is not None:
        url = base_url
    elif selected == config.AGENT_PROVIDER:
        url = config.AGENT_BASE_URL
    else:
        url = _BASE_URLS[selected]
    if selected == "anthropic":
        import anthropic

        kwargs = {"api_key": key}
        if url:
            kwargs["base_url"] = url
        return anthropic.Anthropic(**kwargs)

    from openai import OpenAI

    kwargs = {"api_key": key}
    if url:
        kwargs["base_url"] = url
    return OpenAICompatibleClient(OpenAI(**kwargs))
