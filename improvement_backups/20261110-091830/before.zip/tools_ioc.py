"""IOC 解析与引脚冲突检测。CubeMX .ioc 文件是 key=value 格式。"""
from __future__ import annotations

import re
from pathlib import Path

from tools import tool

# F103 引脚复用限制（部分关键约束）
F103_SPECIAL_PINS = {
    "PC13": "TAMPER-RTC, 最大 2mA, 仅低速输出",
    "PC14": "OSC32_IN, 最大 2mA, 仅低速输出",
    "PC15": "OSC32_OUT, 最大 2mA, 仅低速输出",
    "PA13": "SWDIO (调试占用，慎用 GPIO)",
    "PA14": "SWCLK (调试占用，慎用 GPIO)",
    "PD0": "OSC_IN (外部晶振占用)",
    "PD1": "OSC_OUT (外部晶振占用)",
    "PB2": "BOOT1 (启动模式引脚)",
}


def _parse_ioc_file(path: Path) -> dict[str, str]:
    entries = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, _, v = line.partition("=")
            entries[k.strip()] = v.strip()
    return entries


def _extract_pins(entries: dict[str, str]) -> list[dict]:
    pins = []
    pin_count = int(entries.get("Mcu.Pins", "0"))
    for i in range(pin_count):
        name = entries.get(f"Mcu.Pin{i}", "")
        if not name:
            continue
        mode = entries.get(f"{name}.Mode", "")
        label = entries.get(f"{name}.GPIO_Label", "")
        pull = entries.get(f"{name}.GPIO_PuPd", "")
        speed = entries.get(f"{name}.GPIO_Speed", "")
        pins.append({
            "pin": name,
            "mode": mode,
            "label": label,
            "pull": pull,
            "speed": speed,
        })
    return pins


def _extract_peripherals(entries: dict[str, str]) -> list[str]:
    ips = entries.get("Mcu.IP Nb", "0")
    result = []
    for i in range(int(ips)):
        ip = entries.get(f"Mcu.IP{i}", "")
        if ip:
            result.append(ip)
    return result


def _extract_clock(entries: dict[str, str]) -> dict[str, str]:
    clock = {}
    for k, v in entries.items():
        if k.startswith("RCC.") and any(
            x in k for x in ("Freq", "Clock", "PLL", "HSE", "HSI", "SYSCLK")
        ):
            clock[k] = v
    return clock


@tool(
    "parse_ioc",
    "解析 STM32 CubeMX .ioc 文件，提取引脚分配、外设列表和时钟配置。",
    {"path": {"type": "string", "description": ".ioc 文件的绝对路径或相对工作区路径"}},
    ["path"],
)
def parse_ioc(path: str) -> str:
    p = Path(path)
    if not p.is_absolute():
        from tools import WORKSPACE
        p = WORKSPACE / path
    p = p.resolve()
    if not p.is_file() or p.suffix.lower() != ".ioc":
        return f"错误：找不到指定 .ioc 文件: {path}；不会自动替换为其他板卡文件"

    entries = _parse_ioc_file(p)
    pins = _extract_pins(entries)
    peripherals = _extract_peripherals(entries)
    clock = _extract_clock(entries)
    mcu = entries.get("Mcu.Name", entries.get("Mcu.Family", "未知"))

    lines = [f"芯片: {mcu}", f"文件: {p.name}", f"\n外设 ({len(peripherals)}):"]
    lines += [f"  - {ip}" for ip in peripherals]
    lines.append(f"\n引脚配置 ({len(pins)}):")
    for pin in pins:
        label_str = f" [{pin['label']}]" if pin["label"] else ""
        lines.append(f"  {pin['pin']}: {pin['mode']}{label_str} pull={pin['pull']} speed={pin['speed']}")
    if clock:
        lines.append("\n时钟配置:")
        for k, v in sorted(clock.items()):
            lines.append(f"  {k} = {v}")
    return "\n".join(lines)


@tool(
    "check_pin_conflict",
    "检测引脚配置冲突：同一引脚被多个外设占用、特殊引脚限制等。输入为 parse_ioc 的输出文本或 .ioc 路径。",
    {"ioc_path": {"type": "string", "description": ".ioc 文件路径"}},
    ["ioc_path"],
)
def check_pin_conflict(ioc_path: str) -> str:
    p = Path(ioc_path)
    if not p.is_absolute():
        from tools import WORKSPACE
        p = WORKSPACE / ioc_path
    p = p.resolve()
    if not p.is_file() or p.suffix.lower() != ".ioc":
        return f"错误：找不到指定 .ioc 文件: {ioc_path}；不会自动替换为其他板卡文件"

    entries = _parse_ioc_file(p)
    pins = _extract_pins(entries)
    issues = []

    seen = {}
    for pin in pins:
        name = pin["pin"]
        if name in seen:
            issues.append(f"冲突: {name} 被配置了两次 ({seen[name]} 和 {pin['mode']})")
        seen[name] = pin["mode"]

        base = re.match(r"P([A-K])(\d+)", name)
        if base:
            key = f"P{base.group(1)}{base.group(2)}"
            if key in F103_SPECIAL_PINS:
                issues.append(f"注意: {key} — {F103_SPECIAL_PINS[key]}")

    if not issues:
        return f"检查通过：{len(pins)} 个引脚配置无冲突。"
    return f"发现 {len(issues)} 个问题:\n" + "\n".join(f"  [{i+1}] {s}" for i, s in enumerate(issues))