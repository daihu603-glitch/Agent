"""代码生成工具：基于 Jinja2 模板生成 HAL 初始化代码和驱动框架。"""
from __future__ import annotations

import re
from pathlib import Path

from tools import tool, _safe_path

try:
    import jinja2
    HAS_JINJA = True
except ImportError:
    HAS_JINJA = False

TEMPLATE_DIR = Path(__file__).parent / "knowledge" / "templates"


def _render(template_name: str, **kwargs) -> str:
    if not HAS_JINJA:
        return "错误：未安装 jinja2，请 pip install jinja2"
    tpl_path = TEMPLATE_DIR / template_name
    if not tpl_path.exists():
        return f"错误：模板不存在: {template_name}"
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(str(TEMPLATE_DIR)), keep_trailing_newline=True)
    tpl = env.get_template(template_name)
    return tpl.render(**kwargs)


@tool(
    "generate_hal_init",
    "根据引脚配置生成 STM32 HAL GPIO 初始化代码（MX_GPIO_Init 函数）。",
    {
        "pins": {"type": "string", "description": "JSON 格式引脚列表，如 [{\"pin\":\"PB12\",\"mode\":\"GPIO_Input\",\"label\":\"KEY1\",\"pull\":\"GPIO_PULLUP\"}]"},
        "output_path": {"type": "string", "description": "输出文件路径（相对工作区），默认 generated/gpio.c"},
    },
    ["pins"],
)
def generate_hal_init(pins: str, output_path: str = "generated/gpio.c") -> str:
    import json
    try:
        pin_list = json.loads(pins)
    except json.JSONDecodeError as e:
        return f"错误：引脚 JSON 解析失败: {e}"

    code = _render("gpio_init.c.j2", pins=pin_list)
    if code.startswith("错误"):
        return code

    out = _safe_path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(code, encoding="utf-8")
    return f"已生成 GPIO 初始化代码: {output_path} ({len(pin_list)} 个引脚)\n\n{code[:1500]}"


@tool(
    "generate_i2c_driver",
    "生成 I2C 外设驱动框架代码（.c + .h）。",
    {
        "device_name": {"type": "string", "description": "设备名如 PCA9685"},
        "i2c_handle": {"type": "string", "description": "HAL I2C 句柄如 hi2c1"},
        "address": {"type": "string", "description": "7位 I2C 地址如 0x40"},
        "output_dir": {"type": "string", "description": "输出目录（相对工作区），默认 generated/"},
    },
    ["device_name", "i2c_handle", "address"],
)
def generate_i2c_driver(device_name: str, i2c_handle: str, address: str, output_dir: str = "generated") -> str:
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", device_name):
        return "错误：device_name 只能包含字母、数字、下划线，且必须以字母开头"
    code_c = _render("i2c_driver.c.j2", device=device_name, handle=i2c_handle, addr=address)
    code_h = _render("i2c_driver.h.j2", device=device_name, handle=i2c_handle, addr=address)
    if code_c.startswith("错误"):
        return code_c

    out_dir = _safe_path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    lower = device_name.lower()
    (out_dir / f"{lower}.c").write_text(code_c, encoding="utf-8")
    (out_dir / f"{lower}.h").write_text(code_h, encoding="utf-8")
    return f"已生成 {device_name} 驱动: {output_dir}/{lower}.c, {output_dir}/{lower}.h\n\n{code_c[:1200]}"


@tool(
    "generate_uart_cmd",
    "生成串口命令解析框架（接收行命令并分发处理）。",
    {
        "commands": {"type": "string", "description": "逗号分隔的命令名列表，如 servo,led,relay,version"},
        "output_path": {"type": "string", "description": "输出文件路径，默认 generated/uart_cmd.c"},
    },
    ["commands"],
)
def generate_uart_cmd(commands: str, output_path: str = "generated/uart_cmd.c") -> str:
    cmd_list = [c.strip() for c in commands.split(",") if c.strip()]
    code = _render("uart_command.c.j2", commands=cmd_list)
    if code.startswith("错误"):
        return code

    out = _safe_path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(code, encoding="utf-8")
    return f"已生成串口命令框架: {output_path} (命令: {cmd_list})\n\n{code[:1500]}"


@tool(
    "generate_makefile",
    "生成 STM32 Makefile（arm-none-eabi-gcc）。",
    {
        "project_name": {"type": "string", "description": "项目名"},
        "mcu": {"type": "string", "description": "MCU 型号如 STM32F103xE"},
        "sources": {"type": "string", "description": "逗号分隔的源文件/目录列表"},
        "output_path": {"type": "string", "description": "输出路径，默认 generated/Makefile"},
    },
    ["project_name", "mcu"],
)
def generate_makefile(project_name: str, mcu: str, sources: str = "Core/Src,Drivers", output_path: str = "generated/Makefile") -> str:
    src_list = [s.strip() for s in sources.split(",") if s.strip()]
    code = _render("makefile.j2", project=project_name, mcu=mcu, sources=src_list)
    if code.startswith("错误"):
        return code

    out = _safe_path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(code, encoding="utf-8")
    return f"已生成 Makefile: {output_path}\n\n{code[:1500]}"