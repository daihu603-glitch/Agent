"""测试执行工具：在目标板上运行测试固件并收集结果。"""
from __future__ import annotations

import time
from pathlib import Path

from tools import tool, WORKSPACE

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False


@tool(
    "run_serial_test",
    "通过串口向目标板发送测试命令序列，收集每条命令的响应，判断 pass/fail。",
    {
        "commands": {"type": "string", "description": "JSON 数组，每项 {\"cmd\": \"...\", \"expect\": \"...\"}，expect 为期望包含的关键词"},
        "port": {"type": "string", "description": "串口号"},
        "baudrate": {"type": "integer", "description": "波特率"},
        "timeout": {"type": "number", "description": "每条命令等待超时秒数，默认 2"},
    },
    ["commands"],
)
def run_serial_test(commands: str, port: str = "", baudrate: int = 0, timeout: float = 2) -> str:
    import json
    if not HAS_SERIAL:
        return "错误：未安装 pyserial"

    try:
        test_cases = json.loads(commands)
    except json.JSONDecodeError as e:
        return f"错误：JSON 解析失败: {e}"

    from tools_serial import _get_port, _get_baud
    port = _get_port(port)
    baud = _get_baud(baudrate)

    results = []
    passed = 0
    failed = 0

    try:
        with serial.Serial(port, baud, timeout=0.1, write_timeout=min(max(timeout, 0.1), 5)) as ser:
            for tc in test_cases:
                cmd = tc.get("cmd", "")
                expect = tc.get("expect", "")
                ser.reset_input_buffer()
                ser.write((cmd + "\n").encode("utf-8"))
                ser.flush()

                collected = []
                deadline = time.time() + timeout
                while time.time() < deadline:
                    raw = ser.readline()
                    if raw:
                        collected.append(raw.decode("utf-8", errors="replace").rstrip())
                        if expect and expect.lower() in "\n".join(collected).lower():
                            break

                resp = "\n".join(collected)
                ok = expect.lower() in resp.lower() if expect else bool(collected)
                status = "PASS" if ok else "FAIL"
                if ok:
                    passed += 1
                else:
                    failed += 1
                results.append(f"[{status}] {cmd!r} → 期望含 '{expect}'\n       实际: {resp[:200]}")
    except serial.SerialException as e:
        report = f"测试中止: ABORTED，已执行 {passed + failed}/{len(test_cases)} 条\n串口错误: {e}\n" + "\n".join(results)
        report_path = WORKSPACE / "test_report.txt"
        report_path.write_text(report, encoding="utf-8")
        return report

    summary = f"测试完成: {passed} passed, {failed} failed, 共 {len(test_cases)} 条\n"
    report = summary + "\n".join(results)

    report_path = WORKSPACE / "test_report.txt"
    report_path.write_text(report, encoding="utf-8")
    return report


@tool(
    "run_build_test",
    "编译测试固件并烧录，然后通过串口收集测试结果（完整闭环）。",
    {
        "project_dir": {"type": "string", "description": "测试项目目录"},
        "test_commands": {"type": "string", "description": "JSON 测试命令数组（同 run_serial_test）"},
        "port": {"type": "string", "description": "串口号"},
    },
    ["project_dir", "test_commands"],
)
def run_build_test(project_dir: str, test_commands: str, port: str = "") -> str:
    from tools_build import build_project
    from tools_flash import flash_firmware

    proj = Path(project_dir).resolve()
    before = {
        path: (path.stat().st_mtime_ns, path.stat().st_size)
        for pattern in ("*.hex", "*.bin")
        for path in proj.rglob(pattern)
    }
    build_result = build_project(str(proj))
    if not build_result.startswith(("编译成功", "CubeIDE 编译成功")):
        return f"测试中止 - 编译失败:\n{build_result}"

    changed = [
        path for pattern in ("*.hex", "*.bin") for path in proj.rglob(pattern)
        if before.get(path) != (path.stat().st_mtime_ns, path.stat().st_size)
    ]
    if not changed:
        return "测试中止 - 本次构建没有产生或更新固件，禁止使用旧固件烧录"
    changed.sort(key=lambda path: (path.stat().st_mtime_ns, path.suffix.lower() == ".hex"), reverse=True)
    fw = changed[0]

    flash_result = flash_firmware(str(fw))
    if not flash_result.startswith(("烧录成功:", "OpenOCD 烧录成功:")):
        return f"测试中止 - 烧录失败:\n{flash_result}"

    time.sleep(1)
    return f"本次烧录固件: {fw}\n{flash_result}\n" + run_serial_test(test_commands, port=port)


@tool(
    "save_test_report",
    "将测试结果保存为结构化报告文件。",
    {
        "title": {"type": "string", "description": "报告标题"},
        "content": {"type": "string", "description": "报告内容"},
        "filename": {"type": "string", "description": "文件名，默认 test_report.md"},
    },
    ["title", "content"],
)
def save_test_report(title: str, content: str, filename: str = "test_report.md") -> str:
    from datetime import datetime
    from tools import _safe_path
    report = f"# {title}\n\n日期: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n{content}"
    out = _safe_path(filename)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report, encoding="utf-8")
    return f"测试报告已保存: {filename}"