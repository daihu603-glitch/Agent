"""SSH/SCP 设备连接、受限命令执行和现场日志采集。"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from tools import tool, WORKSPACE
from procutil import CommandError, run_command
import config

_HOST = re.compile(r"^[A-Za-z0-9_.:-]+$")
_USER = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]*$")
_REMOTE_PATH = re.compile(r"^/(tmp|opt|home|root)/[A-Za-z0-9_./+@-]+$")


def _device(platform_name: str = "linux", host: str = "", user: str = "", port: int = 0, key_path: str = "") -> tuple[str, str, int, str]:
    dev = config.hardware.get(platform_name, {})
    host = host or dev.get("host", "")
    user = user or dev.get("user", "root")
    port = port or int(dev.get("port", 22))
    key_path = key_path or dev.get("key_path", "")
    if not host or not _HOST.match(host):
        raise CommandError("请在 config.yaml 配置合法设备 host，或显式传入 host")
    if not _USER.match(user):
        raise CommandError("SSH 用户名格式非法")
    if not 1 <= int(port) <= 65535:
        raise CommandError("SSH 端口非法")
    return host, user, int(port), key_path


def _ssh_base(host: str, user: str, port: int, key_path: str) -> list[str]:
    cmd = ["ssh", "-p", str(port), "-o", "BatchMode=yes", "-o", "ConnectTimeout=8", "-o", "StrictHostKeyChecking=yes"]
    if key_path:
        if not Path(key_path).is_file():
            raise CommandError(f"SSH 密钥不存在: {key_path}")
        cmd += ["-i", key_path]
    cmd.append(f"{user}@{host}")
    return cmd


def _scp_base(port: int, key_path: str) -> list[str]:
    cmd = ["scp", "-P", str(port), "-o", "BatchMode=yes", "-o", "ConnectTimeout=8", "-o", "StrictHostKeyChecking=yes"]
    if key_path:
        if not Path(key_path).is_file():
            raise CommandError(f"SSH 密钥不存在: {key_path}")
        cmd += ["-i", key_path]
    return cmd


@tool(
    "device_health",
    "采集 Linux/RK3588 设备型号、内核、启动时间、负载、内存、存储和温度，判断设备是否在线。",
    {
        "platform_name": {"type": "string", "description": "linux 或 rk3588"},
        "host": {"type": "string"}, "user": {"type": "string"},
        "port": {"type": "integer"}, "key_path": {"type": "string"},
    },
    [],
)
def device_health(platform_name: str = "linux", host: str = "", user: str = "", port: int = 0, key_path: str = "") -> str:
    if platform_name not in {"linux", "rk3588"}:
        return "错误：platform_name 只能是 linux 或 rk3588"
    try:
        host, user, port, key_path = _device(platform_name, host, user, port, key_path)
        base = _ssh_base(host, user, port, key_path)
        commands = [
            "uname -a",
            "cat /proc/device-tree/model",
            "uptime",
            "free -h",
            "df -h / /userdata",
            "cat /sys/class/thermal/thermal_zone0/temp",
        ]
        results = []
        for command in commands:
            try:
                results.append(f"$ {command}\n{run_command(base + [command], timeout=20, max_output=2500)}")
            except CommandError as e:
                results.append(f"$ {command}\n(不可用: {e})")
        return "\n\n".join(results)
    except CommandError as e:
        return f"设备检查失败: {e}"


@tool(
    "device_run",
    "在设备上执行只读诊断命令。按命令及参数限制 uname/cat/ls/ps/top/free/df/dmesg/journalctl/ss/lsmod/modinfo 等；写操作用专门部署工具。", 
    {
        "command": {"type": "string", "description": "单条只读命令，不允许重定向、管道、后台或命令串联"},
        "platform_name": {"type": "string"}, "host": {"type": "string"}, "user": {"type": "string"},
        "port": {"type": "integer"}, "key_path": {"type": "string"},
        "timeout": {"type": "integer"},
    },
    ["command"],
)
def device_run(command: str, platform_name: str = "linux", host: str = "", user: str = "", port: int = 0, key_path: str = "", timeout: int = 30) -> str:
    stripped = command.strip()
    allowed = {"uname", "cat", "ls", "ps", "top", "free", "df", "dmesg", "journalctl", "ss", "lsmod", "modinfo", "test", "stat", "readlink", "grep", "which"}
    executable = stripped.split(maxsplit=1)[0] if stripped else ""
    if executable not in allowed:
        return f"错误：命令 {executable!r} 不在只读白名单中"
    if re.search(r"[;&|`$<>\n\r]|\.\.", stripped):
        return "错误：只读诊断命令不允许 shell 元字符、重定向或父目录跳转"
    lowered = stripped.lower()
    if executable == "dmesg" and re.search(r"(^|\s)(-c|-C|--clear|--read-clear)(\s|$)", stripped):
        return "错误：dmesg 不允许清除内核日志"
    if executable == "journalctl" and any(flag in lowered for flag in ("--rotate", "--vacuum", "--flush", "--sync", "--update-catalog", "--relinquish")):
        return "错误：journalctl 不允许写入、轮转或清理日志"
    try:
        host, user, port, key_path = _device(platform_name, host, user, port, key_path)
        return run_command(_ssh_base(host, user, port, key_path) + [stripped], timeout=min(timeout, 120))
    except CommandError as e:
        return f"远程命令失败: {e}"


@tool(
    "device_upload",
    "通过 SCP 上传构建产物到设备 /tmp、/opt、/home 或 /root 下的安全路径。覆盖远程文件前需在工作流确认。",
    {
        "local_path": {"type": "string"}, "remote_path": {"type": "string"},
        "platform_name": {"type": "string"}, "host": {"type": "string"}, "user": {"type": "string"},
        "port": {"type": "integer"}, "key_path": {"type": "string"},
    },
    ["local_path", "remote_path"],
)
def device_upload(local_path: str, remote_path: str, platform_name: str = "linux", host: str = "", user: str = "", port: int = 0, key_path: str = "") -> str:
    src = Path(local_path).resolve()
    if not src.is_file():
        return f"错误：本地文件不存在: {src}"
    if not _REMOTE_PATH.match(remote_path) or ".." in remote_path:
        return "错误：远程路径必须位于 /tmp、/opt、/home 或 /root，且不能含特殊字符"
    try:
        host, user, port, key_path = _device(platform_name, host, user, port, key_path)
        base = _ssh_base(host, user, port, key_path)
        parent = str(Path(remote_path).parent).replace("\\", "/")
        run_command(base + [f"mkdir -p {parent}"], timeout=20)
        run_command(_scp_base(port, key_path) + [str(src), f"{user}@{host}:{remote_path}"], timeout=180)
        remote_hash = run_command(base + [f"sha256sum {remote_path}"], timeout=30)
        return f"上传成功: {src.name} → {host}:{remote_path}\n{remote_hash}"
    except CommandError as e:
        return f"上传失败: {e}"


@tool(
    "device_driver_test",
    "在目标机执行内核模块冒烟测试：insmod→检查 lsmod→读取内核日志→rmmod。仅操作指定 .ko 文件，工作流中必须确认。",
    {
        "remote_ko": {"type": "string", "description": "设备上的 .ko 绝对路径"},
        "module_name": {"type": "string"},
        "platform_name": {"type": "string"}, "host": {"type": "string"}, "user": {"type": "string"},
        "port": {"type": "integer"}, "key_path": {"type": "string"},
    },
    ["remote_ko", "module_name"],
)
def device_driver_test(remote_ko: str, module_name: str, platform_name: str = "linux", host: str = "", user: str = "", port: int = 0, key_path: str = "") -> str:
    if not _REMOTE_PATH.match(remote_ko) or not remote_ko.endswith(".ko") or not re.match(r"^[A-Za-z0-9_]+$", module_name):
        return "错误：模块路径或模块名非法"
    try:
        host, user, port, key_path = _device(platform_name, host, user, port, key_path)
        base = _ssh_base(host, user, port, key_path)
    except CommandError as e:
        return f"驱动测试失败: {e}"
    results = []
    try:
        run_command(base + [f"insmod {remote_ko}"], timeout=30)
        results.append("insmod: PASS")
    except CommandError as e:
        return f"驱动加载失败: {e}"
    try:
        try:
            loaded = run_command(base + ["lsmod"], timeout=20)
            results.append("lsmod: PASS" if module_name in loaded else f"lsmod: FAIL，未发现 {module_name}")
        except CommandError as e:
            results.append(f"lsmod: FAIL ({e})")
        try:
            logs = run_command(base + ["dmesg --level=err,warn"], timeout=20)
            results.append(f"内核告警:\n{logs[-3000:]}")
        except CommandError as e:
            results.append(f"内核日志读取失败: {e}")
    finally:
        try:
            run_command(base + [f"rmmod {module_name}"], timeout=30)
            results.append("rmmod: PASS")
        except CommandError as e:
            results.append(f"rmmod: FAIL，需人工检查并卸载: {e}")
    status = "FAIL" if any("FAIL" in item for item in results) else "PASS"
    return f"驱动冒烟测试 {status}\n" + "\n".join(results)


@tool(
    "device_capture_logs",
    "采集内核日志、系统日志和崩溃关键词到本地工作区，供故障分析和交付证据使用。",
    {
        "platform_name": {"type": "string"}, "host": {"type": "string"}, "user": {"type": "string"},
        "port": {"type": "integer"}, "key_path": {"type": "string"},
        "lines": {"type": "integer"}, "output_name": {"type": "string"},
    },
    [],
)
def device_capture_logs(platform_name: str = "linux", host: str = "", user: str = "", port: int = 0, key_path: str = "", lines: int = 300, output_name: str = "device_logs.txt") -> str:
    lines = max(10, min(lines, 5000))
    try:
        host, user, port, key_path = _device(platform_name, host, user, port, key_path)
        base = _ssh_base(host, user, port, key_path)
        sections = []
        for command in (f"journalctl -k -n {lines} --no-pager", f"journalctl -n {lines} --no-pager", "dmesg --level=err,warn"):
            try:
                sections.append(f"$ {command}\n{run_command(base + [command], timeout=40, max_output=20000)}")
            except CommandError as e:
                sections.append(f"$ {command}\n{e}")
        text = f"设备: {user}@{host}\n采集时间: {datetime.now().isoformat()}\n\n" + "\n\n".join(sections)
        out = WORKSPACE / "logs" / Path(output_name).name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        lower = text.lower()
        alerts = [kw for kw in ("kernel panic", "oops", "bug:", "call trace", "segfault", "i/o error") if kw in lower]
        return f"日志已保存: {out}\n异常关键词: {alerts or '无'}\n{text[-3000:]}"
    except CommandError as e:
        return f"日志采集失败: {e}"
