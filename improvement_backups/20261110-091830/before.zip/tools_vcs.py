"""版本控制辅助工具。"""
from __future__ import annotations

import subprocess
from pathlib import Path

from tools import tool


@tool(
    "git_status",
    "查看项目目录的 git 状态。",
    {"project_dir": {"type": "string", "description": "项目目录路径"}},
    ["project_dir"],
)
def git_status(project_dir: str) -> str:
    try:
        r = subprocess.run(
            ["git", "status", "--short"], cwd=project_dir,
            capture_output=True, text=True, timeout=10
        )
        if r.returncode != 0:
            return f"错误：git status 失败(exit={r.returncode}): {r.stderr.strip() or r.stdout.strip()}"
        return r.stdout or "(工作区干净)"
    except FileNotFoundError:
        return "错误：未安装 git"
    except subprocess.TimeoutExpired:
        return "错误：git 超时"


@tool(
    "git_diff",
    "查看项目代码变更（git diff）。",
    {
        "project_dir": {"type": "string", "description": "项目目录路径"},
        "file": {"type": "string", "description": "指定文件，留空看全部变更"},
    },
    ["project_dir"],
)
def git_diff(project_dir: str, file: str = "") -> str:
    cmd = ["git", "diff"]
    if file:
        cmd += ["--", file]
    try:
        r = subprocess.run(cmd, cwd=project_dir, capture_output=True, text=True, timeout=10)
        if r.returncode != 0:
            return f"错误：git diff 失败(exit={r.returncode}): {r.stderr.strip() or r.stdout.strip()}"
        return r.stdout[:5000] or "(无变更)"
    except FileNotFoundError:
        return "错误：未安装 git"
    except subprocess.TimeoutExpired:
        return "错误：git 超时"