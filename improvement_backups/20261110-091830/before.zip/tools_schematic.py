"""原理图读取工具：PDF 文本提取 + 图片描述（供 Claude vision 分析）。"""
from __future__ import annotations

import base64
import io
from pathlib import Path

from tools import tool, WORKSPACE

try:
    import pymupdf as fitz
    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


@tool(
    "read_schematic_pdf",
    "从原理图 PDF 中提取文本（网络标号、元件值、连接关系）。适用于嘉立创 EDA / AD 导出的 PDF。",
    {
        "path": {"type": "string", "description": "PDF 文件路径"},
        "pages": {"type": "string", "description": "页码范围如 1-3，默认全部"},
        "keywords": {"type": "string", "description": "过滤关键词（逗号分隔），只返回包含这些词的行"},
    },
    ["path"],
)
def read_schematic_pdf(path: str, pages: str = "", keywords: str = "") -> str:
    if not HAS_PYMUPDF:
        return "错误：未安装 PyMuPDF，请 pip install pymupdf"
    p = Path(path)
    if not p.is_absolute():
        p = WORKSPACE / path
    if not p.exists():
        return f"错误：文件不存在: {path}"

    kws = [k.strip().lower() for k in keywords.split(",") if k.strip()] if keywords else []
    lines = []
    try:
        with fitz.open(str(p)) as doc:
            page_range = range(len(doc))
            if pages:
                parts = pages.split("-")
                start = int(parts[0]) - 1
                end = int(parts[-1]) if len(parts) > 1 else start + 1
                if start < 0 or end <= start:
                    return "错误：页码范围无效"
                page_range = range(start, min(len(doc), end))
            for i in page_range:
                text = doc[i].get_text()
                for line in text.splitlines():
                    line = line.strip()
                    if line and (not kws or any(kw in line.lower() for kw in kws)):
                        lines.append(f"[p{i+1}] {line}")
    except (OSError, ValueError, RuntimeError) as e:
        return f"错误：PDF 读取失败: {type(e).__name__}: {e}"
    if not lines:
        return "未提取到文本。可能是纯图片 PDF，请用 read_schematic_image 转为图片后分析。"
    return "\n".join(lines[:300])


@tool(
    "read_schematic_image",
    "将原理图图片/PDF页转为 base64 编码，供智能体通过视觉能力分析电路连接。返回图片描述提示。",
    {
        "path": {"type": "string", "description": "图片文件（png/jpg）或 PDF 路径"},
        "page": {"type": "integer", "description": "PDF 页码（从1开始），默认第1页"},
        "dpi": {"type": "integer", "description": "PDF 渲染分辨率，默认 150"},
    },
    ["path"],
)
def read_schematic_image(path: str, page: int = 1, dpi: int = 150) -> str:
    p = Path(path)
    if not p.is_absolute():
        p = WORKSPACE / path
    if not p.exists():
        return f"错误：文件不存在: {path}"

    if not 36 <= dpi <= 300 or page < 1:
        return "错误：dpi 必须在 36-300 之间，page 必须从 1 开始"
    if p.stat().st_size > 20 * 1024 * 1024:
        return "错误：输入文件超过 20MB 限制"
    suffix = p.suffix.lower()
    try:
        if suffix == ".pdf":
            if not HAS_PYMUPDF:
                return "错误：未安装 PyMuPDF"
            with fitz.open(str(p)) as doc:
                if page > len(doc):
                    return f"错误：PDF 只有 {len(doc)} 页，不能读取第 {page} 页"
                pix = doc[page - 1].get_pixmap(dpi=dpi)
                if pix.width * pix.height * 4 > 100 * 1024 * 1024:
                    return "错误：渲染像素超过 100MB 内存限制，请降低 dpi"
                img_data = pix.tobytes("png")
        elif suffix in (".png", ".jpg", ".jpeg", ".bmp"):
            from PIL import Image
            with Image.open(p) as image:
                if image.width * image.height > 40_000_000:
                    return "错误：图片像素超过 4000 万限制"
                buffer = io.BytesIO()
                image.convert("RGB").save(buffer, format="PNG")
                img_data = buffer.getvalue()
        else:
            return f"错误：不支持的文件格式 {suffix}"
    except (OSError, ValueError, RuntimeError) as e:
        return f"错误：图片渲染失败: {type(e).__name__}: {e}"
    if len(img_data) > 20 * 1024 * 1024:
        return "错误：渲染结果超过 20MB 限制"

    b64 = base64.b64encode(img_data).decode()
    out_path = WORKSPACE / "schematic_preview.png"
    out_path.write_bytes(img_data)

    return (f"原理图已渲染为 PNG ({len(img_data)} bytes)，保存到 workspace/schematic_preview.png。\n"
            f"base64 前 100 字符: {b64[:100]}...\n"
            f"请基于此图片分析：电源连接、去耦电容、信号走向、引脚连接是否正确。")


@tool(
    "extract_netlist",
    "从嘉立创 EDA / Altium 导出的 netlist 文件中提取网络连接关系。",
    {
        "path": {"type": "string", "description": "netlist 文件路径（.net / .csv / .txt）"},
    },
    ["path"],
)
def extract_netlist(path: str) -> str:
    p = Path(path)
    if not p.is_absolute():
        p = WORKSPACE / path
    if not p.exists():
        return f"错误：文件不存在: {path}"

    text = p.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    nets = {}
    current_net = ""
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("(") or "=" in line or line.endswith(":"):
            current_net = line.strip("():= ")
            nets.setdefault(current_net, [])
        elif current_net and ("." in line or "-" in line or "U" in line or "R" in line or "C" in line):
            nets[current_net].append(line)

    if not nets:
        return f"无法解析 netlist 格式。文件前 500 字符:\n{text[:500]}"

    result = [f"共 {len(nets)} 个网络:"]
    for net, pins in list(nets.items())[:50]:
        result.append(f"  {net}: {', '.join(pins[:8])}")
    return "\n".join(result)