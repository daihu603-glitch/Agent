# 智能产品全流程交付智能体架构

## 目标

将客户需求转化为可复现、可测试、可追溯、可验收的智能产品，覆盖 STM32、Linux 驱动/应用、ESP32、RK3588、Android APP、AI 智能体后端、三端联调和 OPC UA 工业互联。实际交付能力受 SDK、硬件、模型服务、OPC UA 服务器和客户现场验收条件约束，系统对未执行项显式报告 blocked。

## 分层

```
product.py / agent.py                  项目入口与交互入口
model_client.py                       Anthropic / DeepSeek / OpenAI 兼容协议适配
workflow.py + workflows/*.yaml        步骤编排、确认、重试、条件、断点续跑
需求/设计/实现/构建/调试/验收/交付      产品全生命周期
tools_*.py                            动态注册工具（含只读环境探测）
manage.py + requirement_templates.py 平台需求草案、探测、真实模型最小闭环、HTML 进度报告
knowledge/                            芯片、外设、平台、模板与规则
config.yaml + project.yaml            本机环境与独立客户项目配置
workspace/                            需求、日志、证据、状态与交付包
```

## 平台流水线

| 平台 | 核心流水线 |
|---|---|
| STM32 | IOC/原理图 → HAL/驱动/RTOS → ARM GCC/CubeIDE → ELF/容量 → ST-Link → HardFault/版本/HIL/长稳 |
| Linux 驱动 | 原理图/DTS/KDIR → 内核模块/并发/DMA/ABI → 交叉构建 → SSH/insmod → Oops/KASAN/压力 |
| Linux 应用 | 需求/协议 → CMake/线程/IPC/存储 → 交叉构建 → 服务部署 → 异常恢复/资源/时延长稳 |
| ESP32 | IDF/组件/任务 → 分区/NVS/Wi-Fi/BLE → 构建/尺寸 → 烧录/Core Dump → OTA/回滚/功耗/长稳 |
| RK3588 | BoardConfig/启动链 → U-Boot/kernel/rootfs/驱动/应用 → update.img → Loader 烧录 → 外设/MPP/RGA/NPU/恢复 |
| Android | 需求/协议/权限 → APP 实现 → Gradle/build.ps1 → Lint/单测 → APK/AAB 签名 → ADB/仪器测试/互联验收 |
| AI 智能体 | 场景/数据分级 → 模型/工具/记忆/RAG → 权限与安全审计 → 受限真实评测 → 后端部署 → 质量/成本/恢复验收 |
| 设备＋APP＋AI | 统一契约 → 三端构建与版本绑定 → 分端确认部署 → 命令追踪/故障注入/长稳 → 统一需求门禁 |
| OPC UA | 需求/节点映射 → 信息模型与会话/订阅 → 本地协议仿真 → 证书固定远程只读 → 受控写入 → 异常/长稳/统一交付 |

## AI 执行边界

`model_client.py` 按配置创建 Anthropic 或 OpenAI 兼容客户端，并将 DeepSeek/OpenAI 兼容响应统一为 Agent 的文本、工具调用、结束原因和用量格式；密钥只从指定环境变量读取。`Agent(allowed_tools=...)` 同时限制模型可见 schema 和 `run_tool` 实际执行。评测工具再固定交集到 calculator/read_file/list_files/query_knowledge，数据集或配置不能加入硬件、SSH、烧录和部署能力。智能体设计 YAML 强制声明后端密钥、模型域名、数据分级、记忆保留、RAG ACL、日志脱敏、工具 scopes 和人工确认；模型输出不直接构成设备授权。

## OPC UA 执行边界

`opcua_browse/read/write/subscribe` 只接受 `opc.tcp`。环回演示固定 Anonymous + NoSecurity；非环回 endpoint 必须精确配置在允许列表，并使用 SignAndEncrypt、环境变量凭据、客户端证书和固定服务器证书，另检查证书有效期。写操作同时要求显式确认、完整 NodeId 白名单、标量类型和回读核验。演示证据与客户验收证据分开，不用匿名仿真证明真实 PLC 安全或功能通过。

## 交付数据模型

- `requirements.yaml`：需求基线，每条包含 ID、验收标准、方法、设计/代码/测试追踪。
- `acceptance_results.yaml`：pass/fail/blocked/not_run、证据、测试者和时间。
- `build_environment.json`：SDK、工具版本、源码目录、Git SHA/脏状态。
- `agent_design.yaml` + 评测 JSON：模型/权限/数据边界、逐条响应、工具调用、失败原因、Token 和全量通过率。
- `manifest.json`：项目、版本、门禁、需求结果、产物大小与 SHA256。
- `SHA256SUMS.txt` + 外部 ZIP SHA256：完整性校验。

正式交付门禁要求每条需求追踪完整且真实 pass，证据文件存在。`allow_incomplete` 只能产生 `WAIVED_INTERNAL_ONLY` 内部包，不能通过正式包验证。

## 安全边界

烧录、SSH 部署、ADB 安装/仪器测试、后端部署、真实模型评测、OPC UA 真实端点连接与写入、驱动加载卸载、执行器与压力测试、RK3588 整包写入和正式交付在工作流中需要确认。SSH 诊断使用只读白名单；部署路径受限；模型密钥与 OPC UA 凭据仅由环境变量管理；不自动执行 eFuse、系统清除、强制恢复出厂或不可逆安全配置。

## 验证

工作流状态 schema v2 使用原子替换，保存步骤工具调用和 Token；末行缺少精确状态标记即失败，截断的模型工具响应在执行前拒绝。续跑必须匹配绝对工作流路径、内容与变量，旧版宽松状态不可复用。验收结果保存需求基线指纹与证据 SHA256，修改基线或证据会使旧 pass 失效；新需求模板默认 draft，只有客户评审后显式 approved 才可交付。

`manage.py init/discover/smoke/status` 分别覆盖九个平台的草案生成、串口/USB/SDK 只读枚举、受限真实模型评测＋工具工作流和离线 HTML 进度快照。探测不自动选串口或修改配置，报告不启动服务；无 API Key 的 smoke 只记录 BLOCKED。`python -m unittest test_improvements -v` 覆盖完成标记、续跑串项目、工具截断/重复 ID、需求串平台、证据失效和原子写入失败等负例。

`selftest.py` 离线验证工具注册、全部 YAML dry-run、需求/追踪/证据门禁、交付 ZIP 哈希、ESP32 分区、崩溃日志、AI 设计/权限白名单和项目启动器，并实际运行环回 OPC UA 浏览、读取、写入回读和订阅及越权负例。Android 环境与现有 APK 可独立做只读验证；真实构建、硬件验收、模型评测和真实 OPC UA 设备验收需在对应项目环境中执行，不能以离线自测替代。
