# 需求追踪与验收报告

项目: my-opcua-gateway
平台: opc_ua

| 需求 | 设计 | 代码 | 测试 | 验收 | 证据 |
|---|---|---|---|---|---|
| FR-001 设备版本查询 | 缺失 | 缺失 | 缺失 | blocked | - |
| FR-002 舵机角度控制 | 缺失 | 缺失 | 缺失 | blocked | - |
| NFR-001 连续运行稳定性 | design.md#重连与资源释放 | gateway.py | test_gateway.py::test_server_restart_reconnects_and_restores_subscription, evidence/local_protocol_tests.json | blocked | evidence/local_protocol_tests.json |
| SAFE-001 非授权节点写入保护 | design.md#安全设计 | gateway.py | test_gateway.py::test_10_unauthorized_writes_are_rejected_without_changes, evidence/local_protocol_tests.json | pass | evidence/local_protocol_tests.json |

验收统计: {'not_run': 0, 'fail': 0, 'waived': 0, 'blocked': 3, 'pass': 1}
交付门禁: BLOCKED

## 阻塞项
- FR-001 缺少 trace.design
- FR-001 缺少 trace.code
- FR-001 缺少 trace.tests
- FR-001 验收状态为 blocked
- FR-002 缺少 trace.design
- FR-002 缺少 trace.code
- FR-002 缺少 trace.tests
- FR-002 验收状态为 blocked
- NFR-001 验收状态为 blocked