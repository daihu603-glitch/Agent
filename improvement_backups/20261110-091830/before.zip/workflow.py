"""工作流引擎：YAML 编排、确认门禁、重试、条件、变量文件与断点续跑。"""
from __future__ import annotations

import argparse
import hashlib
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import yaml

from agent import DEFAULT_SYSTEM, Agent
from tools import WORKSPACE

_PLACEHOLDER = re.compile(r"\{\{\s*([\w.]+)\s*\}\}")
_STEP_STATUS = re.compile(r"STEP_STATUS:\s*(COMPLETED|FAILED|BLOCKED)", re.IGNORECASE)
_SENSITIVE_KEY = re.compile(r"password|passwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key", re.IGNORECASE)
_WORKFLOW_SUFFIX = "\n\n这是受状态跟踪的工作流步骤。真实完成后，在最后一行输出 STEP_STATUS: COMPLETED；无法完成输出 STEP_STATUS: FAILED；等待外部条件输出 STEP_STATUS: BLOCKED。不得把 dry-run、缺失工具或未执行验收标记为 COMPLETED。"


def render(text: str, ctx: dict) -> str:
    def sub(m: re.Match) -> str:
        scope, _, key = m.group(1).partition(".")
        try:
            return str(ctx[scope][key])
        except KeyError:
            raise KeyError(f"模板变量未定义: {m.group(1)}") from None
    return _PLACEHOLDER.sub(sub, text)


def _eval_condition(expr: str, ctx: dict) -> bool:
    expr = render(expr, ctx) if "{{" in expr else expr
    if " contains " in expr:
        left, right = expr.split(" contains ", 1)
        return right.strip().strip("'\"").lower() in left.lower()
    if " not_contains " in expr:
        left, right = expr.split(" not_contains ", 1)
        return right.strip().strip("'\"").lower() not in left.lower()
    if expr.strip().lower() in ("true", "yes", "1"):
        return True
    if expr.strip().lower() in ("false", "no", "0", ""):
        return False
    return bool(expr.strip())


def _confirm(title: str) -> bool:
    print(f"\n{'='*50}\n  需要确认: {title}\n{'='*50}")
    while True:
        ans = input("  继续执行？(y/n): ").strip().lower()
        if ans in ("y", "yes", "是"):
            return True
        if ans in ("n", "no", "否"):
            return False
        print("  请输入 y 或 n")


def _redact(value: Any, secrets: list[str], sensitive: bool = False) -> Any:
    if sensitive:
        return "***REDACTED***"
    if isinstance(value, dict):
        return {key: _redact(item, secrets, _SENSITIVE_KEY.search(str(key)) is not None) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact(item, secrets) for item in value]
    if isinstance(value, str):
        result = value
        for secret in secrets:
            result = result.replace(secret, "***REDACTED***")
        return result
    return value


def _save_state(path: Path, workflow: str, fingerprint: str, ctx: dict, step_states: dict, status: str, current_step: str = "") -> None:
    variables = ctx["vars"]
    secrets = [str(value) for key, value in variables.items() if _SENSITIVE_KEY.search(str(key)) and str(value)]
    state = {
        "workflow": workflow,
        "workflow_sha256": fingerprint,
        "status": status,
        "current_step": current_step,
        "updated_at": datetime.now().isoformat(),
        "variables": _redact(variables, secrets),
        "steps": _redact(ctx["steps"], secrets),
        "step_states": dict(step_states),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(state, allow_unicode=True, sort_keys=False), encoding="utf-8")


def _result(status: str, ctx: dict, state_file: Path, run_id: str, return_result: bool) -> dict[str, Any]:
    if return_result:
        return {"status": status, "steps": ctx["steps"], "step_states": ctx["step_states"], "state_file": str(state_file), "run_id": run_id}
    return ctx["steps"]


def run_workflow(
    path: str,
    variables: dict[str, Any],
    auto_confirm: bool = False,
    dry_run: bool = False,
    resume_file: str = "",
    agent_factory: Callable[..., Agent] = Agent,
    return_result: bool = False,
) -> dict[str, Any]:
    spec_path = Path(path).resolve()
    spec_bytes = spec_path.read_bytes()
    fingerprint = hashlib.sha256(spec_bytes).hexdigest()
    spec = yaml.safe_load(spec_bytes.decode("utf-8")) or {}
    if not isinstance(spec.get("steps"), list) or not spec["steps"]:
        raise ValueError("工作流至少需要一个步骤")
    resumed_steps: dict[str, str] = {}
    resumed_states: dict[str, str] = {}
    if resume_file:
        saved = yaml.safe_load(Path(resume_file).read_text(encoding="utf-8")) or {}
        if Path(saved.get("workflow", "")).name != spec_path.name:
            raise ValueError("续跑文件与当前工作流不一致")
        if saved.get("workflow_sha256") != fingerprint:
            raise ValueError("工作流内容已变化，禁止从旧状态续跑")
        resumed_steps = saved.get("steps", {})
        resumed_states = saved.get("step_states", {})
        saved_variables = {key: value for key, value in saved.get("variables", {}).items() if value != "***REDACTED***"}
        variables = {**saved_variables, **variables}
    ctx = {"vars": {**spec.get("vars", {}), **variables}, "steps": dict(resumed_steps), "step_states": dict(resumed_states)}
    name = spec.get("name", path)
    print(f"== 工作流：{name} ==")
    if dry_run:
        print("DRY-RUN：仅展示步骤，不调用模型、工具或硬件。")

    run_id = datetime.now().strftime("%Y%m%d-%H%M%S-%f") + f"-{os.getpid()}"
    result_dir = WORKSPACE / "workflow_results" / spec_path.stem
    state_file = result_dir / f"{run_id}.yaml"
    latest_file = result_dir / "latest.yaml"
    final_status = "dry_run" if dry_run else "completed"
    current_step = ""

    def save(status: str, sid: str) -> None:
        _save_state(state_file, str(spec_path), fingerprint, ctx, ctx["step_states"], status, sid)
        _save_state(latest_file, str(spec_path), fingerprint, ctx, ctx["step_states"], status, sid)

    for step in spec["steps"]:
        sid = step["id"]
        current_step = sid
        title = step.get("title", sid)
        if resumed_states.get(sid) in {"completed", "skipped"}:
            print(f"\n[{sid}] 已从续跑状态恢复，跳过已完成步骤")
            continue

        condition = step.get("condition", "")
        if condition and not _eval_condition(condition, ctx):
            print(f"\n[{sid}] 跳过（条件不满足: {condition}）")
            ctx["steps"][sid] = "(skipped)"
            ctx["step_states"][sid] = "skipped"
            continue

        print(f"\n[{sid}] {title}")
        prompt = render(step["task"], ctx)
        if dry_run:
            print(f"  confirm={bool(step.get('confirm'))} retry={step.get('retry', 0)}\n{prompt[:700]}")
            ctx["steps"][sid] = "(dry-run)"
            ctx["step_states"][sid] = "dry_run"
            continue

        if step.get("confirm") and not auto_confirm and not _confirm(title):
            print(f"[{sid}] 用户取消，工作流暂停。可用 --resume {latest_file} 续跑。")
            ctx["steps"][sid] = "(cancelled)"
            ctx["step_states"][sid] = "cancelled"
            final_status = "cancelled"
            save(final_status, sid)
            break

        system = (step.get("system") or DEFAULT_SYSTEM) + _WORKFLOW_SUFFIX
        retry = max(0, int(step.get("retry", 0)))
        timeout = int(step.get("timeout", 0))
        original_prompt = prompt
        result = ""
        step_state = "failed"
        for attempt in range(retry + 1):
            if attempt > 0:
                print(f"  [重试 {attempt}/{retry}]")
            start = time.time()
            try:
                agent = agent_factory(system=system)
                result = agent.run(prompt)
                agent_status = agent.last_status
            except Exception as e:
                result = f"WORKFLOW_AGENT_ERROR: {type(e).__name__}: {e}"
                agent_status = "failed"
            elapsed = time.time() - start
            if timeout and elapsed > timeout:
                result += f"\n(警告：步骤耗时 {elapsed:.0f}s 超过提示阈值 {timeout}s，并非强制中断)"
            marker = _STEP_STATUS.search(result)
            declared = marker.group(1).lower() if marker else "completed"
            step_state = "completed" if agent_status == "completed" and declared == "completed" else declared if declared in {"failed", "blocked"} else "failed"
            if step_state == "failed" and attempt < retry:
                prompt = f"上一次步骤执行失败，输出如下:\n{result}\n\n请分析原因并重新执行原任务:\n{original_prompt}"
                continue
            break

        ctx["steps"][sid] = result
        ctx["step_states"][sid] = step_state
        if step_state != "completed":
            final_status = "blocked" if step_state == "blocked" else "failed"
            save(final_status, sid)
            print(f"[{sid}] {final_status}：{result[:240]}")
            break
        save("running", sid)
        print(f"[{sid}] 完成：{result[:240]}")

    if not dry_run:
        save(final_status, current_step)
        print(f"\n== 工作流状态 {final_status}，结果: {state_file} ==")
    return _result(final_status, ctx, state_file, run_id, return_result)


def main() -> int:
    ap = argparse.ArgumentParser(description="嵌入式产品工作流引擎")
    ap.add_argument("file", help="工作流 YAML 文件路径")
    ap.add_argument("--var", action="append", default=[], help="key=value，可重复")
    ap.add_argument("--var-file", help="YAML 变量文件，顶层对象或 vars 对象")
    ap.add_argument("--resume", help="从此前 latest.yaml/状态文件恢复已完成步骤")
    ap.add_argument("--dry-run", action="store_true", help="只渲染步骤，不调用模型或硬件")
    ap.add_argument("--yes", "-y", action="store_true", help="明确授权跳过所有人工确认点")
    args = ap.parse_args()
    variables = {}
    if args.var_file:
        data = yaml.safe_load(Path(args.var_file).read_text(encoding="utf-8")) or {}
        variables.update(data.get("vars", data))
    variables.update(dict(v.split("=", 1) for v in args.var))
    try:
        result = run_workflow(args.file, variables, auto_confirm=args.yes, dry_run=args.dry_run, resume_file=args.resume, return_result=True)
    except (KeyError, ValueError, OSError, yaml.YAMLError) as e:
        print(f"错误：{e}", file=sys.stderr)
        return 2
    return 0 if result["status"] in {"completed", "dry_run"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
