"""Deterministic setup, inventory, progress reports and a bounded real-model smoke test."""
from __future__ import annotations

import argparse
import html
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml

from requirement_templates import requirement_template
from runtime_support import atomic_write, ensure_utf8_stdio, redact_secrets
from tools import WORKSPACE, _safe_path

ensure_utf8_stdio()

ROOT = Path(__file__).resolve().parent


def init_project(directory: str, platform: str, name: str = "") -> Path:
    target = _safe_path(directory)
    if target == WORKSPACE or target.exists():
        raise ValueError(f"目标已存在，禁止覆盖: {target}")
    title = name.strip() or target.name
    spec = requirement_template(platform, title)
    project = {"project": {"name": title, "version": "0.1.0", "platform": platform,
                           "requirement_spec": "requirements.yaml", "source_dir": "."},
               "hardware": {"serial_port": "", "baudrate": 115200},
               "build": {"method": "auto" if platform == "android_app" else "", "jobs": 4}}
    if platform in {"ai_agent_app", "device_app_ai"}:
        project["ai"] = {"design": "agent_design.yaml", "eval_dataset": "agent_eval.yaml", "backend_dir": "."}
    target.mkdir(parents=True, exist_ok=False)
    for filename, data in (("project.yaml", project), ("requirements.yaml", spec)):
        atomic_write(target / filename, yaml.safe_dump(data, allow_unicode=True, sort_keys=False))
    if platform in {"ai_agent_app", "device_app_ai"}:
        for filename in ("agent_design", "agent_eval"):
            atomic_write(target / f"{filename}.yaml", (ROOT / f"{filename}.example.yaml").read_text(encoding="utf-8"))
    atomic_write(target / "README.md", f"# {title}\n\n平台: {platform}\n\n需求是待评审草案；先修改真实环境、指标和验收方法。客户评审后设置 `baseline_status: approved`。\n\n不要仅修改平台名称来复用其他平台的需求。混合 OPC UA 项目需声明 `project.interfaces: [serial, actuator, mcu]` 中实际需要的接口。\n\n环境检查: `python product.py doctor \"{target / 'project.yaml'}\"`\n\n进度报告: `python manage.py status \"{target / 'project.yaml'}\" --html`\n")
    return target


def smoke_test() -> tuple[dict, Path]:
    from model_client import api_key_env, has_api_key
    import config
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = WORKSPACE / "model_smoke" / stamp / "report.json"
    report = {"scope": "REAL_MODEL_TOOL_EVAL_WORKFLOW_NOT_HARDWARE_ACCEPTANCE",
              "created_at": datetime.now(timezone.utc).isoformat(), "provider": config.AGENT_PROVIDER,
              "model": config.AGENT_MODEL, "status": "BLOCKED", "reason": "", "evaluation": "", "workflow": {}}
    if not has_api_key():
        report["reason"] = f"未设置 {api_key_env()}；模型、评测和工作流均未调用"
    else:
        from tools_ai_agent import run_agent_eval
        from workflow import run_workflow
        eval_path = output.parent / "evaluation.json"
        evaluation = run_agent_eval(str(ROOT / "agent_eval.example.yaml"), str(eval_path.relative_to(WORKSPACE)))
        report["evaluation"] = evaluation
        if not evaluation.startswith("AGENT_EVAL_PASS"):
            report.update(status="FAIL", reason="真实模型评测失败，未执行后续工作流")
        else:
            workflow = run_workflow(str(ROOT / "workflows/model_smoke.yaml"), {}, return_result=True)
            report["workflow"] = workflow
            report["status"] = "PASS" if workflow["status"] == "completed" else "FAIL"
    atomic_write(output, redact_secrets(json.dumps(report, ensure_ascii=False, indent=2)))
    return report, output


def project_status(project_file: str, html_report: bool = False) -> tuple[dict, Path | None]:
    # This command reads saved evidence. It never resumes a workflow or calls a model.
    from product import _project, _vars
    from tools_requirements import _load_spec, _load_results, _requirements, acceptance_issues
    from tools_delivery import check_delivery_gate
    config_path, project = _project(project_file)
    variables = _vars(config_path, project)
    spec_path, spec = _load_spec(variables["spec_path"])
    results = _load_results(spec_path)["results"]
    rows = []
    for req in _requirements(spec):
        result = results.get(req["id"], {})
        rows.append({"id": req["id"], "title": req["title"], "recorded_status": result.get("status", "not_run"),
                     "issues": acceptance_issues(spec_path, spec, req, result), "evidence": result.get("evidence", "")})
    runs = []
    for latest in (WORKSPACE / "workflow_results").glob("*/latest.yaml"):
        try:
            data = yaml.safe_load(latest.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or data.get("variables", {}).get("project_dir") != variables["project_dir"]:
                continue
            runs.append({"workflow": Path(data["workflow"]).stem, "status": data["status"],
                         "current_step": data.get("current_step", ""), "steps": data.get("step_states", {}), "file": str(latest)})
        except (OSError, KeyError, TypeError, yaml.YAMLError):
            continue
    report = {"project": project["project"]["name"], "platform": project["project"]["platform"],
              "created_at": datetime.now(timezone.utc).isoformat(), "gate": check_delivery_gate(str(spec_path)),
              "requirements": rows, "workflows": runs}
    output = None
    if html_report:
        safe_name = re.sub(r"[^A-Za-z0-9_-]", "_", config_path.parent.name) or "project"
        output = WORKSPACE / "status" / f"{safe_name}.html"
        esc = lambda value: html.escape(str(value), quote=True)
        req_rows = "".join(f"<tr><td>{esc(row['id'])}</td><td>{esc(row['title'])}</td><td>{esc(row['recorded_status'])}</td><td>{esc('; '.join(row['issues']) or '基线和证据一致')}</td><td>{esc(row['evidence'])}</td></tr>" for row in rows)
        run_rows = "".join(f"<tr><td>{esc(run['workflow'])}</td><td>{esc(run['status'])}</td><td>{esc(run['current_step'])}</td><td>{esc(json.dumps(run['steps'], ensure_ascii=False))}</td></tr>" for run in runs)
        document = ("<!doctype html><html lang='zh-CN'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                    "<title>项目进度与证据</title><style>body{font:16px/1.7 system-ui;margin:32px auto;padding:0 24px;max-width:1180px;background:#f5f7fa;color:#182638}h1{margin-bottom:4px}table{width:100%;border-collapse:collapse;background:white}td,th{padding:12px;text-align:left;border-bottom:1px solid #dfe5eb;overflow-wrap:anywhere}pre{white-space:pre-wrap;background:#fff;padding:20px;border-left:4px solid #527184}.scroll{overflow-x:auto}small{color:#526376}</style>"
                    f"<h1>{esc(report['project'])}</h1><small>{esc(report['platform'])} · UTC {esc(report['created_at'])} · 保存时快照，重新执行命令刷新</small>"
                    f"<h2>交付门禁</h2><pre>{esc(report['gate'])}</pre><h2>需求与证据</h2><div class='scroll'><table><tr><th>ID</th><th>需求</th><th>记录状态</th><th>当前检查</th><th>证据</th></tr>{req_rows}</table></div>"
                    f"<h2>工作流进度</h2><div class='scroll'><table><tr><th>工作流</th><th>状态</th><th>当前步骤</th><th>步骤明细</th></tr>{run_rows}</table></div><p>本报告只读取保存的状态；无模型调用或设备操作。草案、仿真、构建、真实设备与客户验收按证据分别判定。</p></html>")
        atomic_write(output, document)
    return report, output


def main() -> int:
    from tools_requirements import PLATFORMS
    parser = argparse.ArgumentParser(description="项目初始化、只读探测、真实模型闭环与进度报告")
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="在工作区新建平台对应的需求草案，禁止覆盖")
    init.add_argument("directory")
    init.add_argument("--platform", choices=sorted(PLATFORMS), required=True)
    init.add_argument("--name", default="")
    commands.add_parser("discover", help="只读串口/USB/SDK 清单，不连接目标")
    commands.add_parser("smoke", help="调用真实 API 进行两条评测和一条工具工作流，会消耗 Token")
    status = commands.add_parser("status", help="汇总项目门禁、证据和已保存工作流")
    status.add_argument("project_file")
    status.add_argument("--html", action="store_true", help="另存可离线查看的 HTML 进度报告")
    args = parser.parse_args()
    try:
        if args.command == "init":
            print(f"已创建平台需求草案: {init_project(args.directory, args.platform, args.name)}")
        elif args.command == "discover":
            from tools_discovery import discover_environment
            print(discover_environment())
        elif args.command == "smoke":
            report, output = smoke_test()
            print(f"MODEL_SMOKE_{report['status']}\n{report['reason']}\n报告: {output}")
            return 0 if report["status"] == "PASS" else 2 if report["status"] == "BLOCKED" else 1
        else:
            report, output = project_status(args.project_file, args.html)
            print(redact_secrets(json.dumps(report, ensure_ascii=False, indent=2)))
            if output:
                print(f"可视化报告: {output}")
    except (OSError, ValueError, KeyError, TypeError, yaml.YAMLError) as error:
        print(redact_secrets(f"错误: {error}"), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
