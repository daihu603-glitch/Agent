"""客户需求规格、验收结果和需求追踪。"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import yaml

from tools import tool, WORKSPACE

PLATFORMS = {"stm32", "linux_driver", "linux_app", "esp32", "rk3588", "android_app", "ai_agent_app", "device_app_ai", "opc_ua"}
METHODS = {"inspection", "analysis", "bench_test", "hil_test", "stress_test", "customer_test"}
RESULT_STATES = {"not_run", "pass", "fail", "blocked", "waived"}
REQ_ID = re.compile(r"^(CR|FR|NFR|IF|SAFE)-[A-Za-z0-9][A-Za-z0-9_-]*$")


def _resolve(path: str) -> Path:
    p = Path(path)
    return p.resolve() if p.is_absolute() else (WORKSPACE / path).resolve()


def _workspace_path(path: str) -> Path:
    p = (WORKSPACE / path).resolve()
    if p != WORKSPACE and WORKSPACE not in p.parents:
        raise ValueError(f"输出路径越出工作区: {path}")
    return p


def _load_spec(path: str) -> tuple[Path, dict]:
    p = _resolve(path)
    if not p.is_file():
        raise ValueError(f"需求规格不存在: {p}")
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("需求规格顶层必须是对象")
    return p, data


def _requirements(spec: dict) -> list[dict]:
    reqs = spec.get("requirements", [])
    if not isinstance(reqs, list):
        raise ValueError("requirements 必须是数组")
    return reqs


def _validate_spec(spec: dict) -> list[str]:
    errors = []
    project = spec.get("project", {})
    if not isinstance(project, dict) or not project.get("name"):
        errors.append("缺少 project.name")
    if project.get("platform") not in PLATFORMS:
        errors.append(f"project.platform 必须是 {sorted(PLATFORMS)} 之一")
    reqs = _requirements(spec)
    if not reqs:
        errors.append("至少需要一条客户需求")
    seen = set()
    for index, req in enumerate(reqs, 1):
        if not isinstance(req, dict):
            errors.append(f"第 {index} 条需求不是对象")
            continue
        rid = str(req.get("id", ""))
        prefix = f"需求[{rid or index}]"
        if not REQ_ID.match(rid):
            errors.append(f"{prefix}: id 应形如 FR-001 / NFR-001")
        if rid in seen:
            errors.append(f"{prefix}: id 重复")
        seen.add(rid)
        for key in ("title", "acceptance", "method"):
            if not str(req.get(key, "")).strip():
                errors.append(f"{prefix}: 缺少 {key}")
        if req.get("method") not in METHODS:
            errors.append(f"{prefix}: method 必须为 {sorted(METHODS)} 之一")
        if req.get("acceptance") and not re.search(r"\d|演示|检查|审查|一致|无错误", str(req["acceptance"])):
            errors.append(f"{prefix}: acceptance 应包含可测量指标或明确检查判据")
        trace = req.get("trace", {})
        if trace and not isinstance(trace, dict):
            errors.append(f"{prefix}: trace 必须是对象")
    return errors


def _results_path(spec_path: Path) -> Path:
    return spec_path.parent / "acceptance_results.yaml"


def _load_results(spec_path: Path) -> dict:
    p = _results_path(spec_path)
    if not p.is_file():
        return {"results": {}}
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(data.get("results", {}), dict):
        raise ValueError(f"验收结果格式错误: {p}")
    return data


def missing_evidence_files(spec_path: Path, evidence: str) -> list[str]:
    items = [item.strip() for item in evidence.split(",") if item.strip()]
    if not items:
        return ["(未提供证据文件)"]
    missing = []
    for item in items:
        p = Path(item)
        candidates = [p] if p.is_absolute() else [spec_path.parent / p, WORKSPACE / p]
        if not any(candidate.is_file() for candidate in candidates):
            missing.append(item)
    return missing


@tool(
    "create_requirement_spec",
    "创建客户需求规格。requirements 是 JSON 数组，每项包含 id/title/acceptance/method，可含 priority、source、trace。支持嵌入式、android_app、ai_agent_app、device_app_ai、opc_ua。", 
    {
        "project_name": {"type": "string"},
        "platform": {"type": "string"},
        "requirements": {"type": "string", "description": "需求 JSON 数组"},
        "customer": {"type": "string"},
        "version": {"type": "string", "description": "需求基线版本，默认 0.1.0"},
        "output_path": {"type": "string", "description": "相对工作区路径，默认 <project>/requirements.yaml"},
    },
    ["project_name", "platform", "requirements"],
)
def create_requirement_spec(project_name: str, platform: str, requirements: str, customer: str = "", version: str = "0.1.0", output_path: str = "") -> str:
    try:
        reqs = json.loads(requirements)
    except json.JSONDecodeError as e:
        return f"错误：需求 JSON 无效: {e}"
    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "-", project_name).strip("-") or "project"
    spec = {
        "schema_version": 1,
        "project": {"name": project_name, "customer": customer, "platform": platform, "requirement_baseline": version},
        "requirements": reqs,
        "change_requests": [],
    }
    errors = _validate_spec(spec)
    if errors:
        return "需求规格校验失败:\n" + "\n".join(f"- {e}" for e in errors)
    try:
        out = _workspace_path(output_path or f"{safe_name}/requirements.yaml")
    except ValueError as e:
        return f"错误：{e}"
    if out.exists():
        return f"错误：需求基线已存在，避免覆盖: {out}。请使用 update_traceability 或指定新的版本化 output_path。"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(spec, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return f"已创建需求基线: {out}\n共 {len(reqs)} 条需求；下一步为每条需求补充 trace.design/code/tests。"


@tool(
    "validate_requirements",
    "校验客户需求规格的完整性、唯一 ID、可测验收标准和追踪结构。",
    {"spec_path": {"type": "string"}},
    ["spec_path"],
)
def validate_requirements(spec_path: str) -> str:
    try:
        p, spec = _load_spec(spec_path)
        errors = _validate_spec(spec)
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    if errors:
        return "需求规格校验失败:\n" + "\n".join(f"- {e}" for e in errors)
    reqs = _requirements(spec)
    linked = sum(bool(r.get("trace", {}).get("tests")) for r in reqs)
    return f"需求规格校验通过: {p}\n需求 {len(reqs)} 条，已关联测试 {linked} 条，未关联测试 {len(reqs)-linked} 条。"


@tool(
    "update_traceability",
    "更新单条需求的设计、代码和测试追踪证据。code/tests 为逗号分隔的文件路径或测试 ID。",
    {
        "spec_path": {"type": "string"},
        "requirement_id": {"type": "string"},
        "design": {"type": "string"},
        "code": {"type": "string"},
        "tests": {"type": "string"},
    },
    ["spec_path", "requirement_id"],
)
def update_traceability(spec_path: str, requirement_id: str, design: str = "", code: str = "", tests: str = "") -> str:
    try:
        p, spec = _load_spec(spec_path)
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    for req in _requirements(spec):
        if req.get("id") == requirement_id:
            trace = req.setdefault("trace", {})
            for key, value in (("design", design), ("code", code), ("tests", tests)):
                if value:
                    trace[key] = [x.strip() for x in value.split(",") if x.strip()]
            trace["updated_at"] = datetime.now(timezone.utc).isoformat()
            p.write_text(yaml.safe_dump(spec, allow_unicode=True, sort_keys=False), encoding="utf-8")
            return f"已更新 {requirement_id} 追踪: {trace}"
    return f"错误：找不到需求 {requirement_id}"


@tool(
    "record_acceptance_result",
    "记录一条需求的验收结果。status 只能是 not_run/pass/fail/blocked/waived；pass 必须提供存在的证据文件，waived 必须提供批准说明或证据。", 
    {
        "spec_path": {"type": "string"},
        "requirement_id": {"type": "string"},
        "status": {"type": "string"},
        "evidence": {"type": "string", "description": "日志、截图、报告路径或测试记录"},
        "notes": {"type": "string"},
        "tester": {"type": "string"},
    },
    ["spec_path", "requirement_id", "status"],
)
def record_acceptance_result(spec_path: str, requirement_id: str, status: str, evidence: str = "", notes: str = "", tester: str = "agent") -> str:
    if status not in RESULT_STATES:
        return f"错误：status 必须为 {sorted(RESULT_STATES)}"
    try:
        p, spec = _load_spec(spec_path)
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    if requirement_id not in {r.get("id") for r in _requirements(spec)}:
        return f"错误：需求 {requirement_id} 不在基线中"
    if status == "pass" and not evidence.strip():
        return "错误：pass 必须填写证据文件路径，不能用 notes 替代"
    if status == "pass":
        missing = missing_evidence_files(p, evidence)
        if missing:
            return f"错误：pass 证据文件不存在: {', '.join(missing)}"
    if status == "waived" and not (evidence.strip() or notes.strip()):
        return "错误：waived 必须填写 evidence 或批准说明 notes"
    data = _load_results(p)
    data["results"][requirement_id] = {
        "status": status,
        "evidence": evidence,
        "notes": notes,
        "tester": tester,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
    }
    out = _results_path(p)
    out.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return f"已记录 {requirement_id}={status}: {out}"


@tool(
    "traceability_report",
    "生成需求→设计→代码→测试→验收结果追踪报告，并给出交付门禁结论。",
    {
        "spec_path": {"type": "string"},
        "output_path": {"type": "string", "description": "默认与需求文件同目录 traceability_report.md"},
    },
    ["spec_path"],
)
def traceability_report(spec_path: str, output_path: str = "") -> str:
    try:
        p, spec = _load_spec(spec_path)
        errors = _validate_spec(spec)
        results = _load_results(p).get("results", {})
    except (ValueError, yaml.YAMLError) as e:
        return f"错误：{e}"
    lines = [f"# 需求追踪与验收报告", "", f"项目: {spec.get('project', {}).get('name', '')}", f"平台: {spec.get('project', {}).get('platform', '')}", ""]
    lines += ["| 需求 | 设计 | 代码 | 测试 | 验收 | 证据 |", "|---|---|---|---|---|---|"]
    counts = {state: 0 for state in RESULT_STATES}
    blockers = list(errors)
    for req in _requirements(spec):
        rid = req.get("id", "")
        trace = req.get("trace", {}) or {}
        result = results.get(rid, {})
        status = result.get("status", "not_run")
        counts[status] = counts.get(status, 0) + 1
        for field in ("design", "code", "tests"):
            if not trace.get(field):
                blockers.append(f"{rid} 缺少 trace.{field}")
        if status != "pass":
            blockers.append(f"{rid} 验收状态为 {status}")
        else:
            for missing in missing_evidence_files(p, str(result.get("evidence", ""))):
                blockers.append(f"{rid} 验收证据文件不存在: {missing}")
        lines.append("| {id} {title} | {design} | {code} | {tests} | {status} | {evidence} |".format(
            id=rid, title=str(req.get("title", "")).replace("|", "\\|"),
            design=", ".join(trace.get("design", [])) or "缺失",
            code=", ".join(trace.get("code", [])) or "缺失",
            tests=", ".join(trace.get("tests", [])) or "缺失",
            status=status, evidence=str(result.get("evidence", "")).replace("|", "\\|") or "-",
        ))
    ready = not blockers
    lines += ["", f"验收统计: {counts}", f"交付门禁: {'PASS' if ready else 'BLOCKED'}"]
    if blockers:
        lines += ["", "## 阻塞项"] + [f"- {b}" for b in blockers]
    text = "\n".join(lines)
    out = Path(output_path).resolve() if output_path else p.parent / "traceability_report.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    return text + f"\n\n报告: {out}"
