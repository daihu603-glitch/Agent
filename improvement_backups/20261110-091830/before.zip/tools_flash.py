"""烧录工具：通过 ST-Link / OpenOCD / UART 烧录固件到 STM32。"""
from __future__ import annotations

import hashlib
import os
import re
import subprocess
from pathlib import Path

from tools import tool
import config


@tool(
    "flash_firmware",
    "烧录固件到 STM32 目标板。支持 stlink / openocd / uart 三种方式。⚠️ 硬件操作，工作流中建议设 confirm: true。",
    {
        "firmware": {"type": "string", "description": ".hex 或 .bin 文件的绝对路径"},
        "method": {"type": "string", "description": "烧录方式: stlink | openocd | uart，默认读配置"},
        "chip": {"type": "string", "description": "芯片型号，默认 STM32F103VE"},
        "address": {"type": "string", "description": "bin 文件烧录地址，默认 0x08000000"},
    },
    ["firmware"],
)
def flash_firmware(firmware: str, method: str = "", chip: str = "", address: str = "0x08000000") -> str:
    fw = Path(firmware).resolve()
    if not fw.is_file():
        return f"错误：固件文件不存在: {firmware}"
    if fw.suffix.lower() not in {".hex", ".bin"}:
        return "错误：仅允许烧录 .hex 或 .bin 固件"
    if not re.fullmatch(r"0x[0-9A-Fa-f]+", address):
        return "错误：烧录地址必须是 0x 开头的十六进制数"

    method = method or config.serial_cfg.get("flash_method", "stlink")
    chip = chip or config.serial_cfg.get("chip", "STM32F103VE")

    if method == "stlink":
        return _flash_stlink(fw, chip, address)
    elif method == "openocd":
        return _flash_openocd(fw, chip, address)
    elif method == "uart":
        return _flash_uart(fw)
    else:
        return f"错误：未知烧录方式 {method}"


def _flash_stlink(fw: Path, chip: str, address: str) -> str:
    prog = config.PROGRAMMER_CLI
    if not prog:
        ide = config.get_cubeide_headless()
        if ide:
            candidate = ide.parent / "STLinkServer" / "ST-LINK_CLI.exe"
            if candidate.exists():
                prog = str(candidate)
            else:
                for p in ide.parent.rglob("STM32_Programmer_CLI.exe"):
                    prog = str(p)
                    break
                if not prog:
                    for p in ide.parent.rglob("ST-LINK_CLI.exe"):
                        prog = str(p)
                        break

    if not prog:
        return ("错误：找不到烧录工具。请安装 STM32CubeProgrammer 并在 config.yaml 设置 programmer_cli 路径，"
                "或安装 OpenOCD 使用 openocd 方式。")

    suffix = fw.suffix.lower()
    if suffix == ".hex":
        cmd = [prog, "-c", "port=SWD", "-w", str(fw), "-v", "-rst"]
    else:
        cmd = [prog, "-c", "port=SWD", "-w", str(fw), address, "-v", "-rst"]

    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        return "错误：烧录超时（60s），检查 ST-Link 连接。"
    except FileNotFoundError:
        return f"错误：无法执行 {prog}"

    output = r.stdout + r.stderr
    if r.returncode != 0 or "error" in output.lower():
        return f"烧录失败:\n{output[-1500:]}"
    return f"烧录成功: {fw.name} → {chip}\nSHA256: {_sha256(fw)}\n{output[-500:]}"


def _jim_quote(value: str) -> str:
    if "\n" in value or "\r" in value:
        raise ValueError("OpenOCD 参数不能包含换行")
    return "{" + value.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}") + "}"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _flash_openocd(fw: Path, chip: str, address: str) -> str:
    openocd = config.toolchain.get("openocd") or "openocd"
    family_match = re.match(r"STM32([A-Za-z]+\d)", chip.upper())
    if not family_match:
        return f"错误：无法从芯片型号确定 OpenOCD target: {chip}"
    family = family_match.group(1).lower()
    expected_cfg = f"target/stm32{family}x.cfg"
    configured_cfg = config.serial_cfg.get("openocd_cfg", "") or expected_cfg
    if configured_cfg.replace("\\", "/") != expected_cfg:
        return f"错误：openocd_cfg={configured_cfg} 与芯片 {chip} 不匹配，应使用 {expected_cfg}"
    cfg_file = expected_cfg
    quoted_fw = _jim_quote(fw.as_posix())

    if fw.suffix.lower() == ".hex":
        program_cmd = f"program {quoted_fw} verify reset"
    else:
        program_cmd = f"program {quoted_fw} {address} verify reset"

    cmd = [
        openocd,
        "-f", "interface/stlink.cfg",
        "-f", cfg_file,
        "-c", program_cmd,
        "-c", "shutdown",
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        return "错误：找不到 openocd，请安装并配置路径。"
    except subprocess.TimeoutExpired:
        return "错误：OpenOCD 烧录超时"

    output = r.stdout + r.stderr
    if r.returncode != 0:
        return f"OpenOCD 烧录失败:\n{output[-1500:]}"
    return f"OpenOCD 烧录成功: {fw.name}\nSHA256: {_sha256(fw)}\n{output[-500:]}"


def _flash_uart(fw: Path) -> str:
    return ("错误：UART 自动烧录未实现，已中止，不能视为烧录成功。请改用 stlink/openocd，或人工完成以下步骤后再独立验收：\n"
            "1. 将 BOOT0 接高电平，复位进入 Bootloader\n"
            "2. 使用 STM32 Flash Demonstrator 或 stm32flash 工具烧录\n"
            "3. 烧录完成后 BOOT0 接低电平，复位运行\n"
            f"固件路径: {fw}")


@tool(
    "flash_esp32",
    "烧录 ESP32 固件（idf.py flash）。",
    {
        "project_dir": {"type": "string", "description": "ESP-IDF 项目目录"},
        "port": {"type": "string", "description": "串口号，留空自动检测"},
    },
    ["project_dir"],
)
def flash_esp32(project_dir: str, port: str = "") -> str:
    proj = Path(project_dir)
    if not proj.exists():
        return f"错误：目录不存在: {project_dir}"

    idf_path = config.IDF_PATH
    if not idf_path:
        return "错误：未配置 ESP-IDF 路径"

    port = port or config.esp32_cfg.get("serial_port", "")
    idf_py = Path(idf_path) / "tools" / "idf.py"
    env = os.environ.copy()
    env["IDF_PATH"] = idf_path

    cmd = ["python", str(idf_py)]
    if port:
        cmd += ["-p", port]
    cmd += ["flash"]

    try:
        r = subprocess.run(cmd, cwd=str(proj), env=env, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return "错误：ESP32 烧录超时"

    output = r.stdout + r.stderr
    if r.returncode != 0:
        return f"ESP32 烧录失败:\n{output[-1500:]}"
    return f"ESP32 烧录成功。\n{output[-500:]}"