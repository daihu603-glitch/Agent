"""Linux 内核驱动与跨平台应用构建、DTS 静态检查。"""
from __future__ import annotations

import os
import re
from pathlib import Path

from tools import tool
from procutil import CommandError, existing_dir, find_artifact, run_command, windows_to_wsl
import config


def _linux_prefix(use_wsl: bool, distro: str = "") -> list[str]:
    if not use_wsl:
        return []
    name = distro or config.toolchain.get("wsl_distro", "")
    cmd = ["wsl.exe"]
    if name:
        cmd += ["-d", name]
    return cmd + ["--"]


def _make_driver_cmd(project: Path, kdir: str, arch: str, cross: str, jobs: int, use_wsl: bool, distro: str) -> tuple[list[str], str | None]:
    kdir = kdir or config.toolchain.get("linux_kdir", "")
    if not kdir:
        raise CommandError("未配置内核源码/头文件目录 toolchain.linux_kdir")
    if use_wsl:
        source = windows_to_wsl(project)
        kernel_dir = windows_to_wsl(kdir)
    else:
        source = str(project)
        kernel_dir = kdir
    if not re.match(r"^[A-Za-z0-9_+.-]*$", cross):
        raise CommandError("交叉编译器前缀包含非法字符")
    argv = _linux_prefix(use_wsl, distro) + [
        "make", "-C", kernel_dir, f"M={source}", f"ARCH={arch}", f"CROSS_COMPILE={cross}", f"-j{jobs}", "modules",
    ]
    return argv, None if use_wsl else str(project)


@tool(
    "linux_environment_check",
    "检查 Linux 驱动/应用开发环境：内核头文件、编译器、CMake、设备树编译器和 WSL。",
    {
        "kdir": {"type": "string"}, "cross_compile": {"type": "string"},
        "use_wsl": {"type": "boolean"}, "wsl_distro": {"type": "string"},
    },
    [],
)
def linux_environment_check(kdir: str = "", cross_compile: str = "", use_wsl: bool = False, wsl_distro: str = "") -> str:
    kdir = kdir or config.toolchain.get("linux_kdir", "")
    cross = cross_compile or config.toolchain.get("linux_cross_compile", "")
    prefix = _linux_prefix(use_wsl, wsl_distro)
    checks = []
    for label, argv in (
        ("make", ["make", "--version"]),
        ("cross-gcc", [f"{cross}gcc", "--version"]),
        ("cmake", ["cmake", "--version"]),
        ("dtc", ["dtc", "--version"]),
    ):
        try:
            checks.append(f"{label}: {run_command(prefix + argv, timeout=15, max_output=300)}")
        except CommandError as e:
            checks.append(f"{label}: 不可用 ({e})")
    checks.append(f"KDIR: {kdir or '未配置'}")
    if kdir and not use_wsl:
        p = Path(kdir)
        checks.append(f"KDIR 存在: {p.exists()}；Makefile: {(p / 'Makefile').exists()}")
    return "\n".join(checks)


@tool(
    "build_linux_driver",
    "使用 make -C KDIR M=项目目录 modules 构建 Linux 内核驱动，返回 .ko 路径、大小和哈希。支持 WSL 与交叉编译。",
    {
        "project_dir": {"type": "string"}, "kdir": {"type": "string"},
        "arch": {"type": "string"}, "cross_compile": {"type": "string"},
        "jobs": {"type": "integer"}, "use_wsl": {"type": "boolean"}, "wsl_distro": {"type": "string"},
    },
    ["project_dir"],
)
def build_linux_driver(project_dir: str, kdir: str = "", arch: str = "", cross_compile: str = "", jobs: int = 4, use_wsl: bool = False, wsl_distro: str = "") -> str:
    try:
        proj = existing_dir(project_dir, "驱动项目")
        arch = arch or config.toolchain.get("linux_arch", "arm64")
        cross = cross_compile if cross_compile != "" else config.toolchain.get("linux_cross_compile", "")
        argv, cwd = _make_driver_cmd(proj, kdir, arch, cross, max(1, min(jobs, 32)), use_wsl, wsl_distro)
        output = run_command(argv, cwd=cwd, timeout=600)
        artifact = find_artifact(proj, ("*.ko",))
        if not artifact:
            return f"编译命令成功但未找到 .ko:\n{output}"
        import hashlib
        digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
        return f"驱动编译成功: {artifact}\n大小: {artifact.stat().st_size} bytes\nSHA256: {digest}\n{output[-1500:]}"
    except CommandError as e:
        return f"驱动编译失败: {e}"


@tool(
    "build_linux_app",
    "构建 Linux 应用。支持 CMake（推荐 toolchain file 交叉编译）或 Make，返回可执行文件和构建日志。",
    {
        "project_dir": {"type": "string"}, "method": {"type": "string", "description": "cmake 或 make"},
        "build_dir": {"type": "string"}, "toolchain_file": {"type": "string"},
        "build_type": {"type": "string"}, "jobs": {"type": "integer"},
        "use_wsl": {"type": "boolean"}, "wsl_distro": {"type": "string"},
    },
    ["project_dir"],
)
def build_linux_app(project_dir: str, method: str = "cmake", build_dir: str = "build", toolchain_file: str = "", build_type: str = "Release", jobs: int = 4, use_wsl: bool = False, wsl_distro: str = "") -> str:
    try:
        proj = existing_dir(project_dir, "应用项目")
        prefix = _linux_prefix(use_wsl, wsl_distro)
        jobs = max(1, min(jobs, 32))
        if Path(build_dir).is_absolute() or ".." in Path(build_dir).parts:
            return "错误：build_dir 必须是项目内的相对路径"
        toolchain = toolchain_file or config.toolchain.get("linux_toolchain_file", "")
        if use_wsl:
            source = windows_to_wsl(proj)
            binary_dir = f"{source}/{build_dir}"
            toolchain = windows_to_wsl(toolchain) if toolchain else ""
        else:
            source = str(proj)
            binary_dir = str(proj / build_dir)
        if method == "cmake":
            configure = prefix + ["cmake", "-S", source, "-B", binary_dir, f"-DCMAKE_BUILD_TYPE={build_type}"]
            if toolchain:
                configure.append(f"-DCMAKE_TOOLCHAIN_FILE={toolchain}")
            run_command(configure, timeout=180)
            output = run_command(prefix + ["cmake", "--build", binary_dir, "--parallel", str(jobs)], timeout=600)
        elif method == "make":
            output = run_command(prefix + ["make", "-C", source, f"-j{jobs}"], timeout=600)
        else:
            return "错误：method 只能是 cmake 或 make"
        root = proj / build_dir if method == "cmake" else proj
        binaries = []
        for p in root.rglob("*"):
            if p.is_file() and p.stat().st_size > 0:
                if os.name != "nt" and os.access(p, os.X_OK) and p.suffix == "":
                    binaries.append(p)
                elif p.suffix in {".elf", ".out"}:
                    binaries.append(p)
        listing = "\n".join(f"  {p} ({p.stat().st_size} bytes)" for p in binaries[:10])
        return f"Linux 应用构建成功。\n可执行产物:\n{listing or '  未自动识别，请检查构建输出目录'}\n{output[-1500:]}"
    except CommandError as e:
        return f"Linux 应用构建失败: {e}"


@tool(
    "check_devicetree",
    "用 dtc 编译 DTS 做语法检查，并静态提示兼容字符串、pinctrl、时钟、复位、中断和 regulator 缺失。",
    {
        "dts_path": {"type": "string"}, "output_path": {"type": "string"},
        "use_wsl": {"type": "boolean"}, "wsl_distro": {"type": "string"},
    },
    ["dts_path"],
)
def check_devicetree(dts_path: str, output_path: str = "", use_wsl: bool = False, wsl_distro: str = "") -> str:
    p = Path(dts_path).resolve()
    if not p.is_file() or p.suffix.lower() not in {".dts", ".dtsi", ".dtso"}:
        return f"错误：DTS 文件不存在或格式不支持: {p}"
    text = p.read_text(encoding="utf-8", errors="replace")
    hints = []
    if "compatible" not in text:
        hints.append("未发现 compatible，确认设备匹配方式")
    for token, hint in (("pinctrl", "建议检查引脚复用"), ("clocks", "建议检查时钟父节点和频率"), ("interrupts", "若使用中断需核对触发方式"), ("reset", "若硬件有复位脚需配置"), ("regulator", "若外设独立供电需配置 regulator")):
        if token not in text:
            hints.append(f"未出现 {token}: {hint}")
    out = Path(output_path).resolve() if output_path else p.with_suffix(".agent.dtb")
    prefix = _linux_prefix(use_wsl, wsl_distro)
    source = windows_to_wsl(p) if use_wsl else str(p)
    target = windows_to_wsl(out) if use_wsl else str(out)
    try:
        result = run_command(prefix + ["dtc", "-I", "dts", "-O", "dtb", "-o", target, source], timeout=60)
        return f"DTS 语法检查通过: {out}\n{result}\n静态提示:\n" + ("\n".join(f"- {h}" for h in hints) or "- 无")
    except CommandError as e:
        return f"DTS 检查失败: {e}\n静态提示:\n" + "\n".join(f"- {h}" for h in hints)


@tool(
    "linux_driver_static_check",
    "对驱动源码做静态风险扫描：copy_to/from_user、并发锁、错误路径、资源释放、休眠上下文和 DEVICE_ATTR 权限。",
    {"source_path": {"type": "string", "description": ".c 文件或源码目录"}},
    ["source_path"],
)
def linux_driver_static_check(source_path: str) -> str:
    p = Path(source_path).resolve()
    files = list(p.rglob("*.c")) if p.is_dir() else [p]
    files = [f for f in files if f.is_file()]
    if not files:
        return "错误：未找到 C 源文件"
    rules = [
        (r"copy_(to|from)_user\s*\(", "检查用户指针返回值，未复制字节必须纳入错误处理"),
        (r"spin_lock\s*\([^)]*\)[\s\S]{0,800}(msleep|ssleep|schedule)\s*\(", "spinlock 区域疑似睡眠，可能导致死锁"),
        (r"(request_irq|gpiod_get|clk_get|ioremap|kzalloc|kmalloc|devm_kzalloc)\s*\(", "核对获取资源的错误检查和释放路径"),
        (r"DEVICE_ATTR\s*\([^,]+,\s*0?666", "设备属性允许任意用户写，需安全审查"),
        (r"printk\s*\(\s*KERN_(ERR|WARNING)", "核对错误日志是否包含足够上下文且不泄露敏感数据"),
    ]
    findings = []
    for f in files[:100]:
        text = f.read_text(encoding="utf-8", errors="replace")
        for pattern, advice in rules:
            for match in re.finditer(pattern, text):
                line = text.count("\n", 0, match.start()) + 1
                findings.append(f"{f}:{line}: {advice}")
    if "module_init" not in "\n".join(f.read_text(encoding="utf-8", errors="replace") for f in files):
        findings.append("未发现 module_init，确认是否为内核模块项目")
    return f"扫描 {len(files)} 个文件，{len(findings)} 条提示:\n" + ("\n".join(findings[:150]) or "无") + "\n注意：静态提示不等于运行时验证，仍需 insmod/rmmod、压力测试和 KASAN/lockdep。"
