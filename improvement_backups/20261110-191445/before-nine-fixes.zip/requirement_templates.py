"""Platform-specific starting points; no template constitutes customer approval."""
from __future__ import annotations

from copy import deepcopy

# id, title, measurable acceptance, method
_PLATFORM_CASES = {
    "stm32": [("FR-001", "固件版本查询", "串口 version 连续查询 100 次，1 秒内返回版本和 Git SHA，错误数为 0", "hil_test"),
              ("SAFE-001", "通信中断安全恢复", "通信断开 10 秒后恢复，5 秒内恢复响应，连续 100 次无非预期输出", "hil_test")],
    "esp32": [("FR-001", "联网和状态查询", "指定网络下连续连接 100 次，10 秒内获取 IP 并返回固件版本，失败次数为 0", "hil_test"),
              ("SAFE-001", "OTA 失败回滚", "错误镜像和更新中断各测试 10 次，均恢复到上一有效版本并保留配置", "hil_test")],
    "linux_driver": [("FR-001", "驱动加载与接口", "在目标内核加载卸载模块 100 次，设备节点与接口正常，无 Oops 或残留资源", "hil_test"),
                     ("SAFE-001", "异常参数与并发", "并发 8 个客户端执行 1000 次接口请求，非法参数返回明确错误，无内核崩溃", "hil_test")],
    "linux_app": [("FR-001", "服务部署与状态", "目标机重启服务 100 次，5 秒内返回健康状态和版本，失败数为 0", "hil_test"),
                  ("SAFE-001", "断线恢复", "依赖服务中断 10 秒并恢复，30 秒内重连，连续 100 次无进程崩溃", "hil_test")],
    "rk3588": [("FR-001", "镜像启动与外设", "目标板启动 20 次，60 秒内完成启动，版本和需求外设检查一致", "hil_test"),
               ("SAFE-001", "升级恢复", "按批准方案测试 10 次升级失败，均可按恢复手册恢复并校验版本一致", "hil_test")],
    "android_app": [("FR-001", "安装和核心流程", "指定真机完成安装、启动和需求核心流程 20 次，崩溃数为 0，版本一致", "hil_test"),
                    ("SAFE-001", "权限拒绝与重连", "拒绝权限和网络中断各测试 10 次，显示明确恢复入口，无崩溃或数据丢失", "hil_test")],
    "ai_agent_app": [("FR-001", "模型工具调用闭环", "真实模型评测执行至少 20 条，保存逐条工具输入输出及 Token，核心用例通过率 100%", "bench_test"),
                     ("SAFE-001", "越权工具拒绝", "至少 20 次越权工具请求全部在执行层拒绝，报告中密钥泄露数为 0", "bench_test")],
    "device_app_ai": [("IF-001", "三端版本与命令追踪", "连续执行 100 条授权命令，每条具备设备 APP 后端版本和同一追踪 ID，丢失数为 0", "hil_test"),
                      ("SAFE-001", "断网和重复命令保护", "断网、重复请求、撤销权限各测试 20 次，无重复设备动作或未授权执行", "hil_test")],
    "opc_ua": [("FR-001", "节点浏览读取与受控写回读", "本地协议测试能浏览对象、读取温度并对授权 Double 节点确认写入回读，错误数为 0", "bench_test"),
               ("IF-001", "订阅与服务端重启恢复", "订阅能收到新值；服务端重启后 8 秒内重连并恢复订阅，退出后会话和订阅均释放", "bench_test"),
               ("SAFE-001", "白名单与异常参数保护", "10 次越权写入全部拒绝且原值不变；未确认写入、无效节点、错误类型及远程端点均拒绝", "bench_test")],
}


def requirement_template(platform: str, name: str) -> dict:
    if platform not in _PLATFORM_CASES:
        raise ValueError(f"未知平台: {platform}")
    cases = list(_PLATFORM_CASES[platform])
    cases.append(("NFR-001", "持续运行与资源稳定性", "在已确认的目标环境连续运行 24 小时，进程或固件崩溃数为 0，通信错误率不超过 0.1%，记录资源曲线", "stress_test"))
    return deepcopy({
        "schema_version": 1,
        "project": {"name": name, "customer": "", "platform": platform, "requirement_baseline": "0.1.0"},
        "baseline_status": "draft_requires_customer_review",
        "requirements": [{"id": rid, "title": title, "acceptance": acceptance, "method": method,
                          "source": "平台模板；指标须经客户评审确认", "priority": "must",
                          "trace": {"design": [], "code": [], "tests": []}}
                         for rid, title, acceptance, method in cases],
        "change_requests": [],
    })
